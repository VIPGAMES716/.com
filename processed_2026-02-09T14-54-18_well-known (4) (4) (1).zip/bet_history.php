<?php
// bet_history.php
require_once __DIR__."/includes/util.php";

/**
 * Expectations:
 * - util.php provides: app_pdo(), app_name(), require_login()
 * - Logged-in user id (mobile) is returned by require_login()
 * - You'll create table `bets` (DDL below).
 */

$pdo = app_pdo();
$uid = require_login(); // blocks if not logged in

/* ---------- Inputs ---------- */
$filter = strtolower(trim($_GET['filter'] ?? 'all'));        // all | win | loss | await
$q      = trim((string)($_GET['q'] ?? ''));                  // search text
$page   = max(1, (int)($_GET['page'] ?? 1));
$pp     = 20;                                                // per-page

$validFilters = ['all','win','loss','await'];
if (!in_array($filter, $validFilters, true)) $filter = 'all';

/* ---------- Export CSV ---------- */
if (isset($_GET['export']) && $_GET['export'] == '1') {
    // same filter/search, but no pagination (or you can cap to 5k rows)
    $sql = "SELECT game_name, order_code, placed_at, amount, net_result, status
            FROM bets
            WHERE user_id = :uid";
    $where = [];
    $args  = [':uid'=>$uid];

    if ($filter !== 'all') {
        $where[] = "status = :st";
        $args[':st'] = $filter;
    }
    if ($q !== '') {
        $where[] = "(LOWER(game_name) LIKE :kw OR LOWER(order_code) LIKE :kw OR DATE_FORMAT(placed_at, '%Y-%m-%d %H:%i') LIKE :kw)";
        $args[':kw'] = '%'.strtolower($q).'%';
    }
    if ($where) $sql .= " AND ".implode(" AND ", $where);
    $sql .= " ORDER BY id DESC LIMIT 5000";

    $st = $pdo->prepare($sql);
    $st->execute($args);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=bet_history.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Game','Order ID','Date','Amount','Net','Result']);
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['game_name'],
            strtoupper($r['order_code']),
            date('Y-m-d H:i', strtotime($r['placed_at'])),
            '₹'.number_format((float)$r['amount'],2),
            ($r['net_result'] >= 0 ? '+' : '').'₹'.number_format((float)$r['net_result'],2),
            strtoupper($r['status']),
        ]);
    }
    fclose($out);
    exit;
}

/* ---------- Count + Page fetch ---------- */
$sqlBase = "FROM bets WHERE user_id = :uid";
$where = [];
$args  = [':uid'=>$uid];

if ($filter !== 'all') {
    $where[] = "status = :st";
    $args[':st'] = $filter;
}
if ($q !== '') {
    $where[] = "(LOWER(game_name) LIKE :kw OR LOWER(order_code) LIKE :kw OR DATE_FORMAT(placed_at, '%Y-%m-%d %H:%i') LIKE :kw)";
    $args[':kw'] = '%'.strtolower($q).'%';
}
if ($where) $sqlBase .= " AND ".implode(" AND ", $where);

/* total count */
$st = $pdo->prepare("SELECT COUNT(*) ".$sqlBase);
$st->execute($args);
$total = (int)$st->fetchColumn();

$pages = max(1, (int)ceil($total / $pp));
if ($page > $pages) $page = $pages;
$off = ($page - 1) * $pp;

/* page rows */
$st = $pdo->prepare("
    SELECT id, game_name, order_code, placed_at, amount, net_result, status, icon_hint
    ".$sqlBase."
    ORDER BY id DESC
    LIMIT :lim OFFSET :off
");
foreach ($args as $k=>$v) {
    $st->bindValue($k, $v);
}
$st->bindValue(':lim', $pp, PDO::PARAM_INT);
$st->bindValue(':off', $off, PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Helpers ---------- */
function status_badge(string $s): array {
    $s = strtolower($s);
    if ($s === 'win')   return ['text'=>'WIN',   'class'=>'text-bg-success', 'netClass'=>'text-success'];
    if ($s === 'loss')  return ['text'=>'LOSS',  'class'=>'text-bg-danger',  'netClass'=>'text-danger'];
    return                ['text'=>'AWAIT', 'class'=>'text-bg-warning', 'netClass'=>'text-warning'];
}
function icon_html(?string $hint): string {
    // Allow a few bootstrap icons based on hint; fallback dice
    $map = [
        'dice'   =>'bi-dice-5',
        'shield' =>'bi-shield-plus',
        'rocket' =>'bi-rocket-takeoff',
        'cards'  =>'bi-suit-spade-fill',
        'slot'   =>'bi-sliders',
        'plinko' =>'bi-triangle-fill',
        'crash'  =>'bi-lightning-charge-fill',
    ];
    $cls = $map[strtolower($hint ?? '')] ?? 'bi-dice-5';
    return '<i class="bi '.$cls.'"></i>';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>Bet History – <?= htmlspecialchars(app_name()) ?></title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
:root{
  --clr-primary:#8d78ff;
  --clr-card-bg:rgba(255,255,255,.08);
  --clr-glass-line:rgba(255,255,255,.12);
  --clr-dim:rgba(255,255,255,.74);
}
*{box-sizing:border-box}
body{
  margin:0;min-height:100vh;font-family:'Poppins',sans-serif;color:#fff;
  background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
  overflow-x:hidden;
}
body::after{content:"";position:fixed;inset:0;pointer-events:none;opacity:.05;
  background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png');
  mix-blend-mode:overlay;animation:grain 9s steps(10) infinite}
@keyframes grain{0%{background-position:0 0}100%{background-position:100% 100%}}

.app{max-width:480px;margin:0 auto;padding:1rem 1rem 8.5rem}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem}
.brand{font-size:1.5rem;font-weight:700}
.actions{display:flex;gap:.5rem}
.btn-mini{border:none;border-radius:14px;font-size:.85rem;font-weight:600;padding:.4rem .85rem;cursor:pointer;transition:.25s}
.btn-mini.back{background:var(--clr-card-bg);border:1px solid var(--clr-glass-line);color:var(--clr-dim)}
.btn-mini.back:hover{background:rgba(255,255,255,.12)}
.btn-mini.exp{background:var(--clr-primary);color:#fff}
.btn-mini.exp:hover{opacity:.9}

.search-input{width:100%;padding:.7rem 1rem;border-radius:18px;margin-bottom:1rem;
  border:1px solid var(--clr-glass-line);background:var(--clr-card-bg);
  color:#fff;font-size:.95rem}
.tabs{display:flex;gap:.5rem;margin-bottom:1rem}
.tab-btn{flex:1;padding:.5rem 0;border-radius:14px;font-size:.85rem;font-weight:600;
  border:1px solid var(--clr-glass-line);background:var(--clr-card-bg);color:var(--clr-dim);
  cursor:pointer;transition:.25s;text-decoration:none;text-align:center}
.tab-btn.active{background:var(--clr-primary);color:#fff}

.bet-tile{display:flex;gap:.75rem;padding:.8rem;border-radius:18px;margin-bottom:.6rem;
  background:var(--clr-card-bg);border:1px solid var(--clr-glass-line);backdrop-filter:blur(16px);align-items:center}
.game-icon{width:40px;height:40px;border-radius:14px;background:#8d78ff55;display:flex;align-items:center;justify-content:center;font-size:1.4rem;color:#fff}
.tile-main{flex:1}
.tile-main h6{margin:0;font-size:.9rem;font-weight:600;display:flex;align-items:center;gap:.4rem;flex-wrap:wrap}
.tile-main h6 .meta{font-size:.68rem;font-weight:400;color:var(--clr-dim)}
.tile-side{text-align:right;display:flex;flex-direction:column;align-items:flex-end;gap:2px}
.net{font-size:1rem;font-weight:700}
.badge{font-size:.7rem;padding:.2rem .55rem}
.text-bg-success{background:#198754!important;color:#fff}
.text-bg-warning{background:#ffc107!important;color:#000}
.text-bg-danger{background:#dc3545!important;color:#fff}

.pagination-nav{display:flex;justify-content:center;gap:.25rem;margin:1.2rem 0;flex-wrap:wrap}
.pg{display:inline-block;padding:.35rem .75rem;border-radius:12px;font-size:.8rem;font-weight:600;
  border:1px solid var(--clr-glass-line);background:var(--clr-card-bg);color:var(--clr-dim);transition:.25s;text-decoration:none}
.pg:hover{background:rgba(255,255,255,.12)}
.pg.active{background:var(--clr-primary);color:#fff;border-color:var(--clr-primary)}
.ellipsis{padding:.35rem .3rem;color:var(--clr-dim)}

.dock{position:fixed;left:0;right:0;bottom:0;height:82px;z-index:10;
      backdrop-filter:blur(18px);background:rgba(14,10,30,.68);border-top:1px solid var(--clr-glass-line);
      display:grid;grid-template-columns:repeat(5,1fr);align-items:center;justify-items:center;
      padding:0 env(safe-area-inset-left,8px) 0 env(safe-area-inset-right,8px)}
.nav-btn{color:var(--clr-dim);text-decoration:none;font-size:.75rem;display:flex;flex-direction:column;
      align-items:center;gap:2px;user-select:none}
.nav-btn .bi{font-size:1.4rem} .nav-btn.active{color:#fff}
.fab{position:absolute;top:-6px;left:50%;transform:translateX(-50%);
      width:64px;height:64px;border-radius:22px;background:var(--clr-primary);
      display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#fff;
      box-shadow:0 6px 24px rgba(141,120,255,.55);border:5px solid rgba(255,255,255,.05)}
@media(max-width:350px){.nav-btn .bi{font-size:1.25rem}.nav-btn span{font-size:.63rem)}
</style>
</head>
<body>
<div class="app">

  <!-- Header -->
  <div class="header">
    <div class="brand">Bet History</div>
    <div class="actions">
      <a class="btn-mini exp" id="exportBtn" href="?export=1&filter=<?= urlencode($filter) ?>&q=<?= urlencode($q) ?>">
        <i class="bi bi-download me-1"></i>Export
      </a>
      <button class="btn-mini back" onclick="history.back()">
        <i class="bi bi-arrow-left me-1"></i>Back
      </button>
    </div>
  </div>

  <!-- Search & tabs (server-side state via querystring) -->
  <form method="get">
    <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
    <input id="searchInput" name="q" class="search-input" placeholder="Search game, #-order id, date…" value="<?= htmlspecialchars($q) ?>">
  </form>
  <div class="tabs">
    <?php
      foreach (['all'=>'All','win'=>'Win','loss'=>'Loss','await'=>'Await'] as $k=>$lbl) {
        $url = '?filter='.urlencode($k).'&q='.urlencode($q);
        $active = $filter===$k ? 'active':'';
        echo '<a class="tab-btn '.$active.'" href="'.$url.'">'.$lbl.'</a>';
      }
    ?>
  </div>

  <!-- Bet list -->
  <div id="bet_list">
    <?php if (empty($rows)): ?>
      <div style="opacity:.8">No bets found.</div>
    <?php else: ?>
      <?php foreach ($rows as $r):
        $badge = status_badge($r['status']);
        $dt    = date('d M y – H:i', strtotime($r['placed_at']));
        $net   = (float)$r['net_result'];
        $netTxt= ($net >= 0 ? '+' : '').'₹'.number_format($net,2);
        $netCls= $badge['netClass'];
      ?>
      <div class="bet-tile"
           data-status="<?= htmlspecialchars(strtolower($r['status'])) ?>"
           data-game  ="<?= htmlspecialchars(strtolower($r['game_name'])) ?>"
           data-oid   ="<?= htmlspecialchars(strtolower($r['order_code'])) ?>"
           data-dt    ="<?= htmlspecialchars(date('Y-m-d H:i', strtotime($r['placed_at']))) ?>">
        <div class="game-icon"><?= icon_html($r['icon_hint']) ?></div>
        <div class="tile-main">
          <h6>
            <?= htmlspecialchars($r['game_name']) ?>
            <span class="meta">
              <?= '#-'.strtoupper($r['order_code']) ?> • <?= htmlspecialchars($dt) ?>
            </span>
          </h6>
        </div>
        <div class="tile-side">
          <div class="net <?= $netCls ?>">
            <?= $netTxt ?>
          </div>
          <span class="badge rounded-pill <?= $badge['class'] ?>">
            <?= $badge['text'] ?>
          </span>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Sliding paginator -->
  <div class="pagination-nav">
    <?php
      if ($pages > 1) {
        $mk = function($p,$label=null,$active=false,$disabled=false) use($filter,$q){
          $label = $label ?? (string)$p;
          if ($disabled) {
            return '<span class="pg">'.htmlspecialchars($label).'</span>';
          }
          $cls = 'pg'.($active?' active':'');
          $u = '?filter='.urlencode($filter).'&q='.urlencode($q).'&page='.$p;
          return '<a class="'.$cls.'" href="'.$u.'">'.htmlspecialchars($label).'</a>';
        };
        // Prev
        echo $mk(max(1,$page-1),'«',false, $page==1);
        // Window
        $win = 2;
        $start = max(1, $page-$win);
        $end   = min($pages, $page+$win);
        if ($start > 1) {
          echo $mk(1,'1', $page==1);
          if ($start > 2) echo '<span class="ellipsis">…</span>';
        }
        for ($p=$start; $p<=$end; $p++) {
          echo $mk($p,null,$p==$page);
        }
        if ($end < $pages) {
          if ($end < $pages-1) echo '<span class="ellipsis">…</span>';
          echo $mk($pages,(string)$pages, $page==$pages);
        }
        // Next
        echo $mk(min($pages,$page+1),'»',false, $page==$pages);
      }
    ?>
  </div>
</div>

<!-- Bottom dock -->
<nav class="dock">
  <a href="dashboard.php"  class="nav-btn"><i class="bi bi-controller"></i><span>Arcade</span></a>
  <a href="esports.php" class="nav-btn"><i class="bi bi-trophy"></i><span>eSports</span></a>
  <span></span>
  <a href="chat.php"    class="nav-btn"><i class="bi bi-chat-dots-fill"></i><span>Chat</span></a>
  <a href="profile.php" class="nav-btn active"><i class="bi bi-person-circle"></i><span>Profile</span></a>
  <a href="refer"   class="fab"><i class="bi bi-lightning-fill"></i></a>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Submit search on input pause (optional: press Enter to submit)
const inp = document.getElementById('searchInput');
let t=null;
inp.addEventListener('input', ()=>{
  clearTimeout(t);
  t=setTimeout(()=>inp.form.submit(), 350);
});
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"648dce9918524b9f905e7fa5008b5991","r":1}' crossorigin="anonymous"></script>
</body>
</html>
