<?php
// deposit_history.php — user deposits list + filters + search + CSV export
require_once __DIR__ . '/includes/config.php';
app_require_login();

$pdo = app_pdo();
$UID = app_user_id();
$TABLE = defined('APP_DEPOSIT_TABLE') ? APP_DEPOSIT_TABLE : 'deposits';

/* ---------- helpers ---------- */
function has_col(PDO $pdo, string $t, string $c): bool {
  static $cache = [];
  $k="$t|$c"; if(isset($cache[$k])) return $cache[$k];
  $st=$pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
  $st->execute([$t,$c]); return $cache[$k]=(bool)$st->fetchColumn();
}
function norm(string $s): string { return strtolower(trim($s)); }
function safe(string $s): string { return htmlspecialchars($s, ENT_QUOTES,'UTF-8'); }

/* ---------- map columns (your schema is standard; this keeps it robust) ---------- */
$col_user = has_col($pdo,$TABLE,'user_id')  ? 'user_id'  : null;
$col_amt  = has_col($pdo,$TABLE,'amount')   ? 'amount'   : null;
$col_prov = has_col($pdo,$TABLE,'provider') ? 'provider' : null;
$col_meth = has_col($pdo,$TABLE,'method')   ? 'method'   : null;
$col_txn  = has_col($pdo,$TABLE,'txn_id')   ? 'txn_id'   : null;
$col_stat = has_col($pdo,$TABLE,'status')   ? 'status'   : null;
$col_when = has_col($pdo,$TABLE,'created_at') ? 'created_at' : null;

if(!$col_user || !$col_amt || !$col_when){
  http_response_code(500);
  echo "<h2 style='font-family:system-ui;color:#f66'>deposits table missing required columns.</h2>";
  exit;
}

/* ---------- inputs ---------- */
$allowedTabs = ['all','pending','approved','rejected'];
$status = strtolower($_GET['status'] ?? 'all');
if(!in_array($status,$allowedTabs,true)) $status='all';

$q    = trim((string)($_GET['q'] ?? ''));
$page = max(1,(int)($_GET['page'] ?? 1));
$per  = 20; $off = ($page-1)*$per;

/* ---------- build query ---------- */
$select = "`$col_amt` AS amt, `$col_when` AS dd";
if($col_prov) $select .= ", `$col_prov` AS prov";
if($col_meth) $select .= ", `$col_meth` AS meth";
if($col_txn)  $select .= ", `$col_txn`  AS txn";
if($col_stat) $select .= ", `$col_stat` AS st";

$sql  = "FROM `$TABLE` WHERE `$col_user` = ?";
$args = [$UID];

if($status!=='all' && $col_stat){
  $want = $status==='pending' ? 'Pending' : ($status==='approved' ? 'Approved' : 'Rejected');
  $sql .= " AND `$col_stat` = ?"; $args[] = $want;
}

if($q!==''){
  $like = "%$q%"; $parts=[];
  if($col_txn)  $parts[]="`$col_txn` LIKE ?";
  if($col_prov) $parts[]="`$col_prov` LIKE ?";
  if($col_meth) $parts[]="`$col_meth` LIKE ?";
  if($col_when) $parts[]="`$col_when` LIKE ?";
  if($parts){
    $sql .= " AND (".implode(" OR ", $parts).")";
    foreach($parts as $_) $args[]=$like;
  }
}

$count = (int)db_cell("SELECT COUNT(*) ".$sql, $args);
$totalPages = max(1,(int)ceil($count/$per));

$rows = db_all("SELECT $select ".$sql." ORDER BY `$col_when` DESC LIMIT $per OFFSET $off", $args);

/* ---------- html ---------- */
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Deposit History – <?= safe(app_name()) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{--p:#8d78ff;--card:rgba(255,255,255,.08);--line:rgba(255,255,255,.12);--dim:rgba(255,255,255,.75)}
*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:Poppins,sans-serif;color:#fff;
background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);overflow-x:hidden}
.app{max-width:480px;margin:auto;padding:1rem 1rem 8rem}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem}
.brand{font-size:1.5rem;font-weight:700}.actions{display:flex;gap:.5rem}
.btn-mini{border:none;border-radius:14px;font-size:.85rem;font-weight:600;padding:.4rem .85rem;cursor:pointer}
.btn-mini.back{background:var(--card);border:1px solid var(--line);color:var(--dim)}
.btn-mini.exp{background:var(--p);color:#fff}
.search{width:100%;padding:.7rem 1rem;border-radius:18px;margin-bottom:1rem;border:1px solid var(--line);background:var(--card);color:#fff}
.tabs{display:flex;gap:.5rem;margin-bottom:1rem}
.tab{flex:1;text-align:center;padding:.5rem 0;border-radius:14px;border:1px solid var(--line);background:var(--card);color:var(--dim);text-decoration:none}
.tab.active{background:var(--p);color:#fff}
.rowi{display:flex;gap:.75rem;padding:.8rem;border-radius:18px;margin-bottom:.6rem;background:var(--card);border:1px solid var(--line);align-items:center}
.icon{width:40px;height:40px;border-radius:14px;background:#8d78ff55;display:flex;align-items:center;justify-content:center;font-size:1.3rem}
.meta{font-size:.68rem;color:var(--dim)}
.side{text-align:right}.amt{font-weight:700}
.badge{font-size:.7rem}
.bg-ok{background:#198754}.bg-p{background:#ffc107;color:#000}.bg-bad{background:#dc3545}
.pagination-nav{display:flex;justify-content:center;gap:.25rem;margin:1rem 0;flex-wrap:wrap}
.pg{display:inline-block;padding:.35rem .75rem;border-radius:12px;border:1px solid var(--line);background:var(--card);color:var(--dim)}
.pg.active{background:var(--p);color:#fff;border-color:var(--p)}
</style>
</head>
<body>
<div class="app">
  <div class="header">
    <div class="brand">Deposit History</div>
    <div class="actions">
      <button id="exportBtn" class="btn-mini exp"><i class="bi bi-download me-1"></i>Export</button>
      <button class="btn-mini back" onclick="history.back()"><i class="bi bi-arrow-left me-1"></i>Back</button>
    </div>
  </div>

  <form method="get">
    <input type="hidden" name="status" value="<?= safe($status) ?>">
    <input type="hidden" name="page" value="<?= (int)$page ?>">
    <input name="q" value="<?= safe($q) ?>" class="search" placeholder="Search provider, order id, date…">
  </form>

  <div class="tabs">
    <?php
      $labs = ['all'=>'All','pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'];
      foreach($labs as $k=>$lbl){
        $cls = $k===$status?'tab active':'tab';
        $href = '?status='.$k.'&q='.urlencode($q).'&page=1';
        echo "<a class='$cls' href='$href'>$lbl</a>";
      }
    ?>
  </div>

  <div id="list">
    <?php if(!$rows): ?>
      <div class="rowi"><div class="icon"><i class="bi bi-info-circle"></i></div><div>No records</div></div>
    <?php else: foreach($rows as $r):
      $st = $col_stat ? strtolower($r['st']) : 'pending';
      $cls = ($st==='approved')?'bg-ok':(($st==='rejected')?'bg-bad':'bg-p');
      $prov = $col_prov ? $r['prov'] : '—';
      $meth = $col_meth ? $r['meth'] : '';
      $txn  = $col_txn  ? $r['txn']  : '';
      $dt   = $r['dd'];
    ?>
      <div class="rowi" data-status="<?= safe($st) ?>" data-prov="<?= safe(strtolower($prov)) ?>" data-oid="<?= safe(strtoupper($txn)) ?>" data-dt="<?= safe($dt) ?>">
        <div class="icon"><i class="bi bi-wallet2"></i></div>
        <div style="flex:1">
          <div style="font-weight:600"><?= safe($prov) ?> <?= $meth? ' • '.safe($meth):'' ?></div>
          <div class="meta"><?= $txn? '#-'.safe(strtoupper($txn)).' • ':'' ?><?= safe($dt) ?></div>
        </div>
        <div class="side">
          <div class="amt">₹<?= number_format((float)$r['amt'],2) ?></div>
          <span class="badge rounded-pill <?= $cls ?>"><?= strtoupper($st) ?></span>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>

  <form method="get" class="pagination-nav">
    <input type="hidden" name="q" value="<?= safe($q) ?>">
    <input type="hidden" name="status" value="<?= safe($status) ?>">
    <button class="pg" name="page" value="<?= max(1,$page-1) ?>" <?= $page<=1?'disabled':'' ?>><i class="bi bi-chevron-left"></i></button>
    <?php
      $win = [];
      if($totalPages<=6){ for($i=1;$i<=$totalPages;$i++) $win[]=$i; }
      else {
        $win=[1,2,'…']; $s=max(3,$page-1); $e=min($totalPages-2,$page+1);
        for($i=$s;$i<=$e;$i++) $win[]=$i; if($e<$totalPages-2) $win[]='…'; $win[]=$totalPages-1; $win[]=$totalPages;
      }
      foreach($win as $p){
        if($p==='…'){ echo '<span class="pg">…</span>'; continue; }
        $cls = ($p==$page)?'pg active':'pg';
        echo "<button name='page' value='$p' class='$cls'>$p</button>";
      }
    ?>
    <button class="pg" name="page" value="<?= min($totalPages,$page+1) ?>" <?= $page>=$totalPages?'disabled':'' ?>><i class="bi bi-chevron-right"></i></button>
  </form>
</div>

<script>
const rows=[...document.querySelectorAll('#list .rowi')];
document.getElementById('exportBtn').addEventListener('click',()=>{
  const out=[["Provider","Method","Order ID","Date","Amount","Status"]];
  rows.forEach(r=>{
    if(r.style.display==='none') return;
    const prov=r.querySelector('div[style*="font-weight"]').textContent.trim();
    const meta=r.querySelector('.meta').textContent;
    const oid=r.dataset.oid||'';
    const dt=r.dataset.dt||meta;
    const amt=r.querySelector('.amt').innerText.replace(/[^\d.]/g,'');
    const st=r.querySelector('.badge').innerText;
    out.push([prov.split('•')[0].trim(), prov.includes('•')?prov.split('•')[1].trim():'', oid, dt, amt, st]);
  });
  const csv=out.map(a=>a.map(v=>`"${v}"`).join(',')).join('\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
  const a=document.createElement('a'); a.href=url; a.download='deposit_history.csv'; a.click(); URL.revokeObjectURL(url);
});
</script>
</body>
</html>
