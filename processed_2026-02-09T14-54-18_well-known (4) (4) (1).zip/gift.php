<?php
// gift.php – Redeem Gift/Promo Code (credits users.balance only)

require_once __DIR__ . "/includes/util.php";
require_login();                         // ensure logged in
$pdo = app_pdo();
$uid = function_exists('current_uid') ? current_uid() : ($_SESSION['user_id'] ?? ''); // users.user_id (varchar)

// ---------- Safe bootstrap (matches your structures) ----------
$pdo->exec("
CREATE TABLE IF NOT EXISTS promo_codes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(64) NOT NULL,
  reward_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  max_uses INT NULL,
  per_user_limit INT NOT NULL DEFAULT 1,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");
$pdo->exec("
CREATE TABLE IF NOT EXISTS promo_redemptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code_id INT NOT NULL,
  user_id VARCHAR(64) NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  ip_address VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY code_id (code_id),
  KEY user_id (user_id),
  CONSTRAINT fk_pr_code FOREIGN KEY (code_id) REFERENCES promo_codes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// ---------- Redeem (AJAX) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  header('Content-Type: application/json; charset=utf-8');

  $code = strtoupper(trim((string)($_POST['code'] ?? '')));
  if ($code === '') { echo json_encode(['ok'=>false,'msg'=>'Please enter a code.']); exit; }

  try {
    $pdo->beginTransaction();

    // 1) Load code
    $q = $pdo->prepare("SELECT id, code, reward_amount, max_uses, per_user_limit, starts_at, ends_at, is_active
                        FROM promo_codes WHERE UPPER(code)=? LIMIT 1");
    $q->execute([$code]);
    $pc = $q->fetch(PDO::FETCH_ASSOC);
    if (!$pc || (int)$pc['is_active'] !== 1) {
      $pdo->rollBack(); echo json_encode(['ok'=>false,'msg'=>'Invalid or inactive code.']); exit;
    }

    // 2) Time window
    $now = new DateTimeImmutable('now');
    if (!empty($pc['starts_at']) && $now < new DateTimeImmutable($pc['starts_at'])) {
      $pdo->rollBack(); echo json_encode(['ok'=>false,'msg'=>'This code is not active yet.']); exit;
    }
    if (!empty($pc['ends_at']) && $now > new DateTimeImmutable($pc['ends_at'])) {
      $pdo->rollBack(); echo json_encode(['ok'=>false,'msg'=>'This code has expired.']); exit;
    }

    // 3) Global cap
    if (!empty($pc['max_uses'])) {
      $q = $pdo->prepare("SELECT COUNT(*) FROM promo_redemptions WHERE code_id=?");
      $q->execute([$pc['id']]);
      if ((int)$q->fetchColumn() >= (int)$pc['max_uses']) {
        $pdo->rollBack(); echo json_encode(['ok'=>false,'msg'=>'Code usage limit reached.']); exit;
      }
    }

    // 4) Per-user cap
    $limit = max(1, (int)$pc['per_user_limit']);
    $q = $pdo->prepare("SELECT COUNT(*) FROM promo_redemptions WHERE code_id=? AND user_id=?");
    $q->execute([$pc['id'], $uid]);
    if ((int)$q->fetchColumn() >= $limit) {
      $pdo->rollBack(); echo json_encode(['ok'=>false,'msg'=>'You have already redeemed this code.']); exit;
    }

    // 5) Amount
    $amount = (float)$pc['reward_amount'];
    if ($amount <= 0) {
      $pdo->rollBack(); echo json_encode(['ok'=>false,'msg'=>'This code has zero reward.']); exit;
    }

    // 6) Record redemption first (atomic)
    $ins = $pdo->prepare("INSERT INTO promo_redemptions (code_id,user_id,amount,ip_address,created_at)
                          VALUES (?,?,?,?,NOW())");
    $ins->execute([$pc['id'], $uid, $amount, $_SERVER['REMOTE_ADDR'] ?? '']);

    // 7) CREDIT ONLY users.balance
    $u = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE user_id = ?");
    $u->execute([$amount, $uid]);

    $pdo->commit();
    echo json_encode(['ok'=>true,'msg'=>"+₹".number_format($amount,2)." credited to balance!"]); exit;

  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // error_log($e->getMessage()); // uncomment if you want details in error_log
    echo json_encode(['ok'=>false,'msg'=>'Server error. Please try again.']); exit;
  }
}

// ---------- History ----------
$hist = [];
try {
  $q = $pdo->prepare("SELECT pr.id, pc.code, pr.amount, pr.created_at
                      FROM promo_redemptions pr
                      JOIN promo_codes pc ON pc.id=pr.code_id
                      WHERE pr.user_id=? ORDER BY pr.id DESC LIMIT 50");
  $q->execute([$uid]);
  $hist = $q->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
  $hist = [];
}

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function dt_h($s){ $t=strtotime($s); return date('d M Y, h:i A',$t); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Redeem Code – <?= h(function_exists('app_name') ? app_name() : 'App') ?></title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#0b0a12;--line:rgba(255,255,255,.12);--p:#8d78ff;--card:rgba(255,255,255,.08);--dim:rgba(255,255,255,.75);}
*{box-sizing:border-box}
body{margin:0;color:#fff;font-family:Poppins,system-ui;background:radial-gradient(1000px 560px at 50% -20%,#2d2570 0%,#0b0a12 70%);}
.app{max-width:520px;margin:auto;padding:18px 14px 108px}
.brand{font-size:1.45rem;font-weight:800}

/* How it works (① ② ③) */
.how{background:var(--card);border:1px solid var(--line);border-radius:22px;padding:16px 18px;margin-bottom:14px}
.how h6{margin:0 0 10px 0;font-weight:800}
.steps{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:10px}
.steps li{position:relative;padding-left:34px;font-weight:700}
.steps li::before{content:"①";position:absolute;left:0;top:-1px;color:#cfc6ff}
.steps li:nth-child(2)::before{content:"②"}
.steps li:nth-child(3)::before{content:"③"}

/* form + history */
.glass{background:var(--card);border:1px solid var(--line);border-radius:24px;padding:16px}
.label{font-weight:800;margin-bottom:8px}
.input{width:100%;border-radius:14px;padding:.9rem 1rem;font-weight:700;color:#fff;background:rgba(255,255,255,.06);border:1px solid var(--line)}
.input::placeholder{color:#c8c2ff}
.btn{border:none;border-radius:16px;padding:.85rem 1rem;font-weight:800;background:var(--p);color:#fff}
.card{display:flex;gap:12px;align-items:center;padding:12px;border-radius:18px;background:rgba(255,255,255,.06);border:1px solid var(--line);margin-bottom:10px}
.icon{width:46px;height:46px;border-radius:14px;background:#ffffff1a;display:flex;align-items:center;justify-content:center;color:#cfc6ff;font-size:1.25rem}
.amount{margin-left:auto;font-weight:800;color:#7bfdc5}

/* toast */
.toast{position:fixed;left:50%;bottom:92px;transform:translateX(-50%);padding:.8rem 1.2rem;border-radius:16px;color:#fff;border:1px solid rgba(255,255,255,.18);backdrop-filter:blur(18px);opacity:0;transition:.34s;z-index:1000}
.tok{background:#1f9d6b}.terr{background:#d64561}
</style>
</head>
<body>
<div class="app">
  <div class="brand" style="margin-bottom:12px">Redeem Code</div>

  <!-- How it works -->
  <div class="how">
    <h6>How it works</h6>
    <ul class="steps">
      <li>Enter your gift / promo code.</li>
      <li>Tap <b>Redeem</b>.</li>
      <li>Rewards appear instantly in your <b>balance</b>.</li>
    </ul>
  </div>

  <!-- Redeem form -->
  <div class="glass" style="margin-bottom:14px">
    <div class="label">Gift / Promo Code</div>
    <form id="f">
      <input class="input" name="code" placeholder="ABC123XYZ" required>
      <div style="height:10px"></div>
      <button class="btn" type="submit">Redeem</button>
    </form>
  </div>

  <!-- Redeem history -->
  <div class="glass">
    <div class="label">Redeem History</div>
    <?php if (!$hist): ?>
      <div style="opacity:.8">No redemptions yet.</div>
    <?php else: foreach ($hist as $h): ?>
      <div class="card">
        <div class="icon"><i class="bi bi-gift-fill"></i></div>
        <div>
          <div class="label" style="font-size:.98rem"><?= h($h['code']) ?></div>
          <div style="opacity:.8;font-size:.85rem"><?= h(dt_h($h['created_at'])) ?></div>
        </div>
        <div class="amount">+₹<?= number_format((float)$h['amount'],2) ?></div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<script>
const form = document.getElementById('f');
function toast(msg, ok=true){
  const t=document.createElement('div');
  t.className='toast '+(ok?'tok':'terr'); t.textContent=msg;
  document.body.appendChild(t); requestAnimationFrame(()=>t.style.opacity='1');
  setTimeout(()=>{ t.style.opacity='0'; setTimeout(()=>t.remove(),340); }, 2200);
}
form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  try{
    const res = await fetch(location.href, {method:'POST', body:new FormData(form)});
    const d = await res.json();
    toast(d.msg, !!d.ok);
    if(d.ok){ form.reset(); setTimeout(()=>location.reload(), 600); }
  }catch{
    toast('Network error. Try again.', false);
  }
});
</script>
</body>
</html>
