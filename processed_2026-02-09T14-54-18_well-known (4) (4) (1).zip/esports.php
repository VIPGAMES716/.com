<?php
require_once __DIR__ . "/includes/util.php";
require_login();

$pdo = app_pdo();
$uid = current_uid();
//The perfect provide 
/* -------------------- DB: Tables -------------------- */
$pdo->exec("
CREATE TABLE IF NOT EXISTS lot_lotteries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  jackpot INT NOT NULL DEFAULT 0,         -- in rupees
  cycle_secs INT NOT NULL DEFAULT 10800,  -- seconds between draws
  next_start_ts INT NOT NULL,             -- unix timestamp
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$pdo->exec("
CREATE TABLE IF NOT EXISTS lot_bets (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  lottery_id INT NOT NULL,
  numbers_json JSON NOT NULL,
  stake DECIMAL(12,2) NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  status ENUM('placed','won','lost','void') NOT NULL DEFAULT 'placed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (user_id), INDEX (lottery_id), INDEX (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$pdo->exec("
CREATE TABLE IF NOT EXISTS lot_passes (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  plan VARCHAR(40) NOT NULL,      -- 'monthly'
  price DECIMAL(12,2) NOT NULL,
  starts_at DATE NOT NULL,
  ends_at DATE NOT NULL,
  status ENUM('active','expired','cancelled') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (user_id), INDEX (status), INDEX (ends_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

/* -------------------- Seed lotteries (once) -------------------- */
$seedNeeded = !$pdo->query("SELECT 1 FROM lot_lotteries LIMIT 1")->fetch();
if ($seedNeeded) {
  $now = time();
  $ins = $pdo->prepare("INSERT INTO lot_lotteries (code, name, jackpot, cycle_secs, next_start_ts) VALUES (?,?,?,?,?)");
  // Morning / Noon / Evening / Midnight
  $ins->execute(['q5_morning',  'Quick-5 Morning',  200000,  5400,  $now + 5400]);
  $ins->execute(['q5_noon',     'Quick-5 Noon',     300000, 10800,  $now + 10800]);
  $ins->execute(['q5_evening',  'Quick-5 Evening',  500000, 16200,  $now + 16200]);
  $ins->execute(['q5_midnight', 'Quick-5 Midnight',1000000, 21600,  $now + 21600]);
}

/* -------------------- CSRF token -------------------- */
if (empty($_SESSION['csrf'])) {
  $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$CSRF = $_SESSION['csrf'];

/* -------------------- AJAX actions -------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  header('Content-Type: application/json; charset=utf-8');
  $action = $_POST['action'] ?? '';
  $csrf   = $_POST['csrf']   ?? '';
  if ($csrf !== ($_SESSION['csrf'] ?? '')) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'Bad CSRF']);
    exit;
  }

  try {
    if ($action === 'place_bet') {
      $lottery_id = (int)($_POST['lottery_id'] ?? 0);
      $nums_raw   = (string)($_POST['numbers'] ?? '[]');
      $amount     = (float)($_POST['amount'] ?? 0);

      $nums = @json_decode($nums_raw, true);
      if (!is_array($nums)) $nums = [];
      $nums = array_values(array_unique(array_map('intval', $nums)));
      sort($nums);

      if ($lottery_id <= 0 || count($nums) !== 5 || $amount <= 0) {
        http_response_code(422);
        echo json_encode(['ok'=>false,'error'=>'Invalid bet']);
        exit;
      }

      // Check lottery exists & active
      $st = $pdo->prepare("SELECT id, next_start_ts FROM lot_lotteries WHERE id=? AND is_active=1");
      $st->execute([$lottery_id]);
      $lot = $st->fetch(PDO::FETCH_ASSOC);
      if (!$lot) {
        http_response_code(404);
        echo json_encode(['ok'=>false,'error'=>'Lottery not found']);
        exit;
      }

      // Total = amount * selected numbers (5)
      $total = $amount * 5;

      // TODO: wallet debit integration (later). For now just record.
      $ins = $pdo->prepare("INSERT INTO lot_bets (user_id, lottery_id, numbers_json, stake, total)
                            VALUES (?,?,?,?,?)");
      $ins->execute([$uid, $lottery_id, json_encode($nums), $amount, $total]);

      echo json_encode(['ok'=>true, 'id'=>$pdo->lastInsertId()]);
      exit;
    }

    if ($action === 'buy_pass') {
      // `Monthly Lottery Pass` = ₹150, validity 30 days (inclusive end)
      $price = 150.00;
      // Check existing active
      $st = $pdo->prepare("SELECT id FROM lot_passes WHERE user_id=? AND status='active' AND ends_at>=CURRENT_DATE()");
      $st->execute([$uid]);
      if ($st->fetch()) {
        echo json_encode(['ok'=>false,'error'=>'You already have an active pass.']);
        exit;
      }
      $starts = new DateTime('today');
      $ends   = (clone $starts)->modify('+30 days');
      $ins = $pdo->prepare("INSERT INTO lot_passes (user_id, plan, price, starts_at, ends_at) VALUES (?,?,?,?,?)");
      $ins->execute([$uid, 'monthly', $price, $starts->format('Y-m-d'), $ends->format('Y-m-d')]);

      echo json_encode(['ok'=>true, 'pass_id'=>$pdo->lastInsertId()]);
      exit;
    }

    if ($action === 'list_lotteries') {
      // Provide fresh timings & rough player counts (bets in last cycle window)
      $rows = $pdo->query("SELECT id, code, name, jackpot, cycle_secs, next_start_ts FROM lot_lotteries WHERE is_active=1 ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
      $out  = [];
      foreach ($rows as $r) {
        // player count = last 3 hours bets for this lottery (quick proxy)
        $st = $pdo->prepare("SELECT COUNT(*) FROM lot_bets WHERE lottery_id=? AND created_at >= (NOW() - INTERVAL 3 HOUR)");
        $st->execute([$r['id']]);
        $players = (int)$st->fetchColumn();
        $out[] = [
          'id' => (int)$r['id'],
          'name' => $r['name'],
          'jackpot' => (int)$r['jackpot'],
          'secs' => max(0, (int)$r['next_start_ts'] - time()),
          'players' => $players
        ];
      }
      echo json_encode(['ok'=>true,'list'=>$out]);
      exit;
    }

    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Unknown action']);
  } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'Server error']);
  }
  exit;
}

/* -------------------- First paint data -------------------- */
$lotteries = $pdo->query("SELECT id, name, jackpot, cycle_secs, next_start_ts
                          FROM lot_lotteries WHERE is_active=1 ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
  <title>Number Lottery — <?= htmlspecialchars(app_name()) ?></title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
  :root{
    --clr-primary:#8d78ff; --clr-secondary:#ff57e6;
    --clr-card-bg:rgba(255,255,255,.08); --clr-glass:rgba(255,255,255,.12);
    --clr-glass-line:rgba(255,255,255,.12); --clr-placeholder:rgba(255,255,255,.55);
    --clr-dim:rgba(255,255,255,.74);
  }
  *{box-sizing:border-box;margin:0;padding:0}
  body{
    min-height:100vh;font-family:Poppins,sans-serif;color:#fff;
    background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
    overflow-x:hidden;
  }
  body::after{
    content:"";position:fixed;inset:0;pointer-events:none;
    background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png');
    mix-blend-mode:overlay;opacity:.05;animation:grain 9s steps(10) infinite;
  }
  @keyframes grain{0%{background-position:0 0}100%{background-position:100% 100%}}
  .app{max-width:480px;margin:auto;padding:1.2rem 1rem 8.6rem;position:relative;z-index:1}
  .glass{background:var(--clr-card-bg);border:1px solid var(--clr-glass);backdrop-filter:blur(16px);border-radius:26px}
  .brand{font-size:1.45rem;font-weight:700}

  .lottery-card{margin-bottom:1rem;padding:1rem;border-radius:20px;background:var(--clr-card-bg);border:1px solid var(--clr-glass);backdrop-filter:blur(16px);transition:transform .3s,box-shadow .3s}
  .lottery-card:hover{transform:translateY(-4px);box-shadow:0 8px 24px rgba(0,0,0,.4)}
  .lottery-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem}
  .lottery-header h6{margin:0;font-size:.95rem;font-weight:600}
  .jackpot{background:var(--clr-secondary);padding:.25rem .6rem;border-radius:12px;font-size:.75rem}
  .lottery-desc{font-size:.85rem;color:var(--clr-dim);margin-bottom:.8rem}
  .lottery-info{display:flex;justify-content:space-between;align-items:center;font-size:.83rem;color:var(--clr-dim)}
  .lottery-info .timer{font-weight:600;color:#fff}
  .btn-join{width:100%;margin-top:.8rem;padding:.75rem;font-weight:600;font-size:.9rem;color:#fff;background:var(--clr-primary);border:none;border-radius:18px;transition:background .25s}
  .btn-join:hover{background:var(--clr-secondary)}

  .pass-card{position:relative;overflow:hidden;padding:1.6rem 1.2rem 1.2rem;border-radius:24px;border:1px solid var(--clr-glass);backdrop-filter:blur(20px);background:var(--clr-card-bg);box-shadow:0 10px 30px rgba(0,0,0,.55);transition:transform .4s,box-shadow .4s;margin-bottom:1rem}
  .pass-card:hover{transform:translateY(-6px);box-shadow:0 14px 52px rgba(0,0,0,.65)}
  .pass-card::before{content:"";position:absolute;top:-60%;left:-60%;width:220%;height:220%;background:conic-gradient(from 0deg,var(--clr-primary),var(--clr-secondary),var(--clr-primary));animation:spin 8s linear infinite;opacity:.22;filter:blur(12px)}
  @keyframes spin{to{transform:rotate(1turn)}}
  .pass-card::after{content:"";position:absolute;inset:0;border-radius:inherit;background:var(--clr-card-bg);z-index:-1}
  .pass-top{display:flex;align-items:center;gap:.6rem;margin-bottom:.7rem}
  .pass-icon{width:48px;height:48px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,var(--clr-primary),var(--clr-secondary));box-shadow:0 0 10px rgba(255,87,230,.45);font-size:1.4rem}
  .pass-title{font-size:1.3rem;font-weight:700}
  .pass-sub{font-size:.68rem;font-weight:600;letter-spacing:.8px;text-transform:uppercase;opacity:.7}
  .pass-features{list-style:none;padding:0;margin:.8rem 0 1rem}
  .pass-features li{display:flex;align-items:center;margin-bottom:.45rem;font-size:.85rem;color:var(--clr-dim)}
  .pass-features li i{color:var(--clr-secondary);margin-right:.5rem;font-size:1rem}
  .price-row{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.7rem}
  .price-tag{font-size:2rem;font-weight:700;line-height:1}
  .price-tag small{font-size:.75rem;font-weight:500;opacity:.75;margin-left:.25rem}
  .btn-pass{flex-grow:1;max-width:150px;background:linear-gradient(135deg,var(--clr-primary),var(--clr-secondary));border:none;color:#fff;font-weight:600;padding:.7rem 1.2rem;border-radius:16px;transition:opacity .25s}
  .btn-pass:hover{opacity:.85}
  .ribbon{position:absolute;top:20px;right:-45px;width:140px;text-align:center;background:linear-gradient(135deg,var(--clr-secondary),var(--clr-primary));color:#fff;font-size:.65rem;font-weight:700;text-transform:uppercase;padding:3px 0;transform:rotate(45deg);box-shadow:0 3px 10px rgba(0,0,0,.4)}

  .dock{position:fixed;left:0;right:0;bottom:0;height:82px;z-index:9;backdrop-filter:blur(18px);background:rgba(14,10,30,.68);border-top:1px solid var(--clr-glass);display:grid;grid-template-columns:repeat(5,1fr);align-items:center;justify-items:center}
  .nav-btn{color:var(--clr-dim);text-decoration:none;font-size:.75rem;display:flex;flex-direction:column;align-items:center;gap:2px}
  .nav-btn .bi{font-size:1.35rem}.nav-btn.active{color:#fff}
  .fab{position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:64px;height:64px;border-radius:22px;background:var(--clr-primary);display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#fff;box-shadow:0 6px 24px rgba(141,120,255,.55);border:5px solid rgba(255,255,255,.05)}

  #numGrid{display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(5,1fr);gap:10px;margin-bottom:1rem;}
  .num-btn{width:48px;height:48px;border-radius:50%;border:1px solid var(--clr-glass);background:var(--clr-card-bg);color:#fff;font-size:.9rem;font-weight:600;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s,transform .2s}
  .num-btn:hover{background:rgba(255,255,255,.12)}
  .num-btn.selected{background:var(--clr-secondary);transform:scale(1.08)}
  .chips .chip{display:inline-block;background:var(--clr-secondary);color:#fff;padding:4px 10px;margin:2px;border-radius:14px;font-size:.75rem}
  .form-control{background:rgba(255,255,255,.05)!important;color:#fff!important;border:1px solid var(--clr-glass-line)!important;border-radius:14px;padding:.9rem 1rem;font-size:1rem}
  .form-control:focus{box-shadow:none;border-color:var(--clr-primary)}
  .form-control::placeholder{color:var(--clr-placeholder)}
  </style>
</head>
<body>
<div class="app">

  <!-- Header -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="brand"><i class="bi bi-trophy-fill me-2"></i>Number Lottery</div>
    <button onclick="history.back()" class="btn btn-sm btn-outline-light rounded-pill px-3">
      <i class="bi bi-arrow-left"></i>
    </button>
  </div>

  <!-- Monthly Pass -->
  <div class="glass pass-card mb-4">
    <span class="ribbon">BEST DEAL</span>
    <div class="pass-top">
      <div class="pass-icon"><i class="bi bi-stars"></i></div>
      <div>
        <div class="pass-title">Monthly Lottery Pass</div>
        <div class="pass-sub">Play every draw for one flat fee</div>
      </div>
    </div>
    <ul class="pass-features">
      <li><i class="bi bi-infinity"></i> Unlimited tickets</li>
      <li><i class="bi bi-gem"></i> VIP jackpots</li>
      <li><i class="bi bi-lightning-charge"></i> Priority payouts</li>
      <li><i class="bi bi-emoji-sunglasses"></i> Exclusive emojis</li>
    </ul>
    <div class="price-row">
      <span class="price-tag">₹150<small>/ month</small></span>
      <button class="btn-pass" id="btnBuyPass">Buy Pass</button>
    </div>
  </div>

  <!-- Lottery cards (server-side first paint) -->
  <?php foreach ($lotteries as $row): 
      $secs = max(0, (int)$row['next_start_ts'] - time());
  ?>
    <div class="glass lottery-card" data-secs="<?= (int)$secs ?>" data-id="<?= (int)$row['id'] ?>" data-name="<?= htmlspecialchars($row['name']) ?>">
      <div class="lottery-header">
        <h6><?= htmlspecialchars($row['name']) ?></h6>
        <span class="jackpot">₹<?= number_format((int)$row['jackpot']) ?></span>
      </div>
      <div class="lottery-desc">lottery.quick5</div>
      <div class="lottery-info">
        <div>Starts in <span class="timer">00:00:00</span></div>
        <div>Players: <span class="players">—</span></div>
      </div>
      <button class="btn-join" data-bs-toggle="modal" data-bs-target="#betModal">Join</button>
    </div>
  <?php endforeach; ?>

</div>

<!-- Dock -->
<nav class="dock">
  <a href="/dashboard.php" class="nav-btn"><i class="bi bi-controller"></i><span>Arcade</span></a>
  <a href="/esports.php" class="nav-btn active"><i class="bi bi-trophy"></i><span>Lottery</span></a>
  <span class="spacer"></span>
  <a href="/chat.php" class="nav-btn"><i class="bi bi-chat-dots-fill"></i><span>Chat</span></a>
  <a href="/profile.php" class="nav-btn"><i class="bi bi-person-circle"></i><span>Profile</span></a>
  <a href="/refer.php" class="fab"><i class="bi bi-lightning-fill"></i></a>
</nav>

<!-- Bet Modal -->
<div class="modal fade" id="betModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content glass p-3">
      <div class="modal-header border-0">
        <h5 class="modal-title"><i class="bi bi-123 me-2"></i>Pick Your Numbers</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2 text-center">Select up to 6 numbers (1-20, pick 5)</div>

        <div id="numGrid"></div>
        <div class="chips mt-3 text-center"></div>

        <div class="input-group mt-3">
          <span class="input-group-text">₹</span>
          <input type="number" id="betAmount" class="form-control" min="1" placeholder="Bet per number">
        </div>
        <div class="mt-2 text-center small">Total stake: <span id="totalAmt">₹0</span></div>

        <div class="d-flex justify-content-between mt-3">
          <button id="btnQuick" type="button" class="btn btn-sm btn-outline-light">Quick-Pick</button>
          <button id="btnClear" type="button" class="btn btn-sm btn-outline-light">Clear</button>
        </div>
      </div>
      <div class="modal-footer border-0">
        <button id="btnSubmit" class="btn btn-pass w-100">Place Bet</button>
      </div>
    </div>
  </div>
</div>

<script>
const CSRF = <?= json_encode($CSRF) ?>;

/* Countdown + live players */
const fmt=s=>{const h=String(Math.floor(s/3600)).padStart(2,'0'),m=String(Math.floor((s%3600)/60)).padStart(2,'0'),sec=String(s%60).padStart(2,'0');return`${h}:${m}:${sec}`};
function paintTimers(){
  document.querySelectorAll('.lottery-card').forEach(c=>{
    let s=+c.dataset.secs;
    if(s>0){ s--; c.dataset.secs=s; }
    const tEl = c.querySelector('.timer');
    if (tEl) tEl.textContent=fmt(Math.max(0,s));
  });
}
setInterval(paintTimers,1000);
document.querySelectorAll('.lottery-card').forEach(c=>{
  const tEl = c.querySelector('.timer');
  if (tEl) tEl.textContent=fmt(+c.dataset.secs);
});

/* Load players counts periodically */
async function refreshLotteries(){
  try{
    const r = await fetch(location.href, {
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams({action:'list_lotteries', csrf: CSRF})
    });
    const d = await r.json();
    if(!d.ok) return;
    const cards = document.querySelectorAll('.lottery-card');
    d.list.forEach((row, i)=>{
      const card = [...cards].find(el => +el.dataset.id === row.id);
      if (!card) return;
      card.dataset.secs = row.secs;
      const pEl = card.querySelector('.players');
      if (pEl) pEl.textContent = row.players;
      const tEl = card.querySelector('.timer');
      if (tEl) tEl.textContent = fmt(row.secs);
    });
  }catch(e){}
}
refreshLotteries();
setInterval(refreshLotteries, 15000);

/* Number grid / select logic */
const grid=document.getElementById('numGrid'),
      chips=document.querySelector('.chips'),
      amtIn=document.getElementById('betAmount'),
      total=document.getElementById('totalAmt');

for(let n=1;n<=20;n++){
  const b=document.createElement('div');
  b.className='num-btn';
  b.textContent=n;
  b.onclick=()=>{
    b.classList.toggle('selected');
    if(grid.querySelectorAll('.selected').length>5) b.classList.remove('selected');
    renderChips();
  };
  grid.appendChild(b);
}
function renderChips(){
  chips.innerHTML='';
  [...grid.querySelectorAll('.selected')].forEach(b=>{
    const c=document.createElement('span');
    c.className='chip';
    c.textContent=b.textContent;
    c.onclick=()=>{ b.classList.remove('selected'); renderChips(); };
    chips.appendChild(c);
  });
  updateTotal();
}
function updateTotal(){
  const bet=parseFloat(amtIn.value)||0;
  total.textContent='₹'+(bet * grid.querySelectorAll('.selected').length);
}
amtIn.oninput=updateTotal;

document.getElementById('btnQuick').onclick=()=>{
  [...grid.querySelectorAll('.selected')].forEach(b=>b.classList.remove('selected'));
  [...Array(20).keys()].sort(()=>Math.random()-.5).slice(0,5).forEach(i=>grid.children[i].classList.add('selected'));
  renderChips();
};
document.getElementById('btnClear').onclick=()=>{
  [...grid.querySelectorAll('.selected')].forEach(b=>b.classList.remove('selected'));
  renderChips();
  amtIn.value='';
  updateTotal();
};

/* Modal reset + track which lottery */
let currentLot=null;
document.getElementById('betModal').addEventListener('show.bs.modal',e=>{
  document.getElementById('btnClear').click();
  const card=e.relatedTarget.closest('.lottery-card');
  currentLot={ id:card.dataset.id, name:card.dataset.name };
});

/* Place bet → server */
document.getElementById('btnSubmit').onclick=async ()=>{
  const nums=[...grid.querySelectorAll('.selected')].map(b=>+b.textContent),
        stake=parseFloat(amtIn.value)||0;
  if(nums.length!==5||!stake){ alert("Please choose 5 numbers and enter an amount."); return; }
  try{
    const r = await fetch(location.href, {
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams({
        action:'place_bet',
        csrf: CSRF,
        lottery_id: currentLot.id,
        numbers: JSON.stringify(nums),
        amount: stake
      })
    });
    const d = await r.json();
    if(!d.ok) throw new Error(d.error||'Failed');
    bootstrap.Modal.getInstance(document.getElementById('betModal')).hide();
    alert("Bet placed! Good luck 🤞");
    refreshLotteries();
  }catch(err){
    alert('⚠️ '+(err.message||'Error'));
  }
};

/* Buy Monthly Pass */
document.getElementById('btnBuyPass').onclick = async ()=>{
  try{
    const r = await fetch(location.href, {
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams({action:'buy_pass', csrf: CSRF})
    });
    const d = await r.json();
    if(!d.ok) throw new Error(d.error||'Failed');
    alert('Monthly Pass activated! 🎟️');
  }catch(err){
    alert('⚠️ '+(err.message||'Error'));
  }
};
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
