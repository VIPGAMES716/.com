<?php
// recharge_callback.php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/payments/cola_client.php';

$pdo = app_pdo();

// Read raw
$raw = file_get_contents('php://input') ?: '';
$headers = [];
foreach ($_SERVER as $k=>$v) {
  if (stripos($k,'http_')===0) {
    $h = str_replace('_','-', substr($k,5));
    $headers[$h] = $v;
  }
}
cola_log('callback_raw', ['ip'=>$_SERVER['REMOTE_ADDR'] ?? '','hdr'=>$headers,'raw'=>$raw]);

$vr = cola_verify_callback(
  [
    'sign'      => $_SERVER['HTTP_SIGN']      ?? ($_SERVER['HTTP_HTTP_SIGN'] ?? ''),
    'timestamp' => $_SERVER['HTTP_TIMESTAMP'] ?? '',
    'nonce'     => $_SERVER['HTTP_NONCE']     ?? '',
    'Sign'      => $_SERVER['HTTP_SIGN']      ?? '',
    'Timestamp' => $_SERVER['HTTP_TIMESTAMP'] ?? '',
    'Nonce'     => $_SERVER['HTTP_NONCE']     ?? '',
  ],
  $raw
);

if (!$vr['ok'] || empty($vr['parsed'])) {
  http_response_code(400);
  echo 'invalid';
  exit;
}

$payload = $vr['parsed'];

// Normalize fields from callback (common names; adjust if docs show different keys)
$merchantOrder = $payload['McorderNo'] ?? $payload['orderNo'] ?? $payload['merchantOrderNo'] ?? '';
$status        = strtolower($payload['status'] ?? ($payload['result']['status'] ?? ($payload['tradeStatus'] ?? '')));
$amountPaid    = (float)($payload['Amount'] ?? ($payload['paidAmount'] ?? 0));

// We treat any of these as success
$ok = in_array($status, ['success','succeed','completed','paid','approved','ok'], true) || ((string)($payload['code'] ?? '') === '200');

if (!$merchantOrder) {
  http_response_code(400);
  echo 'no-order';
  exit;
}

try {
  $pdo->beginTransaction();

  // Lock the deposit row
  $st = $pdo->prepare("SELECT * FROM deposits WHERE txn_id=? FOR UPDATE");
  $st->execute([$merchantOrder]);
  $d = $st->fetch(PDO::FETCH_ASSOC);
  if (!$d) { $pdo->rollBack(); echo 'unknown-order'; exit; }

  // Already processed?
  if (strtolower($d['status']) !== 'pending') {
    $pdo->commit(); echo 'ok'; exit;
  }

  if ($ok) {
    // Approve + credit once
    $pdo->prepare("UPDATE deposits SET status='Approved' WHERE id=?")->execute([$d['id']]);
    $pdo->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?")->execute([(float)$d['amount'], $d['user_id']]);
  } else {
    $pdo->prepare("UPDATE deposits SET status='Rejected' WHERE id=?")->execute([$d['id']]);
  }

  $pdo->commit();
  echo 'success';
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  cola_log('callback_err', $e->getMessage());
  http_response_code(500);
  echo 'error';
}
