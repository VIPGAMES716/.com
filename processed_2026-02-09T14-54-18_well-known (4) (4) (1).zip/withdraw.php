<?php
// withdraw.php — UPI + Bank payout; deducts from users.balance and saves details
require_once __DIR__ . '/includes/config.php';
app_require_login();

$pdo = app_pdo();
$UID = app_user_id();

/* ---------- helpers ---------- */
function has_col(PDO $pdo, string $table, string $col): bool {
  static $cache = [];
  $key = "$table|$col";
  if (isset($cache[$key])) return $cache[$key];
  $st = $pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
  $st->execute([$table,$col]);
  return $cache[$key] = (bool)$st->fetchColumn();
}
function fmtINR($n){ return '₹'.number_format((float)$n,2); }

/* ---------- config ---------- */
$MIN = 10;         // min withdrawal
$MAX = 500000;     // hard ceiling safeguard

/* ---------- CSRF ---------- */
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

$err = ''; $ok = '';

/* ---------- POST: create request ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $tok = $_POST['csrf'] ?? '';
  if (!hash_equals($_SESSION['csrf'], $tok)) {
    $err = 'Security token mismatch.';
  } else {
    $method = $_POST['method'] ?? 'upi';                  // upi | bank
    $amount = (int)($_POST['amount'] ?? 0);
    $upi    = trim((string)($_POST['upi'] ?? ''));
    $holder = trim((string)($_POST['holder'] ?? ''));
    $acct   = trim((string)($_POST['acct'] ?? ''));
    $ifsc   = strtoupper(trim((string)($_POST['ifsc'] ?? '')));

    // basic validate
    if (!in_array($method, ['upi','bank'], true))             $err = 'Invalid payout method.';
    elseif ($amount < $MIN)                                    $err = "Minimum withdrawal is ".fmtINR($MIN);
    elseif ($amount > $MAX)                                    $err = 'Amount too large.';
    elseif ($method==='upi'  && !preg_match('/^[A-Za-z0-9.\-_]{2,}@[A-Za-z]{2,}$/', $upi))
                                                               $err = 'Enter a valid UPI ID.';
    elseif ($method==='bank' && (!preg_match('/^\d{6,18}$/', $acct) || !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifsc)))
                                                               $err = 'Enter a valid Account No. & IFSC.';
    if (!$err) {
      try {
        $pdo->beginTransaction();

        // 1) lock user balance
        $row = $pdo->prepare("SELECT balance FROM users WHERE user_id=? FOR UPDATE");
        $row->execute([$UID]);
        $u = $row->fetch();
        if (!$u) throw new Exception('User not found.');
        $bal = (float)$u['balance'];
        if ($amount > $bal) throw new Exception('Amount exceeds available balance.');

        // 2) deduct
        $upd = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE user_id = ?");
        $upd->execute([$amount, $UID]);

        // 3) insert into withdrawals
        $t = 'withdrawals';

        // map available columns (your table has most of these)
        $c_user   = has_col($pdo,$t,'user_id')     ? 'user_id'     : null;
        $c_amount = has_col($pdo,$t,'amount')      ? 'amount'      : null;
        $c_status = has_col($pdo,$t,'status')      ? 'status'      : null;
        $c_method = has_col($pdo,$t,'method')      ? 'method'      : null;
        $c_upi    = has_col($pdo,$t,'upi_id')      ? 'upi_id'      : (has_col($pdo,$t,'upi') ? 'upi' : null);
        $c_holder = has_col($pdo,$t,'holder_name') ? 'holder_name' : (has_col($pdo,$t,'bank_holder') ? 'bank_holder' : null);
        $c_acct   = has_col($pdo,$t,'account_no')  ? 'account_no'  : (has_col($pdo,$t,'acct_no') ? 'acct_no' : (has_col($pdo,$t,'bank_account')?'bank_account':null));
        $c_ifsc   = has_col($pdo,$t,'ifsc')        ? 'ifsc'        : (has_col($pdo,$t,'bank_ifsc') ? 'bank_ifsc' : null);
        $c_oid    = has_col($pdo,$t,'order_id')    ? 'order_id'    : null;
        $c_ct     = has_col($pdo,$t,'created_at')  ? 'created_at'  : null;

        if (!$c_user || !$c_amount) throw new Exception('withdrawals table missing required columns.');

        $cols = [$c_user, $c_amount];
        $vals = [$UID, $amount];

        if ($c_status){ $cols[]=$c_status; $vals[]='pending'; }
        if ($c_method){ $cols[]=$c_method; $vals[] = ($method==='upi'?'UPI':'BANK'); }
        if ($method==='upi' && $c_upi){ $cols[]=$c_upi; $vals[]=$upi; }
        if ($method==='bank'){
          if ($c_holder && $holder!==''){ $cols[]=$c_holder; $vals[]=$holder; }
          if ($c_acct) { $cols[]=$c_acct; $vals[]=$acct; }
          if ($c_ifsc) { $cols[]=$c_ifsc; $vals[]=$ifsc; }
        }
        if ($c_oid){ $cols[]=$c_oid; $vals[] = 'WD'.date('ymdHis').mt_rand(100,999); }
        if ($c_ct) { $cols[]=$c_ct;  $vals[] = date('Y-m-d H:i:s'); }

        $place = implode(',', array_fill(0, count($cols), '?'));
        $sql = "INSERT INTO `$t` (".implode(',', $cols).") VALUES ($place)";
        $ins = $pdo->prepare($sql);
        $ins->execute($vals);

        $pdo->commit();
        $ok = "Request placed for ".fmtINR($amount).".";
      } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $err = $e->getMessage();
      }
    }
  }
}

/* ---------- fetch balance + recent ---------- */
$balNow = (float)db_cell("SELECT balance FROM users WHERE user_id=?", [$UID]);
$recent = db_all("SELECT id, amount, status, method, created_at FROM withdrawals
                  WHERE user_id=? ORDER BY id DESC LIMIT 10", [$UID]);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Withdraw – <?= htmlspecialchars(app_name()) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{--p:#8d78ff;--line:rgba(255,255,255,.12);--card:rgba(255,255,255,.08);--dim:rgba(255,255,255,.75)}
*{box-sizing:border-box} body{margin:0;font-family:Poppins,sans-serif;color:#fff;background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%)}
.app{max-width:480px;margin:auto;padding:18px 14px 100px}
.glass{background:var(--card);border:1px solid var(--line);backdrop-filter:blur(16px);border-radius:22px;padding:16px}
.form-control{background:rgba(255,255,255,.06)!important;border:1px solid var(--line)!important;color:#fff!important;border-radius:14px}
.form-control:focus{box-shadow:none;border-color:var(--p)!important}
.btn-main{background:var(--p);border:none;border-radius:16px;color:#fff;font-weight:700;padding:.9rem}
.bad{background:#ff5d71;border-radius:14px;padding:.7rem 1rem;margin:.4rem 0}
.ok{background:#16c784;border-radius:14px;padding:.7rem 1rem;margin:.4rem 0}
.item{display:flex;gap:10px;align-items:center;padding:10px;border:1px solid var(--line);border-radius:16px;background:rgba(255,255,255,.06);margin-bottom:8px}
.badge{font-size:.7rem}
</style>
</head>
<body>
<div class="app">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="m-0">Withdrawal</h5>
    <div class="glass py-1 px-2"><small>Balance</small> <b><?= htmlspecialchars(fmtINR($balNow)) ?></b></div>
  </div>

  <?php if ($err): ?><div class="bad"><?= htmlspecialchars($err) ?></div><?php endif; ?>
  <?php if ($ok):  ?><div class="ok"><?= htmlspecialchars($ok)  ?></div><?php endif; ?>

  <form method="post" class="glass mb-3">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
    <div class="mb-3">
      <label class="form-label">Amount (₹)</label>
      <input name="amount" type="number" min="<?= (int)$MIN ?>" max="<?= (int)$balNow ?>" class="form-control" required>
      <div class="form-text text-light">Min <?= fmtINR($MIN) ?>. Max <?= fmtINR($balNow) ?>.</div>
    </div>

    <div class="mb-3">
      <label class="form-label">Method</label>
      <select class="form-control" name="method" id="method">
        <option value="upi">UPI</option>
        <option value="bank">Bank</option>
      </select>
    </div>

    <div id="upiBox" class="mb-3">
      <label class="form-label">UPI ID</label>
      <input name="upi" class="form-control" placeholder="username@bank">
    </div>

    <div id="bankBox" class="mb-3" style="display:none">
      <label class="form-label">Account Holder</label>
      <input name="holder" class="form-control" placeholder="Full name">
      <div class="mt-2"></div>
      <label class="form-label">Account Number</label>
      <input name="acct" class="form-control" placeholder="1234567890">
      <div class="mt-2"></div>
      <label class="form-label">IFSC</label>
      <input name="ifsc" class="form-control" placeholder="HDFC0001234">
    </div>

    <button class="btn-main w-100 mt-2">Request Payout</button>
  </form>

  <div class="glass">
    <h6 class="mb-2">Recent Requests</h6>
    <?php if (!$recent): ?>
      <div style="opacity:.75">No requests yet.</div>
    <?php else: foreach ($recent as $r): ?>
      <div class="item">
        <div class="flex-grow-1">
          <div><b><?= htmlspecialchars(strtoupper($r['method'] ?? '')) ?></b> • <?= htmlspecialchars(fmtINR($r['amount'])) ?></div>
          <small style="opacity:.8"><?= htmlspecialchars($r['created_at'] ?? '') ?></small>
        </div>
        <?php
          $s = strtolower($r['status'] ?? 'pending');
          $cls = $s==='completed'?'bg-success':($s==='failed'?'bg-danger':'bg-warning text-dark');
        ?>
        <span class="badge <?= $cls ?>"><?= strtoupper($s) ?></span>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>

<script>
const method = document.getElementById('method');
const upiBox  = document.getElementById('upiBox');
const bankBox = document.getElementById('bankBox');
method.addEventListener('change', ()=>{
  const isBank = method.value === 'bank';
  bankBox.style.display = isBank ? '' : 'none';
  upiBox.style.display  = isBank ? 'none' : '';
});
</script>
</body>
</html>
