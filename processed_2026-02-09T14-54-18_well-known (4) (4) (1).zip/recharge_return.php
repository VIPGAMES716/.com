<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/payments/cola_client.php';
app_require_login();

$orderNo = $_GET['orderNo'] ?? $_GET['order_id'] ?? $_GET['merchantOrderNo'] ?? null;
$msg = 'Payment processing…';

if($orderNo){
  $q = cola_query_order($orderNo);
  if($q['ok']){
    $s = strtolower((string)($q['resp']['data']['status'] ?? $q['resp']['status'] ?? ''));
    if(in_array($s,['success','paid','approved'])) $msg = 'Payment successful!';
    elseif(in_array($s,['fail','failed','rejected'])) $msg = 'Payment failed.';
  }
}
?>
<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Payment Status</title>
<body style="font-family:system-ui;background:#110e25;color:#fff;text-align:center;padding:15vh 16px">
  <h3><?= htmlspecialchars($msg) ?></h3>
  <p><a href="/deposit_history.php" style="color:#8d78ff">View Deposit History</a></p>
</body>
