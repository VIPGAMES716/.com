<?php
/* admin/referrals.php — list + approve/fail + codes (Hyper Admin style) */
require_once __DIR__ . '/_boot.php';
require_admin();

$db = pdo();
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function inr($n){ return '₹'.number_format((float)$n,2); }

/* ---------- ensure tables exist (safe to re-run) ---------- */
$db->exec("CREATE TABLE IF NOT EXISTS referral_codes(
  user_id    VARCHAR(64) PRIMARY KEY,
  code       VARCHAR(32) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$db->exec("CREATE TABLE IF NOT EXISTS referrals(
  id INT AUTO_INCREMENT PRIMARY KEY,
  referrer_id     VARCHAR(64) NOT NULL,
  referred_id     VARCHAR(64) DEFAULT NULL,
  referred_mobile VARCHAR(32) DEFAULT NULL,
  status ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  note   VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY (referrer_id), KEY (referred_id), KEY (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* ---------- actions (atomic; one-time) ---------- */
function mark_paid(PDO $db, int $id): array {
  try{
    $db->beginTransaction();
    $st = $db->prepare("SELECT * FROM referrals WHERE id=? FOR UPDATE");
    $st->execute([$id]);
    $r = $st->fetch(PDO::FETCH_ASSOC);
    if(!$r){ $db->rollBack(); return [false,"Referral not found"]; }
    if($r['status']!=='pending'){ $db->rollBack(); return [false,"Already {$r['status']}"]; }

    // credit wallet (requires users.balance)
    $db->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?")
       ->execute([(float)$r['amount'], (string)$r['referrer_id']]);

    $db->prepare("UPDATE referrals SET status='paid', note=CONCAT(COALESCE(note,''),' | paid by admin') WHERE id=?")
       ->execute([$id]);

    $db->commit();
    return [true,"Paid ₹".number_format((float)$r['amount'],2)." to ".$r['referrer_id']];
  } catch(Throwable $e){
    if($db->inTransaction()) $db->rollBack();
    return [false,$e->getMessage()];
  }
}
function mark_failed(PDO $db, int $id): array {
  try{
    $db->beginTransaction();
    $st = $db->prepare("SELECT status FROM referrals WHERE id=? FOR UPDATE");
    $st->execute([$id]);
    $r = $st->fetch(PDO::FETCH_ASSOC);
    if(!$r){ $db->rollBack(); return [false,"Referral not found"]; }
    if($r['status']!=='pending'){ $db->rollBack(); return [false,"Already {$r['status']}"]; }
    $db->prepare("UPDATE referrals SET status='failed', note=CONCAT(COALESCE(note,''),' | failed by admin') WHERE id=?")
       ->execute([$id]);
    $db->commit();
    return [true,"Marked failed"];
  } catch(Throwable $e){
    if($db->inTransaction()) $db->rollBack();
    return [false,$e->getMessage()];
  }
}

/* ---------- POST ---------- */
$flash='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $act = $_POST['action'] ?? '';
  $id  = (int)($_POST['id'] ?? 0);
  if($id>0){
    [$ok,$flash] = $act==='pay' ? mark_paid($db,$id)
               : ($act==='fail'? mark_failed($db,$id) : [false,'Invalid action']);
  }
}

/* ---------- filters ---------- */
$tab    = $_GET['tab'] ?? 'referrals'; // referrals|codes
$stat   = strtolower($_GET['status'] ?? 'pending'); // for referrals
$search = trim((string)($_GET['q'] ?? ''));
$from   = trim((string)($_GET['from'] ?? ''));
$to     = trim((string)($_GET['to'] ?? ''));

/* ---------- load data ---------- */
$cards = [
  'pending' => (int)$db->query("SELECT COUNT(*) FROM referrals WHERE status='pending'")->fetchColumn(),
  'paid'    => (int)$db->query("SELECT COUNT(*) FROM referrals WHERE status='paid'")->fetchColumn(),
  'failed'  => (int)$db->query("SELECT COUNT(*) FROM referrals WHERE status='failed'")->fetchColumn(),
  'amount'  => (float)$db->query("SELECT COALESCE(SUM(amount),0) FROM referrals WHERE status='paid'")->fetchColumn(),
];

$where=[]; $args=[];
if($search!==''){
  $where[]="(referrer_id LIKE ? OR referred_id LIKE ? OR referred_mobile LIKE ?)";
  $args[]= "%$search%"; $args[]="%$search%"; $args[]="%$search%";
}
if($from!==''){ $where[]="DATE(created_at) >= ?"; $args[]=$from; }
if($to!==''){   $where[]="DATE(created_at) <= ?"; $args[]=$to;   }
if(in_array($stat,['pending','paid','failed'],true)){ $where[]="status=?"; $args[]=$stat; }

$sqlWhere = $where?('WHERE '.implode(' AND ',$where)) : '';

$rows = $db->prepare("SELECT * FROM referrals $sqlWhere ORDER BY id DESC LIMIT 500");
$rows->execute($args);
$refs = $rows->fetchAll(PDO::FETCH_ASSOC);

$codes = $db->query("SELECT rc.user_id, rc.code, rc.created_at,
                    (SELECT COUNT(*) FROM referrals r WHERE r.referrer_id=rc.user_id) AS total_refs,
                    (SELECT COUNT(*) FROM referrals r WHERE r.referrer_id=rc.user_id AND r.status='paid') AS paid_refs,
                    (SELECT COALESCE(SUM(amount),0) FROM referrals r WHERE r.referrer_id=rc.user_id AND r.status='paid') AS paid_sum
                    FROM referral_codes rc ORDER BY rc.created_at DESC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin • Referrals</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{
  --bg:#0b0a12; --bg2:#141225; --line:rgba(255,255,255,.12); --p:#8d78ff; --txt:#fff;
  --ok:#1bd89b; --warn:#ffd166; --err:#ff5d71;
}
*{box-sizing:border-box}
body{margin:0;color:var(--txt);background:
  radial-gradient(1100px 600px at 10% -10%,#2d2570 0%,#0b0a12 60%);font-family:Poppins}
.container{max-width:1200px;margin:16px auto;padding:0 12px}
.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
.title{font-weight:800;font-size:1.55rem;display:flex;align-items:center;gap:.6rem}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:10px 0 16px}
.card{background:rgba(255,255,255,.06);border:1px solid var(--line);border-radius:16px;padding:12px}
.card small{opacity:.78}
.card b{display:block;font-size:1.15rem;margin-top:4px}
.toolbar{display:flex;gap:8px;flex-wrap:wrap;background:rgba(255,255,255,.06);
  border:1px solid var(--line);border-radius:14px;padding:10px;margin-bottom:12px}
.tabs a{padding:.5rem .9rem;border-radius:999px;border:1px solid var(--line);text-decoration:none;color:#fff;background:rgba(255,255,255,.06)}
.tabs a.active{background:#3a3294;border-color:#5b4cf4;box-shadow:0 10px 30px rgba(141,120,255,.35)}
input,select{background:rgba(255,255,255,.05);border:1px solid var(--line);color:#fff;border-radius:10px;padding:.5rem .6rem}
.btn{border:1px solid var(--line);border-radius:10px;background:rgba(255,255,255,.08);color:#fff;padding:.5rem .8rem;font-weight:800}
.btn-approve{background:linear-gradient(135deg,#0ea37e,#15d19b);border:none;color:#041b15}
.btn-fail{border:1px solid #8f3a3a;color:#ffb3b3}
.table{width:100%;border-collapse:collapse}
.table th,.table td{border-bottom:1px solid var(--line);padding:10px;text-align:left;vertical-align:middle}
.badge{padding:.18rem .52rem;border-radius:999px;font-size:.72rem;font-weight:800;border:1px solid var(--line)}
.s-p{background:#2b1d00;color:#ffd98a;border-color:#7b5c00}
.s-paid{background:#05251a;color:#bff8d8;border-color:#1e765a}
.s-fail{background:#2e1111;color:#ffb3b3;border-color:#8f3a3a}
.note{opacity:.8;font-size:.85rem}
</style>
</head>
<body>
<div class="container">
  <div class="head">
    <div class="title"><i class="bi bi-people"></i> Referrals</div>
    <div class="tabs">
      <a href="?tab=referrals" class="<?= $tab==='referrals'?'active':'' ?>">Referrals</a>
      <a href="?tab=codes" class="<?= $tab==='codes'?'active':'' ?>">Referral Codes</a>
    </div>
  </div>

  <?php if($flash): ?>
    <div class="card" style="border-color:#5b4cf4"><?= h($flash) ?></div>
  <?php endif; ?>

  <?php if($tab==='referrals'): ?>
    <div class="cards">
      <div class="card"><small>Pending</small><b><?= (int)$cards['pending'] ?></b></div>
      <div class="card"><small>Paid</small><b><?= (int)$cards['paid'] ?></b></div>
      <div class="card"><small>Failed</small><b><?= (int)$cards['failed'] ?></b></div>
      <div class="card"><small>Total Paid Amount</small><b><?= inr($cards['amount']) ?></b></div>
    </div>

    <form class="toolbar" method="get">
      <input type="hidden" name="tab" value="referrals">
      <select name="status">
        <?php foreach(['pending'=>'Pending','paid'=>'Paid','failed'=>'Failed','all'=>'All'] as $k=>$v): ?>
          <option value="<?=$k?>" <?= $k===$stat?'selected':'' ?>><?=$v?></option>
        <?php endforeach; ?>
      </select>
      <input name="q" value="<?=h($search)?>" placeholder="Search referrer / referred / mobile">
      <input type="date" name="from" value="<?=h($from)?>">
      <input type="date" name="to"   value="<?=h($to)?>">
      <button class="btn"><i class="bi bi-search"></i> Filter</button>
    </form>

    <div class="panel">
      <table class="table">
        <thead>
          <tr>
            <th style="width:80px">#ID</th>
            <th>Referrer</th>
            <th>Referred</th>
            <th style="width:120px">Amount</th>
            <th style="width:120px">Status</th>
            <th style="width:170px">Date</th>
            <th style="width:210px" class="text-end">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!$refs): ?>
          <tr><td colspan="7" class="note">No records.</td></tr>
        <?php else: foreach($refs as $r): $cls = $r['status']==='pending'?'s-p':($r['status']==='paid'?'s-paid':'s-fail'); ?>
          <tr>
            <td>#<?= (int)$r['id'] ?></td>
            <td><b><?= h($r['referrer_id']) ?></b></td>
            <td><?= h($r['referred_id'] ?: ($r['referred_mobile'] ?: '—')) ?></td>
            <td><?= inr($r['amount']) ?></td>
            <td><span class="badge <?= $cls ?>"><?= strtoupper($r['status']) ?></span></td>
            <td><?= h($r['created_at']) ?></td>
            <td>
              <?php if($r['status']==='pending'): ?>
                <form method="post" style="display:inline-block">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="action" value="pay">
                  <button class="btn-approve"><i class="bi bi-check2-circle"></i> Mark Paid</button>
                </form>
                <form method="post" style="display:inline-block" onsubmit="return confirm('Mark as failed?');">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="action" value="fail">
                  <button class="btn btn-fail"><i class="bi bi-x-circle"></i> Fail</button>
                </form>
              <?php else: ?>
                <span class="note">Processed</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="toolbar">
      <div class="note"><i class="bi bi-info-circle"></i> This list shows every user’s referral code and performance.</div>
    </div>
    <div class="panel">
      <table class="table">
        <thead>
          <tr>
            <th>User ID</th>
            <th>Code</th>
            <th style="width:160px">Created</th>
            <th style="width:120px">Total</th>
            <th style="width:120px">Paid</th>
            <th style="width:140px">Paid Amount</th>
            <th>Invite Link</th>
          </tr>
        </thead>
        <tbody>
          <?php if(!$codes): ?>
            <tr><td colspan="7" class="note">No codes yet.</td></tr>
          <?php else: foreach($codes as $c): 
            $link = ( (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https':'http' ).'://'.($_SERVER['HTTP_HOST']??'localhost').'/register.php?ref='.rawurlencode($c['code']); ?>
            <tr>
              <td><b><?= h($c['user_id']) ?></b></td>
              <td><?= h($c['code']) ?></td>
              <td><?= h($c['created_at']) ?></td>
              <td><?= (int)$c['total_refs'] ?></td>
              <td><?= (int)$c['paid_refs'] ?></td>
              <td><?= inr($c['paid_sum']) ?></td>
              <td><input style="width:100%;max-width:420px" value="<?= h($link) ?>" readonly></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<script>
// disable double clicks on action forms
document.querySelectorAll('form[method="post"]').forEach(f=>{
  f.addEventListener('submit', e=>{
    const btn=f.querySelector('button'); if(btn){ btn.disabled=true; btn.style.opacity=.7; }
  });
});
</script>
</body>
</html>
