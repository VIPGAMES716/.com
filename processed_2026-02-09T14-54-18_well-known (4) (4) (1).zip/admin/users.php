<?php
require_once __DIR__.'/_boot.php';
require_admin();
$db = pdo();

if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));

$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='adjust' && hash_equals($_SESSION['csrf'], $_POST['csrf']??'')) {
  $uid  = trim((string)($_POST['user_id'] ?? ''));
  $mode = $_POST['mode'] ?? 'credit'; // credit|debit
  $amt  = (float)($_POST['amount'] ?? 0);
  if ($uid!=='' && $amt>0) {
    if ($mode==='debit') {
      $st=$db->prepare("UPDATE users SET balance = GREATEST(0, balance - ?) WHERE user_id=?");
      $st->execute([$amt,$uid]);
      $msg = "Debited ₹".number_format($amt,2)." from $uid";
    } else {
      $st=$db->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?");
      $st->execute([$amt,$uid]);
      $msg = "Credited ₹".number_format($amt,2)." to $uid";
    }
  }
  header("Location: users.php?ok=".urlencode($msg)); exit;
}

$q = trim($_GET['q'] ?? '');
$sql = "SELECT id,user_id,name,role,balance,created_at FROM users";
$args=[]; if($q!==''){ $sql.=" WHERE user_id LIKE ? OR name LIKE ?"; $args=["%$q%","%$q%"]; }
$sql.=" ORDER BY id DESC LIMIT 120";
$rows = $db->prepare($sql); $rows->execute($args); $rows=$rows->fetchAll();

function inr($n){ return '₹'.number_format((float)$n,2); }
?>
<!doctype html><html><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Users</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#0b0a12;--line:rgba(255,255,255,.12);--p:#8d78ff;--ok:#16c784;--err:#ff5d71}
*{box-sizing:border-box}body{margin:0;color:#fff;background:radial-gradient(1000px 560px at 10% -10%,#2d2570 0%,#0b0a12 60%);font-family:Poppins}
.wrap{max-width:1100px;margin:0 auto;padding:16px}
.h{font-weight:800;font-size:1.35rem;margin-bottom:10px}
.bar{display:flex;gap:8px;margin-bottom:10px}
input,select{padding:.75rem .9rem;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.06);color:#fff}
input[name=q]{flex:1}
.btn{border:none;border-radius:12px;padding:.78rem 1rem;background:#8d78ff;color:#fff;font-weight:700}
.table{width:100%;border-collapse:separate;border-spacing:0 8px}
th,td{padding:8px 10px} th{color:rgba(255,255,255,.75);text-align:left}
tr.data{background:#141225;border:1px solid var(--line);border-radius:12px}
.act{display:flex;gap:6px;align-items:center}
.badge{padding:.18rem .52rem;border-radius:999px;font-size:.72rem;font-weight:800;border:1px solid var(--line)}
.ok{background:#0f2f22;color:#bff8d8;border-color:#1c815d}
.note{margin:8px 0 0 2px;color:#bbb}
</style>
</head><body><div class="wrap">
  <div class="h">Users</div>

  <?php if(!empty($_GET['ok'])): ?>
    <div style="background:rgba(16,199,132,.15);border:1px solid #1c815d;padding:.7rem .9rem;border-radius:12px;margin-bottom:8px"><?=htmlspecialchars($_GET['ok'])?></div>
  <?php endif; ?>

  <form class="bar" method="get">
    <input name="q" placeholder="Search user id / name" value="<?=htmlspecialchars($q)?>">
    <button class="btn">Search</button>
  </form>

  <!-- Credit / Debit box -->
  <form class="bar" method="post" style="margin-top:-2px">
    <input type="hidden" name="csrf" value="<?=$_SESSION['csrf']?>">
    <input type="hidden" name="action" value="adjust">
    <select name="mode" title="Mode">
      <option value="credit">Credit</option>
      <option value="debit">Debit</option>
    </select>
    <input name="user_id" placeholder="User ID (exact)" required>
    <input name="amount" type="number" step="0.01" min="0.01" placeholder="Amount" required>
    <button class="btn">Apply</button>
  </form>
  <div class="note">One-time update (PRG safe). Balance column is directly updated in <b>users.balance</b>.</div>

  <table class="table" style="margin-top:10px">
    <thead><tr><th>ID</th><th>User ID</th><th>Name</th><th>Role</th><th>Balance</th><th>Joined</th><th>Links</th></tr></thead>
    <tbody>
      <?php foreach($rows as $u): ?>
        <tr class="data">
          <td>#<?=$u['id']?></td>
          <td style="font-weight:700"><?=htmlspecialchars($u['user_id'])?></td>
          <td><?=htmlspecialchars($u['name']??'')?></td>
          <td><?=strtoupper($u['role']??'user')?></td>
          <td><span class="badge ok"><?=inr($u['balance']??0)?></span></td>
          <td style="opacity:.8"><?=htmlspecialchars($u['created_at'])?></td>
          <td class="act">
            <a class="btn" style="padding:.45rem .7rem" href="deposits.php?uid=<?=urlencode($u['user_id'])?>">Deposits</a>
            <a class="btn" style="padding:.45rem .7rem" href="withdraws.php?uid=<?=urlencode($u['user_id'])?>">Withdrawals</a>
          </td>
        </tr>
      <?php endforeach; if(!$rows): ?>
        <tr class="data"><td colspan="7" style="opacity:.7">No users found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div></body></html>
