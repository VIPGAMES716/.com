<?php
require_once __DIR__.'/_boot.php';
require_admin();
$db = pdo();

/* ---------- CSRF ---------- */
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$CSRF = $_SESSION['csrf'];

/* ---------- Actions ---------- */
if ($_SERVER['REQUEST_METHOD']==='POST' && hash_equals($CSRF, $_POST['csrf'] ?? '')) {
  $act = $_POST['action'] ?? '';
  if ($act === 'reply') {
    $ticket_id = (int)($_POST['ticket_id'] ?? 0);
    $msg       = trim((string)($_POST['message'] ?? ''));
    if ($ticket_id && $msg !== '') {
      $q = $db->prepare("INSERT INTO support_replies (ticket_id,admin_id,user_id,message,created_at)
                         VALUES (?,?,?,?,NOW())");
      $q->execute([$ticket_id, (int)($_SESSION['admin_id'] ?? 0), null, $msg]);
      $db->prepare("UPDATE support_tickets SET updated_at = NOW() WHERE id=?")->execute([$ticket_id]);
    }
    header("Location: tickets.php?id=".$ticket_id."&status=".urlencode($_GET['status'] ?? 'open')); exit;
  }
  if ($act === 'set_status') {
    $ticket_id = (int)($_POST['ticket_id'] ?? 0);
    $status    = $_POST['status'] ?? 'open';
    if ($ticket_id && in_array($status, ['open','pending','closed'], true)) {
      $db->prepare("UPDATE support_tickets SET status=?, updated_at=NOW() WHERE id=?")
         ->execute([$status, $ticket_id]);
    }
    header("Location: tickets.php?id=".$ticket_id."&status=".urlencode($status)); exit;
  }
}

/* ---------- Query lists ---------- */
$filter = $_GET['status'] ?? 'open';
if (!in_array($filter,['open','pending','closed','all'],true)) $filter='open';
$where  = ($filter==='all') ? '1=1' : 'status = ?';
$args   = ($filter==='all') ? []    : [$filter];

$L = $db->prepare("SELECT id,user_id,subject,status,updated_at
                   FROM support_tickets
                   WHERE $where
                   ORDER BY updated_at DESC, id DESC
                   LIMIT 200");
$L->execute($args);
$list = $L->fetchAll();

$tid = (int)($_GET['id'] ?? 0);
$ticket = null; $replies = [];
if ($tid) {
  $s = $db->prepare("SELECT * FROM support_tickets WHERE id=? LIMIT 1");
  $s->execute([$tid]); $ticket = $s->fetch();
  if ($ticket) {
    $r = $db->prepare("SELECT * FROM support_replies WHERE ticket_id=? ORDER BY id ASC");
    $r->execute([$tid]); $replies = $r->fetchAll();
  }
}
function h($s){ return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Admin • Tickets</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{
  --bg:#090711; --bg2:#0f0d1f; --glass:rgba(255,255,255,.06); --line:rgba(255,255,255,.12);
  --ring:rgba(141,120,255,.35); --txt:#f8f8ff; --muted:rgba(255,255,255,.78);
  --vio:#8d78ff; --vio2:#5b4cf4; --ok:#16c784; --warn:#ffd166; --err:#ff5d71;
  --chip:#1a1730; --chip-ring:#2a2470;
}
*{box-sizing:border-box} html,body{height:100%}
body{
  margin:0;color:var(--txt);font-family:Poppins,system-ui,Segoe UI;
  background:
    radial-gradient(1200px 620px at 20% -15%, #3a3398 0%, transparent 65%),
    radial-gradient(900px 520px at 110% 0%, #7a2d7b 0%, transparent 60%),
    var(--bg);
}
.wrap{max-width:1280px;margin:0 auto;padding:18px}

/* Header */
.header{display:flex;align-items:center;gap:16px;justify-content:space-between;margin-bottom:12px}
.title{font-weight:800;font-size:1.6rem;letter-spacing:.2px}
.tabs{display:flex;gap:10px;flex-wrap:wrap}
.tab{
  display:inline-flex;align-items:center;gap:.45rem;
  padding:.6rem 1rem;border:1px solid var(--line);border-radius:999px;background:var(--glass);
  color:#fff;text-decoration:none;font-weight:800
}
.tab i{font-size:1rem;opacity:.85}
.tab.active{background:linear-gradient(135deg,#473cff,#a689ff);border-color:#6b5aff;box-shadow:0 10px 28px var(--ring)}
.tab:hover{box-shadow:0 6px 18px var(--ring)}

/* Layout */
.layout{display:grid;grid-template-columns:390px 1fr;gap:16px}
@media(max-width:1020px){.layout{grid-template-columns:1fr}}

/* Card / glass */
.card{
  background:var(--glass);border:1px solid var(--line);border-radius:20px;backdrop-filter:blur(18px);overflow:hidden;position:relative
}
.card:before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;box-shadow:0 0 28px var(--ring) inset}

/* Search chip (for future) */
.chips{display:flex;gap:8px;padding:10px;border-bottom:1px solid var(--line);background:linear-gradient(180deg,var(--bg2),transparent)}
.chip{padding:.38rem .7rem;border:1px solid var(--line);border-radius:999px;background:var(--chip);color:#cfcfff;font-size:.8rem}
.badge{padding:.28rem .65rem;border-radius:999px;font-size:.72rem;font-weight:800;border:1px solid var(--line)}
.badge-open{background:#2b1d00;color:#ffd98a;border-color:#806400}
.badge-pending{background:#0f223b;color:#bcd6ff;border-color:#3f6aa0}
.badge-closed{background:#05251a;color:#bff8d8;border-color:#2a7f61}

/* Ticket list */
.list{max-height:74vh;overflow:auto}
.item{display:flex;justify-content:space-between;gap:10px;padding:12px 14px;border-bottom:1px solid var(--line);text-decoration:none;color:#fff}
.item:hover{background:rgba(255,255,255,.055)}
.subject{font-weight:800}
.meta{color:var(--muted);font-size:.78rem}

/* Right side */
.head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px;border-bottom:1px solid var(--line)}
.head .title2{font-weight:800;font-size:1.05rem}
.select{background:var(--glass);color:#fff;border:1px solid var(--line);border-radius:12px;padding:.55rem .8rem}
.save{background:linear-gradient(135deg,#5d45ff,#a486ff);border:none;color:#fff;border-radius:12px;padding:.7rem 1rem;font-weight:800}
.save:active{transform:translateY(1px)}

.msgs{
  height:calc(74vh - 150px);overflow:auto;padding:16px;display:flex;flex-direction:column;gap:12px;
  background:linear-gradient(180deg,var(--bg2) 0,var(--bg) 100%)
}
.row{display:flex;gap:10px;align-items:flex-end}
.avatar{
  width:34px;height:34px;border-radius:50%;background:#221e44;border:1px solid var(--chip-ring);
  display:grid;place-items:center;font-size:.75rem;color:#cfcfff;flex:0 0 34px
}
.bubble{
  max-width:78%;padding:10px 12px;border-radius:16px;border:1px solid var(--line);line-height:1.55;
  box-shadow:0 6px 18px rgba(0,0,0,.25)
}
.user{background:#151a25}
.admin{background:linear-gradient(135deg,#5e49ff,#8f7dff);color:#fff;margin-left:auto}
.stamp{display:inline-block;margin-top:6px;font-size:.73rem;color:#cbd0ff;opacity:.9}

/* Composer */
.composer{display:flex;gap:10px;border-top:1px solid var(--line);padding:12px;background:rgba(0,0,0,.25);position:sticky;bottom:0}
textarea{
  flex:1;resize:none;height:96px;padding:.85rem;border-radius:14px;background:var(--glass);color:#fff;border:1px solid var(--line);
  outline:none
}
textarea:focus{box-shadow:0 0 0 4px rgba(141,120,255,.18)}
.send{background:linear-gradient(135deg,#6b5aff,#b09bff);border:none;color:#fff;border-radius:14px;padding:.95rem 1.1rem;font-weight:800}
.send:active{transform:translateY(1px)}
.hint{font-size:.74rem;color:var(--muted);margin-left:auto;align-self:center}
.empty{padding:24px 16px;color:var(--muted)}
</style>
</head>
<body>
<div class="wrap">

  <div class="header">
    <div class="title"><i class="bi bi-life-preserver"></i> Support Tickets</div>
    <div class="tabs">
      <?php $cur=$filter;
      $icons=['open'=>'bi-inbox','pending'=>'bi-hourglass','closed'=>'bi-check2-circle','all'=>'bi-ui-checks-grid'];
      foreach(['open'=>'Open','pending'=>'Pending','closed'=>'Closed','all'=>'All'] as $k=>$v): ?>
        <a class="tab <?= $cur===$k?'active':'' ?>" href="?status=<?=$k?>">
          <i class="bi <?=$icons[$k]?>"></i><?=$v?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="layout">
    <!-- LEFT: list -->
    <div class="card">
      <div class="chips">
        <span class="chip"><i class="bi bi-filter"></i> Filter: <b style="margin-left:.3rem"><?=ucfirst($cur)?></b></span>
        <span class="chip"><i class="bi bi-collection"></i> <?=count($list)?> tickets</span>
      </div>
      <div class="list">
        <?php foreach($list as $t):
          $b = $t['status']==='closed'?'badge-closed':($t['status']==='pending'?'badge-pending':'badge-open'); ?>
          <a class="item" href="?status=<?=h($cur)?>&id=<?=$t['id']?>">
            <div>
              <div class="subject">#<?=$t['id']?> • <?=h($t['subject'] ?: 'No subject')?></div>
              <div class="meta">User: <?=h($t['user_id'])?> • Updated: <?=h($t['updated_at'])?></div>
            </div>
            <span class="badge <?=$b?>"><?=strtoupper($t['status'])?></span>
          </a>
        <?php endforeach; if(!$list): ?>
          <div class="empty">No tickets in this filter.</div>
        <?php endif; ?>
      </div>
    </div>

    <!-- RIGHT: detail -->
    <div class="card">
      <?php if(!$ticket): ?>
        <div class="head"><span class="title2">Select a ticket from the left to view & reply</span></div>
        <div class="empty" style="padding:22px">Tip: Use the tabs to switch between <b>Open</b>, <b>Pending</b>, and <b>Closed</b> tickets.</div>
      <?php else: ?>
        <div class="head">
          <div>
            <div class="title2">Ticket #<?=$ticket['id']?> • User: <?=h($ticket['user_id'])?></div>
            <div class="meta" style="margin-top:2px"><?=h($ticket['subject'])?></div>
          </div>
          <form method="post" style="display:flex;gap:10px;align-items:center">
            <input type="hidden" name="csrf" value="<?=$CSRF?>">
            <input type="hidden" name="action" value="set_status">
            <input type="hidden" name="ticket_id" value="<?=$ticket['id']?>">
            <select name="status" class="select">
              <?php foreach(['open','pending','closed'] as $st): ?>
                <option value="<?=$st?>" <?=$ticket['status']===$st?'selected':''?>><?=ucfirst($st)?></option>
              <?php endforeach; ?>
            </select>
            <button class="save"><i class="bi bi-save2"></i> Save</button>
          </form>
        </div>

        <div class="msgs" id="msgs">
          <!-- Opening message -->
          <div class="row">
            <div class="avatar">U</div>
            <div class="bubble user">
              <?= nl2br(h((string)$ticket['message'])) ?>
              <div class="stamp">Opened • <?=h($ticket['created_at'])?></div>
            </div>
          </div>

          <!-- Replies -->
          <?php foreach($replies as $rp): $isAdmin=!empty($rp['admin_id']); ?>
            <?php if($isAdmin): ?>
              <div class="row" style="justify-content:flex-end">
                <div class="bubble admin">
                  <?= nl2br(h($rp['message'])) ?>
                  <div class="stamp">Admin • <?=h($rp['created_at'])?></div>
                </div>
                <div class="avatar" style="background:#2b2660;color:#fff;border-color:#4c43a9">A</div>
              </div>
            <?php else: ?>
              <div class="row">
                <div class="avatar">U</div>
                <div class="bubble user">
                  <?= nl2br(h($rp['message'])) ?>
                  <div class="stamp">User • <?=h($rp['created_at'])?></div>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>

        <!-- Composer -->
        <form class="composer" method="post" id="replyForm">
          <input type="hidden" name="csrf" value="<?=$CSRF?>">
          <input type="hidden" name="action" value="reply">
          <input type="hidden" name="ticket_id" value="<?=$ticket['id']?>">
          <textarea name="message" id="msgBox" placeholder="Type your reply…" required></textarea>
          <button class="send"><i class="bi bi-send-fill"></i> Send</button>
          <div class="hint">Ctrl + Enter</div>
        </form>

        <script>
          // auto-scroll
          (function(){const m=document.getElementById('msgs'); if(m){ m.scrollTop=m.scrollHeight; }})();
          // Ctrl+Enter to send
          (function(){
            const ta=document.getElementById('msgBox'), f=document.getElementById('replyForm');
            if(!ta||!f) return;
            ta.addEventListener('keydown', e=>{
              if((e.ctrlKey||e.metaKey) && e.key==='Enter'){ e.preventDefault(); f.submit(); }
            });
          })();
        </script>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
