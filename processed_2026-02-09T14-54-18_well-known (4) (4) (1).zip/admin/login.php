<?php
require_once __DIR__ . '/_boot.php';
if (admin_logged_in()) { header('Location: dashboard.php'); exit; }

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $login = trim((string)($_POST['login'] ?? ''));
  $pass  = (string)($_POST['password'] ?? '');

  // Build WHERE from available columns (username/phone/email)
  $wheres = [];
  $args   = [];
  if (has_col('admin_users','username')) { $wheres[] = 'username = ?'; $args[] = $login; }
  if (has_col('admin_users','phone'))    { $wheres[] = 'phone    = ?'; $args[] = $login; }
  if (has_col('admin_users','email'))    { $wheres[] = 'email    = ?'; $args[] = $login; }

  if (!$wheres) {
    $msg = 'Admin auth not configured (no username/phone/email columns).';
  } else {
    $sql = "SELECT id,
                   ".(has_col('admin_users','username')?'username':'"" AS username').",
                   ".(has_col('admin_users','name')    ?'name'    :'"" AS name').",
                   ".(has_col('admin_users','role')    ?'role'    :'"" AS role').",
                   password_hash
            FROM admin_users
            WHERE (".implode(' OR ', $wheres).")
            LIMIT 1";
    $st = pdo()->prepare($sql);
    $st->execute($args);
    $u = $st->fetch(PDO::FETCH_ASSOC);

    if ($u && !empty($u['password_hash']) && password_verify($pass, $u['password_hash'])) {
      $_SESSION['admin_id']   = (int)$u['id'];
      $_SESSION['admin_name'] = $u['name'] ?: ($u['username'] ?: 'admin');
      $_SESSION['admin_role'] = $u['role'] ?: 'admin';
      header('Location: dashboard.php'); exit;
    } else {
      $msg = 'Invalid credentials';
    }
  }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<title>Admin Login – <?= h(app_name_safe()) ?></title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{--p:#8d78ff;--card:rgba(255,255,255,.08);--line:rgba(255,255,255,.12);--dim:rgba(255,255,255,.74);}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;color:#fff;font-family:Poppins,system-ui,Segoe UI,Arial;
  background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);overflow:hidden}
body::after{content:"";position:fixed;inset:0;opacity:.05;pointer-events:none;mix-blend-mode:overlay;
  background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png')}
.wrap{display:grid;place-items:center;min-height:100vh;padding:1rem}
.cardx{width:100%;max-width:420px;background:var(--card);backdrop-filter:blur(16px);
  border:1px solid var(--line);border-radius:24px;padding:1.3rem}
.brand{font-weight:700;font-size:1.45rem}
.sub{font-size:.84rem;color:var(--dim)}
.form-control{background:rgba(255,255,255,.06)!important;color:#fff!important;border-radius:14px;
  border:1px solid var(--line)!important;padding:.85rem 1rem}
.form-control:focus{box-shadow:none;border-color:var(--p)!important}
.btn-main{background:var(--p);border:none;border-radius:14px;font-weight:700;padding:.8rem 1rem}
.alert{border-radius:14px;border:none}
.note{font-size:.78rem;color:var(--dim);text-align:center}
</style>
</head>
<body>
  <div class="wrap">
    <div class="cardx">
      <div class="text-center mb-2">
        <div class="brand">Admin Login</div>
        <div class="sub">Use username / phone / email</div>
      </div>

      <?php if ($msg): ?>
        <div class="alert alert-danger py-2 px-3 text-center"><?= h($msg) ?></div>
      <?php endif; ?>

      <form method="post" autocomplete="off">
        <div class="mb-3">
          <label class="form-label">Login</label>
          <input name="login" class="form-control" placeholder="HYPER / 9905854332 / email@example.com" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input name="password" type="password" class="form-control" placeholder="••••••••" required>
        </div>
        <button class="btn btn-main w-100">Login</button>
      </form>

      <div class="note mt-3">
        First time here? We auto-created <b>HYPER</b> / <b>1234567890</b> with your password.
      </div>
    </div>
  </div>
</body>
</html>