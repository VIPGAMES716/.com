<?php
require_once __DIR__.'/_boot.php';
require_admin();
$db = pdo();

$err=''; $ok='';

if($_SERVER['REQUEST_METHOD']==='POST'){
  $action = $_POST['action'] ?? '';
  if($action==='create'){
    $code = trim($_POST['code'] ?? '');
    $amt  = (float)($_POST['reward_amount'] ?? 0);
    $max  = (int)($_POST['max_uses'] ?? 0);
    $pusr = (int)($_POST['per_user_limit'] ?? 1);
    $sa   = $_POST['starts_at'] ?: null;
    $ea   = $_POST['ends_at']   ?: null;
    $act  = isset($_POST['is_active']) ? 1 : 0;

    if($code==='' || $amt<=0){ $err='Code & amount required'; }
    else{
      $st=$db->prepare("INSERT INTO promo_codes(code,reward_amount,max_uses,per_user_limit,starts_at,ends_at,is_active,created_at)
                        VALUES(?,?,?,?,?,?,?,NOW())");
      $st->execute([$code,$amt,$max,$pusr,$sa,$ea,$act]);
      $ok='Gift code created';
    }
  } elseif($action==='toggle' && !empty($_POST['id'])){
    $id=(int)$_POST['id']; $st=$db->prepare("UPDATE promo_codes SET is_active=1-is_active WHERE id=?"); $st->execute([$id]); $ok='Toggled';
  } elseif($action==='delete' && !empty($_POST['id'])){
    $id=(int)$_POST['id']; $db->prepare("DELETE FROM promo_codes WHERE id=?")->execute([$id]); $ok='Deleted';
  }
}

$rows = $db->query("SELECT * FROM promo_codes ORDER BY id DESC LIMIT 100")->fetchAll();
function inr($n){ return '₹'.number_format((float)$n,2); }
?>
<!doctype html><html><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Gift Codes</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{ --bg:#0b0a12; --line:rgba(255,255,255,.12); --p:#8d78ff; }
*{box-sizing:border-box} body{margin:0;color:#fff;background:radial-gradient(1000px 560px at 10% -10%,#2d2570 0%,#0b0a12 60%);font-family:Poppins}
.wrap{max-width:1100px;margin:0 auto;padding:18px}
.h{font-weight:800;font-size:1.35rem;margin-bottom:12px}
.panel{background:rgba(255,255,255,.06);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:12px;position:relative}
.panel::after{content:"";position:absolute;inset:0;border-radius:16px;box-shadow:0 0 30px rgba(141,120,255,.25);pointer-events:none}
.row{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}
input,select{width:100%;padding:.72rem .9rem;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.06);color:#fff}
.btn{border:none;border-radius:12px;padding:.8rem 1rem;background:#8d78ff;color:#fff;font-weight:700}
.table{width:100%;border-collapse:separate;border-spacing:0 8px}
th,td{padding:8px 10px} th{color:rgba(255,255,255,.75);text-align:left}
tr.data{background:#141225;border:1px solid var(--line);border-radius:12px}
.badge{padding:.18rem .52rem;border-radius:999px;font-size:.74rem;font-weight:800;border:1px solid var(--line)}
.ok{background:#12281f;color:#bff8d8;border-color:#1c815d}
.off{background:#2a1625;color:#ffb3c1;border-color:#93374b}
.act{display:flex;gap:6px}
.note{margin:8px 0 0 2px;color:#bbb}
.mtop{margin-top:10px}
</style>
</head><body><div class="wrap">
  <div class="h">Gift Codes</div>

  <?php if($err): ?><div class="panel" style="border-color:#93374b;color:#ffb3c1"><?=htmlspecialchars($err)?></div><?php endif; ?>
  <?php if($ok):  ?><div class="panel" style="border-color:#1c815d;color:#bff8d8"><?=htmlspecialchars($ok)?></div><?php endif; ?>

  <div class="panel">
    <div style="font-weight:700;margin-bottom:8px">Create Code</div>
    <form method="post">
      <input type="hidden" name="action" value="create">
      <div class="row">
        <input name="code" placeholder="CODE (UPPERCASE)" required>
        <input name="reward_amount" type="number" min="1" step="0.01" placeholder="Reward Amount (₹)" required>
        <input name="max_uses" type="number" min="0" placeholder="Max Uses (0 = unlimited)">
        <input name="per_user_limit" type="number" min="1" value="1" placeholder="Per User">
        <input name="starts_at" type="datetime-local" placeholder="Starts">
        <input name="ends_at"   type="datetime-local" placeholder="Ends">
      </div>
      <div class="mtop" style="display:flex;gap:10px;align-items:center">
        <label><input type="checkbox" name="is_active" checked> Active</label>
        <button class="btn">Create</button>
      </div>
      <div class="note">* Code banate hi users redeem kar sakte hain (Active ON ho to).</div>
    </form>
  </div>

  <div class="panel">
    <div style="font-weight:700;margin-bottom:6px">All Codes</div>
    <table class="table">
      <thead><tr><th>ID</th><th>Code</th><th>Reward</th><th>Limits</th><th>Window</th><th>Active</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach($rows as $r): ?>
          <tr class="data">
            <td>#<?= (int)$r['id'] ?></td>
            <td style="font-weight:700"><?= htmlspecialchars($r['code']) ?></td>
            <td><?= inr($r['reward_amount']) ?></td>
            <td>Max: <?= (int)$r['max_uses'] ?> • /User: <?= (int)$r['per_user_limit'] ?></td>
            <td><?= htmlspecialchars($r['starts_at'] ?: '—') ?> → <?= htmlspecialchars($r['ends_at'] ?: '—') ?></td>
            <td><?= $r['is_active']?'<span class="badge ok">ON</span>':'<span class="badge off">OFF</span>' ?></td>
            <td class="act">
              <form method="post"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn" style="padding:.45rem .7rem">On/Off</button></form>
              <form method="post" onsubmit="return confirm('Delete this code?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn" style="background:#ff5d71;padding:.45rem .7rem">Delete</button></form>
            </td>
          </tr>
        <?php endforeach; if(!$rows): ?>
          <tr class="data"><td colspan="7" style="color:#bbb">No codes yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div></body></html>
