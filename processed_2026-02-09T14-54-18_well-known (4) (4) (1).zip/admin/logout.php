<?php
require_once __DIR__.'/_boot.php';
session_destroy();
header('Location: /admin/login.php');
