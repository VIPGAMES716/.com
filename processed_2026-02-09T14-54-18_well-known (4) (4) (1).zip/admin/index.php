<?php
header("Location: /admin/login.php"); //The perfect provide 
exit;