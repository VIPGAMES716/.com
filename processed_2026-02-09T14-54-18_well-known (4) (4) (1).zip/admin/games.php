<?php
// admin/games.php  — dark neon UI, slug-as-name, enable/disable, tidy actions
require_once __DIR__ . '/_boot.php';
if (!function_exists('pdo')) { require_once __DIR__ . '/../includes/config.php'; function pdo(){ return app_pdo(); } }
$db = pdo();

/* --- smart table/column discovery --- */
function T($c){ foreach($c as $t){ try{ pdo()->query("SELECT 1 FROM `$t` LIMIT 1"); return $t; }catch(Throwable $e){} } return null; }
function C($t,$c){ foreach($c as $x){ try{ pdo()->query("SELECT `$x` FROM `$t` LIMIT 1"); return $x; }catch(Throwable $e){} } return null; }

$G = T(['games','game_list','arcade_games']);
if(!$G){ die("No games table found."); }
$ID   = C($G,['id','game_id']) ?? 'id';
$SLUG = C($G,['slug','code','key','name']) ?? 'slug';
$EN   = C($G,['enabled','is_active','active','status']) ?? null;

/* --- toggle enable/disable --- */
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['id'],$_POST['toggle']) && $EN){
  $id=(int)$_POST['id'];
  $db->prepare("UPDATE `$G` SET `$EN` = IF(COALESCE(`$EN`,0)=1,0,1) WHERE `$ID`=?")->execute([$id]);
  header("Location: games.php"); exit;
}
/* --- edit slug --- */
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['id'],$_POST['slug_edit'])){
  $id=(int)$_POST['id']; $slug=trim((string)$_POST['slug_edit']);
  if($slug!==''){ $db->prepare("UPDATE `$G` SET `$SLUG`=? WHERE `$ID`=?")->execute([$slug,$id]); }
  header("Location: games.php"); exit;
}

$rows = $db->query("SELECT * FROM `$G` ORDER BY `$ID` DESC LIMIT 500")->fetchAll();
function h($s){ return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Admin • Games</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{
  --bg:#090711; --bg2:#0f0d1f; --glass:rgba(255,255,255,.06); --line:rgba(255,255,255,.12);
  --ring:rgba(141,120,255,.35); --txt:#f7f7ff; --muted:rgba(255,255,255,.78);
  --vio:#8d78ff; --vio2:#5b4cf4; --ok:#16c784; --off:#6c7280; --chip:#17132f;
}
*{box-sizing:border-box} html,body{height:100%}
body{
  margin:0;color:var(--txt);font-family:Poppins,system-ui,Segoe UI;
  background:
    radial-gradient(1200px 600px at 20% -20%, #3a3398 0%, transparent 65%),
    radial-gradient(900px 520px at 110% 0%, #7a2d7b 0%, transparent 60%),
    var(--bg);
}
.container-tight{max-width:1100px}

/* Header */
.page-head{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:18px 0}
.title{font-weight:800;font-size:1.55rem;letter-spacing:.2px;display:flex;align-items:center;gap:.6rem}
.title i{font-size:1.3rem;color:#b6a8ff}
.sub{color:var(--muted);font-size:.9rem}

/* Card glass */
.cardx{
  background:var(--glass); border:1px solid var(--line); border-radius:20px; backdrop-filter:blur(18px);
  box-shadow:0 10px 30px rgba(0,0,0,.35), inset 0 0 0 1px rgba(255,255,255,.03);
}
.cardx:before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;box-shadow:0 0 28px var(--ring) inset}

/* Chips row */
.chips{display:flex;gap:10px;flex-wrap:wrap;padding:12px 14px;border-bottom:1px solid var(--line);
  background:linear-gradient(180deg,var(--bg2),transparent)}
.chip{background:var(--chip);border:1px solid var(--line);color:#cfcfff;border-radius:999px;padding:.45rem .8rem;font-weight:700}
.chip i{opacity:.9;margin-right:.45rem}

/* Table */
.table-dark{--bs-table-color:var(--txt);--bs-table-bg:transparent;--bs-table-border-color:var(--line);
  --bs-table-striped-bg:rgba(255,255,255,.04);--bs-table-hover-bg:rgba(255,255,255,.07)}
th{font-weight:800;letter-spacing:.02em}
td{vertical-align:middle}
.name{
  font-weight:800; color:#fff; letter-spacing:.2px;
  display:flex; align-items:center; gap:.55rem;
}
.name .slug{opacity:.85;font-weight:700}
.status-pill{
  display:inline-flex;align-items:center;gap:.4rem;padding:.34rem .7rem;border-radius:999px;border:1px solid var(--line);
  font-weight:800; font-size:.78rem;
}
.on{background:#06261a;color:#b4f7d8;border-color:#2b8768}
.off{background:#161822;color:#cfd5e4;border-color:#363b4a}

.actions{display:flex;gap:.45rem;flex-wrap:wrap}
.btn-glass{
  border:1px solid var(--line); background:var(--glass); color:#fff; font-weight:800;
  padding:.42rem .7rem; border-radius:12px;
}
.btn-glass:hover{box-shadow:0 8px 20px var(--ring)}
.btn-vio{background:linear-gradient(135deg,#5d45ff,#a486ff);border:none}
.badge-id{background:#2a234f;border:1px solid var(--line);border-radius:8px;padding:.2rem .5rem;font-weight:800}

/* Modal dark */
.modal-content{background:rgba(10,8,22,.98);color:#fff;border:1px solid var(--line);border-radius:16px}
.form-control{
  background:rgba(255,255,255,.06);color:#fff;border:1px solid var(--line);border-radius:12px;padding:.7rem .9rem
}
.form-control:focus{box-shadow:0 0 0 .25rem rgba(141,120,255,.18);border-color:#7d6bff}
</style>
</head>
<body>
<div class="container container-tight">

  <div class="page-head">
    <div>
      <div class="title"><i class="bi bi-controller"></i>Games</div>
      <div class="sub">Manage slugs and enable/disable visibility</div>
    </div>
  </div>

  <div class="position-relative cardx">
    <div class="chips">
      <div class="chip"><i class="bi bi-grid"></i> <?=count($rows)?> items</div>
      <?php if($EN): ?>
        <div class="chip"><i class="bi bi-toggle-on"></i> Toggle via button</div>
      <?php endif; ?>
      <div class="chip"><i class="bi bi-pencil-square"></i> Edit slug = display name</div>
    </div>

    <div class="table-responsive">
      <table class="table table-dark table-striped align-middle mb-0">
        <thead>
          <tr>
            <th style="width:80px">ID</th>
            <th>Game (Slug)</th>
            <?php if($EN): ?><th style="width:140px">Status</th><?php endif; ?>
            <th style="width:260px">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!$rows): ?>
          <tr><td colspan="<?= $EN?4:3 ?>" class="text-center text-muted py-5">No games found.</td></tr>
        <?php else: foreach($rows as $r):
          $enabled = $EN? (int)($r[$EN]??0) : null; ?>
          <tr>
            <td><span class="badge-id">#<?= (int)$r[$ID] ?></span></td>
            <td class="name">
              <i class="bi bi-joystick"></i>
              <span class="slug"><?= h($r[$SLUG]) ?></span>
            </td>
            <?php if($EN): ?>
              <td>
                <span class="status-pill <?= $enabled? 'on':'off' ?>">
                  <i class="bi <?= $enabled?'bi-check2-circle':'bi-slash-circle' ?>"></i>
                  <?= $enabled ? 'ENABLED' : 'DISABLED' ?>
                </span>
              </td>
            <?php endif; ?>
            <td>
              <div class="actions">
                <?php if($EN): ?>
                <form method="post" class="d-inline">
                  <input type="hidden" name="id" value="<?= (int)$r[$ID] ?>">
                  <button class="btn btn-glass" name="toggle" value="1">
                    <i class="bi <?= $enabled?'bi-eye-slash':'bi-eye' ?>"></i> <?= $enabled? 'Disable':'Enable' ?>
                  </button>
                </form>
                <?php endif; ?>
                <button class="btn btn-glass btn-vio" data-bs-toggle="modal" data-bs-target="#editModal"
                        data-id="<?= (int)$r[$ID] ?>" data-slug="<?= h($r[$SLUG]) ?>">
                  <i class="bi bi-pencil-square"></i> Edit
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"><i class="bi bi-pencil-square"></i> Edit Game</h6>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="g_id">
        <label class="form-label fw-bold">Slug (shown as name)</label>
        <input class="form-control" name="slug_edit" id="g_slug" required>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-glass" data-bs-dismiss="modal"><i class="bi bi-x-lg"></i> Cancel</button>
        <button class="btn btn-glass btn-vio"><i class="bi bi-check2"></i> Save</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('editModal').addEventListener('show.bs.modal', e=>{
  const b=e.relatedTarget;
  document.getElementById('g_id').value   = b.getAttribute('data-id') || '';
  document.getElementById('g_slug').value = b.getAttribute('data-slug') || '';
});
</script>
</body>
</html>
