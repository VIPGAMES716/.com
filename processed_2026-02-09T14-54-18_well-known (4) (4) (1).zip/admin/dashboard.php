<?php
require_once __DIR__.'/_boot.php';
require_admin();
$db = pdo();

function q1($sql,$a=[]){ $st=pdo()->prepare($sql); $st->execute($a); return $st->fetchColumn(); }
function inr($n){ return '₹'.number_format((float)$n,2); }
function has($t){ try{ pdo()->query("SELECT 1 FROM `$t` LIMIT 1"); return true; }catch(Throwable $e){ return false; } }

$usersTotal = has('users')        ? (int) q1("SELECT COUNT(*) FROM users") : 0;
$depSum     = has('deposits')     ? (float)q1("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE LOWER(status) IN ('approved','success','completed','paid')") : 0;
$depPend    = has('deposits')     ? (int) q1("SELECT COUNT(*) FROM deposits WHERE LOWER(status)='pending'") : 0;
$wdSum      = has('withdrawals')  ? (float)q1("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE LOWER(status) IN ('completed','success','paid')") : 0;
$wdPend     = has('withdrawals')  ? (int) q1("SELECT COUNT(*) FROM withdrawals WHERE LOWER(status)='pending'") : 0;
$tOpen      = has('support_tickets') ? (int) q1("SELECT COUNT(*) FROM support_tickets WHERE status IN ('open','pending')") : 0;
$giftOn     = has('promo_codes')  ? (int) q1("SELECT COUNT(*) FROM promo_codes WHERE is_active=1") : 0;

$recentDeps = has('deposits')
  ? $db->query("SELECT id,user_id,amount,method,provider,status,created_at FROM deposits ORDER BY id DESC LIMIT 30")->fetchAll()
  : [];
$recentWds  = has('withdrawals')
  ? $db->query("SELECT id,user_id,amount,method,order_id,status,created_at FROM withdrawals ORDER BY id DESC LIMIT 30")->fetchAll()
  : [];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Hyper Yolo Admin • Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{ --bg:#0b0a12; --bg2:#141225; --line:rgba(255,255,255,.12); --p:#8d78ff; --txt:#fff; }
*{box-sizing:border-box}
body{margin:0;color:var(--txt);background:radial-gradient(1100px 600px at 10% -10%,#2d2570 0%,#0b0a12 60%);font-family:Poppins}
.app{display:grid;grid-template-columns:240px 1fr;min-height:100dvh}
.aside{padding:16px;border-right:1px solid var(--line);background:linear-gradient(180deg,#0f0d1f 0%,#0b0a12 100%)}
.brand{font-weight:800;font-size:1.3rem;margin-bottom:14px}
.nav a{display:flex;align-items:center;gap:.6rem;padding:.65rem .8rem;border-radius:12px;color:#fff;text-decoration:none;border:1px solid var(--line);background:rgba(255,255,255,.05);margin-bottom:.55rem}
.nav a:hover{border-color:#a091ff;box-shadow:0 0 18px rgba(141,120,255,.35)}
.main{padding:16px}
.kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px}
.card{background:rgba(255,255,255,.06);border:1px solid var(--line);border-radius:16px;padding:12px;min-height:86px;display:flex;gap:10px;align-items:center;position:relative;overflow:hidden}
.card::after{content:"";position:absolute;inset:-1px;border-radius:16px;box-shadow:0 0 40px rgba(141,120,255,.25) inset}
.ico{font-size:1.2rem;color:#d6ceff}
.cap{color:rgba(255,255,255,.75);font-size:.78rem}
.val{font-weight:800;font-size:1.12rem;margin-top:2px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px}
.panel{background:rgba(255,255,255,.06);border:1px solid var(--line);border-radius:16px;overflow:hidden;position:relative}
.panel::after{content:"";position:absolute;inset:0;border-radius:16px;box-shadow:0 0 26px rgba(141,120,255,.25);pointer-events:none}
.ph{padding:10px 12px;border-bottom:1px solid var(--line);font-weight:800}
.scroll{max-height:420px;overflow:auto}
.row{display:grid;grid-template-columns:70px 1fr 86px 86px;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--line)}
.badge{padding:.18rem .52rem;border-radius:999px;font-size:.72rem;font-weight:800;border:1px solid var(--line)}
.s-warn{background:#332400;color:#ffe58a;border-color:#806400}
.s-ok{background:#0f2f22;color:#bff8d8;border-color:#1c815d}
.s-err{background:#2a1625;color:#ffb3c1;border-color:#93374b}
@media(max-width:1100px){ .kpis{grid-template-columns:repeat(3,1fr)} .grid{grid-template-columns:1fr} .row{grid-template-columns:60px 1fr 80px 80px}}
</style>
</head>
<body>
<div class="app">
  <aside class="aside">
    <div class="brand">✦ Hyper Yolo Admin</div>
    <nav class="nav">
      <a href="dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a>
      <a href="users.php"><i class="bi bi-people-fill"></i>Users</a>
      <a href="deposits.php"><i class="bi bi-wallet2"></i>Deposits</a>
      <a href="referrals.php"><i class="bi bi-people"></i>Referrals</a>
      <a href="withdraws.php"><i class="bi bi-cash-coin"></i>Withdrawals</a>
      <a href="gifts.php"><i class="bi bi-gift"></i>Gift Codes</a>
      <a href="tickets.php"><i class="bi bi-life-preserver"></i>Tickets</a>
      <a href="games.php"><i class="bi bi-controller"></i>Games</a>
    </nav>
  </aside>

  <main class="main">
    <div class="kpis">
      <div class="card"><i class="ico bi bi-people-fill"></i><div><div class="cap">Users</div><div class="val"><?=$usersTotal?></div></div></div>
      <div class="card"><i class="ico bi bi-wallet2"></i><div><div class="cap">Deposits Approved</div><div class="val"><?=inr($depSum)?></div></div></div>
      <div class="card"><i class="ico bi bi-hourglass-split"></i><div><div class="cap">Deposits Pending</div><div class="val"><?=$depPend?></div></div></div>
      <div class="card"><i class="ico bi bi-cash-coin"></i><div><div class="cap">Withdraw Completed</div><div class="val"><?=inr($wdSum)?></div></div></div>
      <div class="card"><i class="ico bi bi-hourglass"></i><div><div class="cap">Withdraw Pending</div><div class="val"><?=$wdPend?></div></div></div>
      <div class="card"><i class="ico bi bi-life-preserver"></i><div><div class="cap">Open Tickets</div><div class="val"><?=$tOpen?></div></div></div>
    </div>

    <div class="grid">
      <div class="panel">
        <div class="ph">Recent Deposits</div>
        <div class="scroll">
          <div class="row" style="opacity:.75"><b>ID</b><b>User / Method</b><b>Amount</b><b>Status</b></div>
          <?php foreach($recentDeps as $r):
            $s=strtolower($r['status']); $cls=$s==='pending'?'s-warn':($s==='approved'?'s-ok':'s-err'); ?>
            <div class="row">
              <div>#<?=$r['id']?></div>
              <div><?=htmlspecialchars($r['user_id'])?> • <?=htmlspecialchars($r['method']??'—')?> <?= $r['provider']? '– '.htmlspecialchars($r['provider']):'' ?></div>
              <div><?=inr($r['amount'])?></div>
              <div><span class="badge <?=$cls?>"><?=strtoupper($r['status'])?></span></div>
            </div>
          <?php endforeach; if(!$recentDeps): ?>
            <div class="row" style="opacity:.7">No deposits.</div>
          <?php endif; ?>
        </div>
      </div>

      <div class="panel">
        <div class="ph">Recent Withdrawals</div>
        <div class="scroll">
          <div class="row" style="opacity:.75"><b>ID</b><b>User / Method</b><b>Amount</b><b>Status</b></div>
          <?php foreach($recentWds as $r):
            $s=strtolower($r['status']); $cls=$s==='pending'?'s-warn':($s==='completed'?'s-ok':'s-err'); ?>
            <div class="row">
              <div>#<?=$r['id']?></div>
              <div><?=htmlspecialchars($r['user_id'])?> • <?=htmlspecialchars($r['method']??'—')?><?= $r['order_id']?' – #'.htmlspecialchars($r['order_id']):'' ?></div>
              <div><?=inr($r['amount'])?></div>
              <div><span class="badge <?=$cls?>"><?=strtoupper($r['status'])?></span></div>
            </div>
          <?php endforeach; if(!$recentWds): ?>
            <div class="row" style="opacity:.7">No withdrawals.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </main>
</div>
</body>
</html>
