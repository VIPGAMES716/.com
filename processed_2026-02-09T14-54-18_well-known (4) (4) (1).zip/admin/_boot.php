<?php
// admin/_boot.php
// Common bootstrap for all admin pages

// ---------- harden & log ----------
ini_set('display_errors', '0');
ini_set('log_errors', '1');
if (!is_dir(__DIR__.'/_logs')) @mkdir(__DIR__.'/_logs', 0775, true);
ini_set('error_log', __DIR__.'/_logs/error.log');

// ---------- load app config (PDO + session) ----------
$cfgTried = false;
$cfgPaths = [
  __DIR__ . '/../includes/config.php',
  __DIR__ . '/../includes/util.php',
  __DIR__ . '/../config.php', // last resort
];
foreach ($cfgPaths as $p) {
  if (is_file($p)) { require_once $p; $cfgTried = true; break; }
}
if (!$cfgTried) {
  error_log('FATAL: could not locate includes/config.php for admin.');
  http_response_code(500);
  exit('Admin bootstrap failed. Missing includes/config.php');
}

// ---------- PDO accessor ----------
if (!function_exists('pdo')) {
  function pdo(): PDO {
    // prefer app_pdo() if user config provides it
    if (function_exists('app_pdo')) return app_pdo();
    global $pdo;
    if ($pdo instanceof PDO) return $pdo;
    throw new RuntimeException('No PDO instance found from includes/config.php');
  }
}

// ---------- small DB helpers ----------
if (!function_exists('qcell')) {
  function qcell(string $sql, array $args = []) {
    $st = pdo()->prepare($sql);
    $st->execute($args);
    return $st->fetchColumn();
  }
}
if (!function_exists('qrow')) {
  function qrow(string $sql, array $args = []) {
    $st = pdo()->prepare($sql);
    $st->execute($args);
    return $st->fetch(PDO::FETCH_ASSOC);
  }
}
if (!function_exists('qall')) {
  function qall(string $sql, array $args = []) {
    $st = pdo()->prepare($sql);
    $st->execute($args);
    return $st->fetchAll(PDO::FETCH_ASSOC);
  }
}

// information_schema lookups
if (!function_exists('has_table')) {
  function has_table(string $t): bool {
    $st = pdo()->prepare("
      SELECT 1
      FROM INFORMATION_SCHEMA.TABLES
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
      LIMIT 1
    ");
    $st->execute([$t]);
    return (bool)$st->fetchColumn();
  }
}
if (!function_exists('has_col')) {
  function has_col(string $t, string $c): bool {
    $st = pdo()->prepare("
      SELECT 1
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
      LIMIT 1
    ");
    $st->execute([$t, $c]);
    return (bool)$st->fetchColumn();
  }
}
// compatibility aliases if your old code calls these:
if (!function_exists('db_has_col')) {
  function db_has_col(string $t, string $c): bool { return has_col($t,$c); }
}
if (!function_exists('db_has_table')) {
  function db_has_table(string $t): bool { return has_table($t); }
}

// ---------- admin session helpers ----------
if (!function_exists('admin_logged_in')) {
  function admin_logged_in(): bool {
    return !empty($_SESSION['admin_id']);
  }
}
if (!function_exists('require_admin')) {
  function require_admin(): void {
    if (!admin_logged_in()) {
      header('Location: login.php');
      exit;
    }
  }
}

// ---------- app name (fallback to config’s app_name) ----------
if (!function_exists('app_name_safe')) {
  function app_name_safe(): string {
    if (function_exists('app_name')) return (string)app_name();
    return 'Hyper Arcade';
  }
}

// ---------- seed admin_users (only if table empty) ----------
function admin_seed_once(): void {
  // Make table if missing
  pdo()->exec("
    CREATE TABLE IF NOT EXISTS admin_users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username       VARCHAR(100) UNIQUE,
      phone          VARCHAR(32)  UNIQUE NULL,
      email          VARCHAR(190) UNIQUE NULL,
      name           VARCHAR(120) NULL,
      role           VARCHAR(32)  NOT NULL DEFAULT 'admin',
      password_hash  VARCHAR(255) NOT NULL,
      created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");
  $cnt = (int)qcell("SELECT COUNT(*) FROM admin_users");
  if ($cnt === 0) {
    $hash = password_hash('GOPALKUMAR1a@', PASSWORD_DEFAULT);
    $st = pdo()->prepare("
      INSERT INTO admin_users (username, phone, name, role, password_hash)
      VALUES (?,?,?,?,?)
    ");
    $st->execute(['HYPER','9905954332','Super Admin','super',$hash]);
  }
}
admin_seed_once();

// ---------- tiny UI helpers ----------
if (!function_exists('h')) {
  function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}