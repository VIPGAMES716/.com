<?php
/* withdraws.php — Admin withdrawals list (reads payout details from withdrawals row) */
require_once __DIR__ . '/_boot.php';
require_admin();
$db = pdo();
header('Content-Type: text/html; charset=utf-8');

/* ---------- helpers ---------- */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function db_has_col(PDO $db, string $table, string $col): bool {
  static $cache=[]; $k="$table::$col";
  if(isset($cache[$k])) return $cache[$k];
  $q=$db->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
                   WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
  $q->execute([$table,$col]);
  return $cache[$k]=(bool)$q->fetchColumn();
}

/* ---------- map your table/columns ---------- */
$T = 'withdrawals';
$C_USER   = db_has_col($db,$T,'user_id')  ? 'user_id'  : 'uid';
$C_AMT    = db_has_col($db,$T,'amount')   ? 'amount'   : 'amt';
$C_STAT   = db_has_col($db,$T,'status')   ? 'status'   : (db_has_col($db,$T,'state') ? 'state' : null);
$C_METH   = db_has_col($db,$T,'method')   ? 'method'   : (db_has_col($db,$T,'channel') ? 'channel' : null);
$C_OID    = db_has_col($db,$T,'order_id') ? 'order_id' : (db_has_col($db,$T,'txn_id') ? 'txn_id' : null);
$C_DT     = db_has_col($db,$T,'created_at') ? 'created_at' : (db_has_col($db,$T,'created') ? 'created' : (db_has_col($db,$T,'date') ? 'date' : null));

/* payout detail columns (from withdrawals row itself) */
$C_UPI    = db_has_col($db,$T,'upi_id')      ? 'upi_id'      : (db_has_col($db,$T,'upi') ? 'upi' : null);
$C_HOLDER = db_has_col($db,$T,'holder_name') ? 'holder_name' : (db_has_col($db,$T,'bank_holder') ? 'bank_holder' : null);
$C_ACC    = db_has_col($db,$T,'account_no')  ? 'account_no'  : (db_has_col($db,$T,'acct_no') ? 'acct_no' : (db_has_col($db,$T,'bank_account')?'bank_account':null));
$C_IFSC   = db_has_col($db,$T,'ifsc')        ? 'ifsc'        : (db_has_col($db,$T,'bank_ifsc') ? 'bank_ifsc' : null);

if (!$C_STAT || !$C_AMT || !$C_USER) {
  die('<p style="color:#fff;font-family:system-ui">withdrawals table missing required columns.</p>');
}

/* ---------- actions (Approve / Reject) ---------- */
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['act'], $_POST['id'])) {
  $id  = (int)$_POST['id'];
  $act = $_POST['act']==='approve' ? 'approve' : 'reject';

  $q = $db->prepare("SELECT id, `$C_STAT` AS st FROM `$T` WHERE id=? LIMIT 1");
  $q->execute([$id]);
  $row = $q->fetch(PDO::FETCH_ASSOC);
  if ($row && strtolower($row['st'])==='pending') {
    $new = $act==='approve' ? 'completed' : 'rejected';
    $u = $db->prepare("UPDATE `$T` SET `$C_STAT`=? WHERE id=? LIMIT 1");
    $u->execute([$new, $id]);
  }
  header('Location: withdraws.php?'.http_build_query($_GET)); exit;
}

/* ---------- filters ---------- */
$allowed = ['all','pending','completed','rejected'];
$status  = strtolower($_GET['status'] ?? 'all');
if (!in_array($status,$allowed,true)) $status = 'all';
$qUser   = trim((string)($_GET['q'] ?? ''));

/* ---------- fetch ---------- */
$select = "id, `$C_USER` AS uid, `$C_AMT` AS amt";
if($C_METH) $select .= ", `$C_METH` AS method";
if($C_OID)  $select .= ", `$C_OID`  AS order_id";
if($C_DT)   $select .= ", `$C_DT`   AS dt";
if($C_STAT) $select .= ", `$C_STAT` AS st";
if($C_UPI)    $select .= ", `$C_UPI`    AS upi";
if($C_HOLDER) $select .= ", `$C_HOLDER` AS holder";
if($C_ACC)    $select .= ", `$C_ACC`    AS acc";
if($C_IFSC)   $select .= ", `$C_IFSC`   AS ifsc";

$sql = "SELECT $select FROM `$T`";
$cla=[]; $args=[];
if ($status!=='all'){ $cla[]="LOWER(`$C_STAT`) = ?"; $args[]=$status; }
if ($qUser!==''){   $cla[]="`$C_USER` LIKE ?";     $args[]="%$qUser%"; }
if ($cla) $sql .= " WHERE ".implode(" AND ",$cla);
$sql .= " ORDER BY ".($C_DT ? "`$C_DT`" : "id")." DESC LIMIT 500";

$st = $db->prepare($sql);
$st->execute($args);
$data = $st->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"/>
<title>Withdrawals – Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--bg:#0c0b12;--bg2:#141320;--card:#12111b;--line:#232139;--txt:#f8f8ff;--mut:#b8b6d4;--p:#8d78ff;--ok:#1f9962;--bad:#e14a5a}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(1200px 800px at 50% -20%,#251f54 0%,var(--bg) 60%) fixed;color:var(--txt);font:14px/1.5 system-ui,Segoe UI,Poppins}
.wrap{max-width:1200px;margin:30px auto;padding:0 14px}
h1{margin:0 0 18px;font-weight:800}
.toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0 18px}
.chip{background:#1b1830;border:1px solid var(--line);padding:8px 14px;border-radius:24px;color:var(--mut);text-decoration:none}
.chip.active{background:var(--p);color:#fff}
.find{flex:1;min-width:220px;background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:10px 12px;color:#fff}
.table{width:100%;border-collapse:separate;border-spacing:0 10px}
th{text-align:left;color:#cfcdea;padding:0 10px 6px}
tr{background:var(--card);border:1px solid var(--line)}
td{padding:12px 10px;vertical-align:top}
.badge{padding:6px 10px;border-radius:12px;font-weight:700}
.badge.ok{background:#102e22;color:#8ef1c4;border:1px solid #1b6447}
.badge.pending{background:#2a2411;color:#ffe09a;border:1px solid #6b5a1e}
.badge.bad{background:#2c1116;color:#ff9aa7;border:1px solid #6b1e28}
.action{display:flex;gap:6px}
.btn{border:none;border-radius:10px;padding:8px 12px;cursor:pointer}
.approve{background:var(--ok);color:#fff}.reject{background:var(--bad);color:#fff}
.small{font-size:12px}
.cell{background:rgba(255,255,255,.03);padding:8px;border-radius:10px;border:1px solid var(--line);margin-bottom:4px}
</style>
</head>
<body>
<div class="wrap">
  <h1>Withdrawals</h1>

  <form class="toolbar" method="get">
    <?php
      $tabs=['pending'=>'Pending','completed'=>'Completed','rejected'=>'Rejected','all'=>'All'];
      foreach($tabs as $k=>$label){
        $cls='chip'.($status===$k?' active':'');
        echo "<a class='$cls' href='?status=$k&q=".urlencode($qUser)."'>$label</a>";
      }
    ?>
    <input class="find" name="q" value="<?=h($qUser)?>" placeholder="Search user / order">
    <button class="chip" type="submit">Filter</button>
  </form>

  <table class="table">
    <thead>
      <tr>
        <th>ID</th><th>User</th><th>Amount</th><th>Method</th><th>Order</th><th>Date</th>
        <th>Payout Details</th><th>Status</th><th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php if(!$data): ?>
      <tr><td colspan="9" class="small" style="color:#aaa;padding:18px">No records.</td></tr>
    <?php else: foreach($data as $r):
      $st = strtolower($r['st'] ?? 'pending');
      $badge = $st==='completed' ? 'badge ok' : ($st==='pending' ? 'badge pending' : 'badge bad');
    ?>
      <tr>
        <td>#<?= (int)$r['id'] ?></td>
        <td><b><?= h($r['uid']) ?></b></td>
        <td><b>₹<?= number_format((float)$r['amt'],2) ?></b></td>
        <td><?= h($r['method'] ?? '—') ?></td>
        <td><?= h($r['order_id'] ?? '—') ?></td>
        <td class="small"><?= h($r['dt'] ?? '') ?></td>
        <td>
          <?php if(!empty($r['upi'])): ?>
            <div class="cell"><b>UPI:</b> <?= h($r['upi']) ?></div>
          <?php endif; ?>
          <?php if(!empty($r['holder'])): ?>
            <div class="cell"><b>Holder:</b> <?= h($r['holder']) ?></div>
          <?php endif; ?>
          <?php if(!empty($r['acc'])): ?>
            <div class="cell"><b>Account:</b> <?= h($r['acc']) ?></div>
          <?php endif; ?>
          <?php if(!empty($r['ifsc'])): ?>
            <div class="cell"><b>IFSC:</b> <?= h($r['ifsc']) ?></div>
          <?php endif; ?>
          <?php if(empty($r['upi']) && empty($r['holder']) && empty($r['acc']) && empty($r['ifsc'])): ?>
            <span class="small" style="color:#9a98b8">No payout fields on this row.</span>
          <?php endif; ?>
        </td>
        <td><span class="<?= $badge ?>"><?= strtoupper($st) ?></span></td>
        <td>
          <?php if($st==='pending'): ?>
            <form method="post" style="display:inline">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="hidden" name="act" value="approve">
              <button class="btn approve" title="Approve"><i class="bi bi-check2-circle"></i></button>
            </form>
            <form method="post" style="display:inline">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="hidden" name="act" value="reject">
              <button class="btn reject" title="Reject"><i class="bi bi-x-circle"></i></button>
            </form>
          <?php else: ?>
            <span class="small" style="color:#8a87a5">—</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
</body>
</html>
