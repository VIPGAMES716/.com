<?php
// admin/deposits.php — neon dark UI + safe one-time approve/reject
require_once __DIR__ . '/_boot.php';
require_admin();

$db = pdo();
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* ---------- actions (approve/reject) — safe & one-time ---------- */
function approve_deposit(PDO $db, int $id): array {
  try{
    $db->beginTransaction();

    // Lock row so refresh can't double-credit
    $st=$db->prepare("SELECT id,user_id,amount,status FROM deposits WHERE id=? FOR UPDATE");
    $st->execute([$id]);
    $d=$st->fetch(PDO::FETCH_ASSOC);
    if(!$d){ $db->rollBack(); return [false,"Deposit not found"]; }
    if(strtolower($d['status'])!=='pending'){ $db->rollBack(); return [false,"Already {$d['status']}"]; }

    // Ensure user exists by user_id (varchar)
    $st=$db->prepare("SELECT id FROM users WHERE user_id=? LIMIT 1");
    $st->execute([$d['user_id']]);
    if(!$st->fetch()){ $db->rollBack(); return [false,"User not found for user_id ".$d['user_id']]; }

    // Update status first (still inside lock)
    $ok=$db->prepare("UPDATE deposits SET status='Approved' WHERE id=? AND status='Pending'")->execute([$id]);
    if(!$ok){ $db->rollBack(); return [false,"Could not update status"]; }

    // Credit exactly once
    $db->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?")
       ->execute([(float)$d['amount'], (string)$d['user_id']]);

    $db->commit();
    return [true,"Approved & credited ₹".number_format((float)$d['amount'],2)." to ".$d['user_id']];
  }catch(Throwable $e){
    if($db->inTransaction()) $db->rollBack();
    return [false,$e->getMessage()];
  }
}
function reject_deposit(PDO $db, int $id): array {
  try{
    $db->beginTransaction();
    $st=$db->prepare("SELECT id,status FROM deposits WHERE id=? FOR UPDATE");
    $st->execute([$id]); $d=$st->fetch(PDO::FETCH_ASSOC);
    if(!$d){ $db->rollBack(); return [false,"Deposit not found"]; }
    if(strtolower($d['status'])!=='pending'){ $db->rollBack(); return [false,"Already {$d['status']}"]; }
    $db->prepare("UPDATE deposits SET status='Rejected' WHERE id=? AND status='Pending'")->execute([$id]);
    $db->commit();
    return [true,"Rejected"];
  }catch(Throwable $e){
    if($db->inTransaction()) $db->rollBack();
    return [false,$e->getMessage()];
  }
}

/* ---------- handle POST ---------- */
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=(int)($_POST['id']??0);
  $act=$_POST['action']??'';
  if($id>0){
    [$ok,$msg]=($act==='approve')?approve_deposit($db,$id):(($act==='reject')?reject_deposit($db,$id):[false,'Invalid']);
  }
}

/* ---------- filters & query ---------- */
$tab = strtolower($_GET['status'] ?? 'pending');
if(!in_array($tab,['pending','approved','rejected','all'],true)) $tab='pending';
$search = trim((string)($_GET['q'] ?? ''));

$where=[]; $args=[];
if($tab!=='all'){ $where[]="LOWER(d.status)=?"; $args[]=$tab; }
if($search!==''){ $where[]="(d.user_id LIKE ? OR d.txn_id LIKE ?)"; $args[]="%$search%"; $args[]="%$search%"; }
$sqlWhere = $where?('WHERE '.implode(' AND ',$where)):'';

/* NOTE: expects deposits: id,user_id,amount,status,method,txn_id,created_at
         users: user_id,name,balance */
$sql="SELECT d.*, u.name AS user_name, u.balance AS curr_balance
      FROM deposits d LEFT JOIN users u ON u.user_id=d.user_id
      $sqlWhere
      ORDER BY d.id DESC
      LIMIT 300";
$st=$db->prepare($sql); $st->execute($args);
$rows=$st->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin • Deposits</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{
  --bg:#090711; --bg2:#0f0d1f; --glass:rgba(255,255,255,.06); --line:rgba(255,255,255,.12);
  --ring:rgba(141,120,255,.35); --txt:#f7f7ff; --muted:rgba(255,255,255,.78);
  --vio:#8d78ff; --vio2:#5b4cf4; --ok:#1bd89b; --warn:#ffd166; --err:#ff5d71;
  --chip:#17132f;
}
*{box-sizing:border-box}
body{
  margin:0;color:var(--txt);font-family:Poppins,system-ui,Segoe UI;
  background:
    radial-gradient(1200px 600px at 18% -18%, #3a3398 0%, transparent 65%),
    radial-gradient(900px 520px at 110% 0%, #7a2d7b 0%, transparent 60%),
    var(--bg);
}
.container-tight{max-width:1200px}

/* Header */
.page-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:18px 0}
.title{font-weight:800;font-size:1.55rem;letter-spacing:.2px;display:flex;align-items:center;gap:.6rem}
.title i{font-size:1.3rem;color:#b6a8ff}
.sub{color:var(--muted);font-size:.9rem}

/* Toolbar */
.toolbar{
  position:sticky;top:0;z-index:6;padding:10px 12px;border-radius:14px;margin-bottom:14px;
  background:linear-gradient(180deg,var(--bg2),transparent);
  border:1px solid var(--line);backdrop-filter:blur(12px);
}
.tabs{display:flex;gap:10px;flex-wrap:wrap}
.tab{padding:.58rem 1rem;border:1px solid var(--line);border-radius:999px;background:var(--glass);
  color:#fff;text-decoration:none;font-weight:800}
.tab.active{background:#3a3294;border-color:#5b4cf4;box-shadow:0 10px 30px var(--ring)}
.searchbox{display:flex;gap:8px;margin-left:auto}
.searchbox input{
  background:var(--glass);border:1px solid var(--line);color:#fff;border-radius:12px;padding:.7rem 1rem;min-width:240px
}
.btn-ghost{border:1px solid var(--line);background:var(--glass);color:#fff;border-radius:12px;padding:.6rem .9rem;font-weight:800}
.btn-ghost:hover{box-shadow:0 8px 20px var(--ring)}

/* Card + table */
.cardx{
  position:relative;background:var(--glass); border:1px solid var(--line); border-radius:20px; backdrop-filter:blur(18px);
  box-shadow:0 10px 30px rgba(0,0,0,.35), inset 0 0 0 1px rgba(255,255,255,.03);
}
.cardx:before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;box-shadow:0 0 28px var(--ring) inset}

.table-dark{
  --bs-table-color:var(--txt);--bs-table-bg:transparent;--bs-table-border-color:var(--line);
  --bs-table-striped-bg:rgba(255,255,255,.04);--bs-table-hover-bg:rgba(255,255,255,.07)
}
th{font-weight:800;letter-spacing:.02em}
td{vertical-align:middle}
.cell-id .badge-id{background:#2a234f;border:1px solid var(--line);border-radius:8px;padding:.2rem .5rem;font-weight:800}
.usercell .uid{font-weight:800}
.usercell .uname{opacity:.8;font-size:.8rem}
.amt{font-weight:800}
.badge-pill{border-radius:999px;padding:.42rem .7rem;font-weight:800}
.st-p{background:#2b1d00;color:#ffd98a;border:1px solid #7b5c00}
.st-a{background:#05251a;color:#bff8d8;border:1px solid #1e765a}
.st-r{background:#2e1111;color:#ffb3b3;border:1px solid #8f3a3a}

.actions{display:flex;gap:.4rem;justify-content:flex-end;flex-wrap:wrap}
.btn-approve{background:linear-gradient(135deg,#0ea37e,#15d19b);border:none;border-radius:12px;padding:.45rem .7rem;font-weight:800;color:#041b15}
.btn-reject{background:transparent;border:1px solid #8f3a3a;border-radius:12px;padding:.45rem .7rem;color:#ffb3b3;font-weight:800}
.btn-reject:hover{background:#3b2222}
.notice{background:rgba(255,255,255,.08);border:1px solid var(--line);border-radius:12px;padding:.7rem 1rem;margin-bottom:12px}
</style>
</head>
<body>
<div class="container container-tight">

  <div class="page-head">
    <div>
      <div class="title"><i class="bi bi-wallet2"></i>Deposits</div>
      <div class="sub">Approve once (credits wallet) or reject. Safe against refresh/double-click.</div>
    </div>
  </div>

  <?php if($msg): ?>
    <div class="notice"><?= h($msg) ?></div>
  <?php endif; ?>

  <div class="toolbar d-flex align-items-center">
    <div class="tabs">
      <a class="tab <?= $tab==='pending'?'active':'' ?>"  href="?status=pending"><i class="bi bi-hourglass-split me-1"></i> Pending</a>
      <a class="tab <?= $tab==='approved'?'active':'' ?>" href="?status=approved"><i class="bi bi-check2-circle me-1"></i> Approved</a>
      <a class="tab <?= $tab==='rejected'?'active':'' ?>" href="?status=rejected"><i class="bi bi-x-octagon me-1"></i> Rejected</a>
      <a class="tab <?= $tab==='all'?'active':'' ?>"      href="?status=all"><i class="bi bi-collection me-1"></i> All</a>
    </div>
    <form class="searchbox ms-auto" method="get">
      <input type="hidden" name="status" value="<?=h($tab)?>">
      <input name="q" value="<?=h($search)?>" placeholder="Search user_id / txn_id">
      <button class="btn-ghost"><i class="bi bi-search"></i> Filter</button>
    </form>
  </div>

  <div class="cardx p-3">
    <div class="table-responsive">
      <table class="table table-dark table-striped table-hover align-middle mb-0">
        <thead>
          <tr>
            <th style="width:88px">ID</th>
            <th>User</th>
            <th style="width:140px">Amount</th>
            <th style="width:120px">Method</th>
            <th>Txn</th>
            <th style="width:160px">Date</th>
            <th style="width:120px">Status</th>
            <th style="width:210px" class="text-end">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!$rows): ?>
          <tr><td colspan="8" class="text-center text-secondary py-5">No records</td></tr>
        <?php else: foreach($rows as $r):
          $st = strtolower($r['status']);
          $badge = $st==='pending' ? 'st-p' : ($st==='approved' ? 'st-a' : 'st-r'); ?>
          <tr>
            <td class="cell-id"><span class="badge-id">#<?= (int)$r['id'] ?></span></td>
            <td class="usercell">
              <div class="uid"><?= h($r['user_id']) ?></div>
              <div class="uname"><?= h($r['user_name'] ?? '') ?></div>
            </td>
            <td class="amt">₹<?= number_format((float)$r['amount'],2) ?></td>
            <td><?= h($r['method']) ?></td>
            <td class="text-break"><?= h($r['txn_id']) ?></td>
            <td><?= h($r['created_at']) ?></td>
            <td><span class="badge-pill <?= $badge ?>"><?= strtoupper($r['status']) ?></span></td>
            <td>
              <div class="actions">
                <?php if($st==='pending'): ?>
                  <form class="d-inline action-form" method="post">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="action" value="approve">
                    <button class="btn-approve"><i class="bi bi-check2-circle me-1"></i>Approve</button>
                  </form>
                  <form class="d-inline action-form" method="post" onsubmit="return confirm('Reject this deposit?');">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <input type="hidden" name="action" value="reject">
                    <button class="btn-reject"><i class="bi bi-x-circle me-1"></i>Reject</button>
                  </form>
                <?php else: ?>
                  <span class="text-secondary small">Processed</span>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
// prevent double submit on approve/reject
document.querySelectorAll('.action-form').forEach(f=>{
  f.addEventListener('submit', e=>{
    const btn = f.querySelector('button'); if(btn){ btn.disabled = true; btn.style.opacity = .7; }
  });
});
</script>
</body>
</html>
