<?php
// recharge.php — ColaPay integration + enhanced UI
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/payments/cola_client.php';
app_require_login();

$pdo = app_pdo();
$UID = app_user_id();

function table_has(PDO $pdo, string $tbl, string $col): bool {
  $st=$pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
  $st->execute([$tbl,$col]); return (bool)$st->fetchColumn();
}

$msg = '';
$just_amount = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $amount = (int)($_POST['amount'] ?? 0);
  if ($amount < 100) { $amount = 100; }
  $just_amount = (string)$amount;

  // Create local order id
  $txn_id = 'DP'.date('ymdHis').substr((string)mt_rand(1000,9999),-4);

  // Insert into deposits (Pending)
  $tbl = 'deposits';
  foreach (['user_id','amount'] as $c) {
    if (!table_has($pdo,$tbl,$c)) { http_response_code(500); exit("deposits table missing '$c'"); }
  }
  $data = [
    'user_id'    => $UID,
    'amount'     => $amount,
    'method'     => 'UPI',
    'provider'   => 'Cola',
    'txn_id'     => $txn_id,
    'status'     => 'Pending',
    'created_at' => date('Y-m-d H:i:s'),
  ];
  $cols  = array_keys($data);
  $avail = array_values(array_filter($cols, fn($c)=>table_has($pdo,$tbl,$c)));
  $vals  = array_map(fn($c)=>$data[$c], $avail);
  $place = implode(',', array_fill(0,count($avail),'?'));
  $pdo->prepare("INSERT INTO `$tbl` (".implode(',',$avail).") VALUES ($place)")->execute($vals);

  // Ask ColaPay for payUrl
  $res = cola_create_order((string)$UID, (int)$amount, $txn_id, cola_return_url(), cola_notify_url());
  if (!empty($res['ok']) && !empty($res['url'])) {
    header('Location: '.$res['url']);
    exit;
  }

  $msg = 'Order created locally but gateway link failed. Please try again.';
  if (!empty($res)) { cola_log('create_error', $res); }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Recharge – <?= htmlspecialchars(app_name()) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{
  --p:#8d78ff; --s:#ff57e6; --ok:#22c55e;
  --card:rgba(255,255,255,.08); --line:rgba(255,255,255,.12); --dim:rgba(255,255,255,.75);
}
*{box-sizing:border-box}
body{
  margin:0;min-height:100vh;color:#fff;font-family:Poppins,system-ui,Segoe UI;
  background:radial-gradient(1100px 700px at 50% -20%, #2d2570 0%, #110e25 70%);
}
body::after{content:"";position:fixed;inset:0;pointer-events:none;opacity:.05;
  background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png')}
.app{max-width:520px;margin:auto;padding:1.2rem 1rem 3rem}

/* header */
.brand{font-size:1.45rem;font-weight:800;letter-spacing:.2px;display:flex;align-items:center;gap:.6rem}
.hbtn{border:1px solid var(--line);background:transparent;color:#fff;border-radius:14px;padding:.5rem .9rem;font-weight:600}
.hbtn:hover{box-shadow:0 8px 22px rgba(141,120,255,.35)}

/* glass cards */
.cardx{
  background:var(--card); border:1px solid var(--line); border-radius:22px; backdrop-filter:blur(16px);
  box-shadow:0 10px 28px rgba(0,0,0,.35), inset 0 0 0 1px rgba(255,255,255,.04);
}

/* channel badge */
.kv{display:flex;align-items:center;gap:.55rem}
.kv i{opacity:.9}
.tag{display:inline-flex;align-items:center;gap:.4rem;background:rgba(255,255,255,.1);
  border:1px solid var(--line);padding:.25rem .6rem;border-radius:999px;font-size:.78rem;font-weight:700}

/* amount input + chips */
.form-control{
  background:rgba(255,255,255,.06)!important;border:1px solid var(--line)!important;color:#fff!important;
  border-radius:14px;padding:1rem 1rem;font-weight:600;font-size:1.05rem
}
.form-control:focus{box-shadow:none;border-color:var(--p)!important}
.hint{color:var(--dim);font-size:.85rem}
.chips{display:flex;gap:.55rem;flex-wrap:wrap;margin:.6rem 0 .2rem}
.chip{flex:0 0 auto;cursor:pointer;padding:.55rem .9rem;border-radius:14px;font-weight:700;
  background:rgba(255,255,255,.09);border:1px solid var(--line)}
.chip:hover{filter:brightness(1.1)}
.chip.active{outline:2px solid var(--p)}

/* CTA */
.btn-main{
  background:linear-gradient(135deg,var(--p),var(--s));
  border:none;border-radius:16px;color:#fff;font-weight:800;padding:1rem 1.1rem
}
.btn-main:disabled{opacity:.6}

/* info + error */
.info{display:flex;gap:.6rem;align-items:flex-start;background:rgba(255,255,255,.08);border:1px solid var(--line);
  border-radius:16px;padding:.7rem .9rem;margin:.7rem 0}
.bad{background:#ff5d71;border:1px solid rgba(255,255,255,.2);border-radius:14px;padding:.8rem 1rem;margin:.7rem 0}

/* footer note */
.note{color:var(--dim);font-size:.82rem;text-align:center;margin-top:1rem}
</style>
</head>
<body>
<div class="app">

  <!-- header -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="brand">
      <button class="hbtn" onclick="history.back()"><i class="bi bi-arrow-left"></i></button>
      <span>Recharge</span>
    </div>
    <a class="hbtn" href="/deposit_history.php"><i class="bi bi-clock-history me-1"></i> History</a>
  </div>

  <!-- provider panel -->
  <div class="cardx p-3 mb-3">
    <div class="kv mb-2"><i class="bi bi-upc-scan"></i><div><strong>Payment Channel</strong><div class="hint">UPI • Fast & secure</div></div></div>
    <div class="kv"><i class="bi bi-shield-check"></i><div><strong>Provider</strong><div class="hint">ColaPay (auto-redirect)</div></div></div>
  </div>

  <?php if ($msg): ?><div class="bad"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <!-- form -->
  <form method="post" class="cardx p-4" id="rechargeForm">
    <label class="form-label fw-semibold">Amount (₹)</label>
    <input class="form-control" type="number" name="amount" id="amount" min="100" step="1"
           placeholder="100" value="<?= htmlspecialchars($just_amount ?: '') ?>" required>

    <div class="chips" id="chips">
      <?php foreach ([100,200,300,500,1000,2000] as $v): ?>
        <span class="chip" data-v="<?= $v ?>">₹ <?= number_format($v) ?></span>
      <?php endforeach; ?>
      <span class="chip" data-v="0"><i class="bi bi-pencil-square me-1"></i>Custom</span>
    </div>

    <div class="info"><i class="bi bi-info-circle"></i>
      <div><strong>Note:</strong> Minimum ₹100. You’ll be sent to a secure UPI page. After successful payment, your wallet is credited automatically.</div>
    </div>

    <div class="d-grid mt-2">
      <button class="btn btn-main" id="payBtn">
        <span class="txt"><i class="bi bi-lightning-charge-fill me-1"></i> Proceed to Pay</span>
        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
      </button>
    </div>
    <div class="hint mt-2">Having trouble? Try a different amount like ₹300 or ₹500.</div>
  </form>

  <div class="note">Powered by <?= htmlspecialchars(app_name()) ?> • Secure UPI</div>
</div>

<script>
const amt   = document.getElementById('amount');
const chips = document.querySelectorAll('#chips .chip');
chips.forEach(c=>{
  c.addEventListener('click', ()=>{
    chips.forEach(k=>k.classList.remove('active'));
    c.classList.add('active');
    const v = parseInt(c.dataset.v,10);
    if (v>0){ amt.value=v; } else { amt.focus(); }
  });
});

const form  = document.getElementById('rechargeForm');
const payBtn= document.getElementById('payBtn');
form.addEventListener('submit', (e)=>{
  // basic guard
  const v = parseInt(amt.value||'0',10);
  if (isNaN(v) || v < 100){
    e.preventDefault();
    amt.value = 100;
    amt.focus();
    return;
  }
  payBtn.disabled = true;
  payBtn.querySelector('.txt').classList.add('d-none');
  payBtn.querySelector('.spinner-border').classList.remove('d-none');
});
</script>
</body>
</html>
