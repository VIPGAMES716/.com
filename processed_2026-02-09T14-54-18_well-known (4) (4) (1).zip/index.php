<?php
header("Location: login.php"); //The perfect provide 
exit;