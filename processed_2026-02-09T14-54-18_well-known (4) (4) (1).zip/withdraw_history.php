<?php
// withdraw_history.php
require_once __DIR__ . '/includes/config.php';
app_require_login();

$pdo = app_pdo();
$UID = app_user_id();

function tbl_exists(PDO $pdo, string $t): bool {
  $st=$pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1");
  $st->execute([$t]); return (bool)$st->fetchColumn();
}
function col_exists(PDO $pdo, string $t, string $c): bool {
  $st=$pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
  $st->execute([$t,$c]); return (bool)$st->fetchColumn();
}
function first_table(PDO $pdo, array $cs): ?string { foreach($cs as $t) if (tbl_exists($pdo,$t)) return $t; return null; }
function first_col(PDO $pdo, string $t, array $cs): ?string { foreach($cs as $c) if (col_exists($pdo,$t,$c)) return $c; return null; }
function money_fmt(float $n): string { return '₹'.number_format($n,2); }

$tbl = first_table($pdo, ['withdrawals','payouts','withdraw','cashout','transactions']);
if (!$tbl) {
  http_response_code(500);
  echo "<h2 style='font-family:system-ui;color:#c00'>No withdrawals table found.</h2>";
  exit;
}
$C = [
  'id'     => first_col($pdo,$tbl,['id','wid','txid']),
  'user'   => first_col($pdo,$tbl,['user_id','uid','account_id','member_id']),
  'amount' => first_col($pdo,$tbl,['amount','amt','value','total']),
  'status' => first_col($pdo,$tbl,['status','tx_status','state','result']),
  'method' => first_col($pdo,$tbl,['method','payout_method','channel','mode']),
  'upi'    => col_exists($pdo,$tbl,'upi_id') ? 'upi_id' : null,
  'acct'   => (col_exists($pdo,$tbl,'account_no') ? 'account_no' : (col_exists($pdo,$tbl,'acct_no') ? 'acct_no' : null)),
  'ifsc'   => col_exists($pdo,$tbl,'ifsc') ? 'ifsc' : null,
  'note'   => (function($pdo,$tbl){foreach(['details','note','notes','remark','meta','meta_json'] as $c) if (col_exists($pdo,$tbl,$c)) return $c; return null;})($pdo,$tbl),
  'ctime'  => (function($pdo,$tbl){foreach(['created_at','created_on','ctime','created','time','date'] as $c) if (col_exists($pdo,$tbl,$c)) return $c; return null;})($pdo,$tbl),
];
//HYPERDEVELOPER
$page = max(1,(int)($_GET['page'] ?? 1));
$per  = 20; $off = ($page-1)*$per;
$q    = trim((string)($_GET['q'] ?? ''));
$tab  = strtolower((string)($_GET['status'] ?? 'all'));
if (!in_array($tab,['all','pending','completed','failed'],true)) $tab='all';

$sel = [$C['id'] ? "{$C['id']} AS _id" : "NULL AS _id"];
$sel[] = "{$C['amount']} AS _amount";
if($C['status']) $sel[] = "{$C['status']} AS _status";
if($C['method']) $sel[] = "{$C['method']} AS _method";
if($C['ctime'])  $sel[] = "{$C['ctime']}  AS _ctime";
if($C['upi'])    $sel[] = "{$C['upi']}    AS _upi";
if($C['acct'])   $sel[] = "{$C['acct']}   AS _acct";
if($C['ifsc'])   $sel[] = "{$C['ifsc']}   AS _ifsc";
if($C['note'])   $sel[] = "{$C['note']}   AS _note";

$sql  = "SELECT ".implode(',', $sel)." FROM `$tbl` WHERE `{$C['user']}` = :uid";
$args = [':uid'=>$UID];

if ($q!=='') {
  $like = "%$q%";
  $kw = [];
  if ($C['id'])   $kw[] = "{$C['id']} LIKE :kw";
  if ($C['ctime'])$kw[] = "{$C['ctime']} LIKE :kw";
  if ($C['method'])$kw[]= "{$C['method']} LIKE :kw";
  if ($C['status'])$kw[]= "{$C['status']} LIKE :kw";
  if ($C['upi'])  $kw[] = "{$C['upi']} LIKE :kw";
  if ($C['acct']) $kw[] = "{$C['acct']} LIKE :kw";
  if ($kw) { $sql .= " AND (".implode(' OR ',$kw).")"; $args[':kw']=$like; }
}
$sql .= " ORDER BY ".($C['ctime'] ?: $C['id'])." DESC LIMIT :lim OFFSET :off";

$st = $pdo->prepare($sql);
foreach($args as $k=>$v){ $st->bindValue($k,$v, is_int($v)?PDO::PARAM_INT:PDO::PARAM_STR); }
$st->bindValue(':lim',$per,PDO::PARAM_INT);
$st->bindValue(':off',$off,PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll();

function norm_status($s){
  $s = strtolower((string)$s);
  if (in_array($s,['approved','success','completed','paid','done','ok'],true)) return 'completed';
  if (in_array($s,['fail','failed','error','declined','canceled','cancelled'],true)) return 'failed';
  if ($s===''||$s===null) return 'pending';
  return $s;
}
$items=[];
foreach($rows as $r){
  $st = $r['_status'] ?? 'pending'; $st = norm_status($st);
  if ($tab!=='all' && $st!==$tab) continue;
  $dest = '';
  if (!empty($r['_upi'])) $dest = 'UPI: '.$r['_upi'];
  elseif (!empty($r['_acct']) || !empty($r['_ifsc'])) $dest = 'BANK: '.($r['_acct']??'').' '.($r['_ifsc']??'');
  elseif (!empty($r['_note'])) $dest = $r['_note'];
  $items[] = [
    'id'     => $r['_id'] ?? '',
    'amount' => (float)$r['_amount'],
    'status' => $st,
    'method' => $r['_method'] ?? '',
    'when'   => $r['_ctime'] ?? '',
    'dest'   => $dest
  ];
}

/* count for pager */
$cntSql = "SELECT COUNT(*) FROM `$tbl` WHERE `{$C['user']}`=?";
$cntArgs= [$UID];
if ($q!=='' && !empty($args[':kw'])) {
  $kwParts=[];
  if ($C['id'])   $kwParts[]="{$C['id']} LIKE ?";
  if ($C['ctime'])$kwParts[]="{$C['ctime']} LIKE ?";
  if ($C['method'])$kwParts[]="{$C['method']} LIKE ?";
  if ($C['status'])$kwParts[]="{$C['status']} LIKE ?";
  if ($C['upi'])  $kwParts[]="{$C['upi']} LIKE ?";
  if ($C['acct']) $kwParts[]="{$C['acct']} LIKE ?";
  if ($kwParts){ $cntSql.=" AND (".implode(' OR ',$kwParts).")"; $cntArgs=array_merge($cntArgs, array_fill(0,count($kwParts), "%$q%")); }
}
$tot = (int)db_cell($cntSql,$cntArgs);
$pages = max(1,(int)ceil($tot/20));

function pager_window($cur,$max){
  if ($max<=6){ $a=[]; for($i=1;$i<=$max;$i++) $a[]=$i; return $a; }
  $out=[1,2]; $s=max(3,$cur-1); $e=min($max-2,$cur+1);
  if ($s>3) $out[]='...'; for($i=$s;$i<=$e;$i++) $out[]=$i;
  if ($e<$max-2) $out[]='...'; $out[]=$max-1; $out[]=$max; return $out;
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Withdraw History – <?= htmlspecialchars(app_name()) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{--p:#8d78ff;--card:rgba(255,255,255,.08);--line:rgba(255,255,255,.12);--dim:rgba(255,255,255,.74)}
*{box-sizing:border-box} body{margin:0;min-height:100vh;font-family:Poppins,sans-serif;color:#fff;background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);overflow-x:hidden}
.app{max-width:480px;margin:auto;padding:1rem 1rem 8.6rem}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem}
.brand{font-size:1.5rem;font-weight:700}
.btn-mini{border:none;border-radius:14px;font-size:.85rem;font-weight:600;padding:.4rem .85rem;cursor:pointer}
.btn-mini.exp{background:var(--p);color:#fff}
.btn-mini.back{background:var(--card);border:1px solid var(--line);color:var(--dim)}
.search-input{width:100%;padding:.7rem 1rem;border-radius:18px;margin-bottom:1rem;border:1px solid var(--line);background:var(--card);color:#fff;font-size:.95rem}
.tabs{display:flex;gap:.5rem;margin-bottom:1rem}
.tab{flex:1;padding:.5rem 0;border-radius:14px;font-size:.85rem;font-weight:600;border:1px solid var(--line);background:var(--card);color:var(--dim);text-align:center;text-decoration:none}
.tab.active{background:var(--p);color:#fff}
.item{display:flex;gap:.75rem;padding:.8rem;border-radius:18px;margin-bottom:.6rem;background:var(--card);border:1px solid var(--line);align-items:center}
.icon{width:40px;height:40px;border-radius:14px;background:#8d78ff55;display:flex;align-items:center;justify-content:center}
.side{text-align:right}
.badge{font-size:.7rem;padding:.2rem .55rem}
.text-bg-success{background:#198754!important;color:#fff}
.text-bg-warning{background:#ffc107!important;color:#000}
.text-bg-danger{background:#dc3545!important;color:#fff}
.pagination-nav{display:flex;justify-content:center;gap:.25rem;margin:1.2rem 0;flex-wrap:wrap}
.pg{display:inline-block;padding:.35rem .75rem;border-radius:12px;font-size:.8rem;font-weight:600;border:1px solid var(--line);background:var(--card);color:var(--dim)}
.pg.active{background:var(--p);color:#fff;border-color:var(--p)}
</style>
</head>
<body>
<div class="app">
  <div class="header">
    <div class="brand">Withdraw History</div>
    <div class="d-flex gap-2">
      <button class="btn-mini exp" id="exportBtn"><i class="bi bi-download me-1"></i>Export</button>
      <button class="btn-mini back" onclick="history.back()"><i class="bi bi-arrow-left me-1"></i>Back</button>
    </div>
  </div>

  <form>
    <input type="hidden" name="page" value="<?= (int)$page ?>">
    <input name="q" value="<?= htmlspecialchars($q) ?>" class="search-input" placeholder="Search id, date, method…">
  </form>

  <div class="tabs">
    <?php
      $tabs = ['all'=>'All','pending'=>'Pending','completed'=>'Completed','failed'=>'Failed'];
      foreach($tabs as $k=>$label){
        $cls = $k===$tab ? 'tab active':'tab';
        $href = '?status='.$k.'&q='.urlencode($q).'&page=1';
        echo "<a class=\"$cls\" href=\"$href\">$label</a>";
      }
    ?>
  </div>

  <div id="list">
    <?php if (!$items): ?>
      <div class="item"><div class="icon"><i class="bi bi-info-circle"></i></div><div>No records.</div></div>
    <?php endif; ?>
    <?php foreach ($items as $it):
      $badge = $it['status']==='completed'?'text-bg-success':($it['status']==='failed'?'text-bg-danger':'text-bg-warning');
    ?>
      <div class="item" data-status="<?= htmlspecialchars($it['status']) ?>" data-id="<?= htmlspecialchars($it['id']) ?>" data-dt="<?= htmlspecialchars($it['when']) ?>">
        <div class="icon"><i class="bi bi-receipt"></i></div>
        <div class="flex-grow-1">
          <div style="font-weight:600"><?= htmlspecialchars($it['method']?:'—') ?> <span style="opacity:.7;font-size:.75rem">#<?= htmlspecialchars($it['id']) ?> • <?= htmlspecialchars($it['when']) ?></span></div>
          <div style="opacity:.85;font-size:.85rem"><?= htmlspecialchars($it['dest']?:'') ?></div>
        </div>
        <div class="side">
          <div style="font-weight:700"><?= htmlspecialchars(money_fmt($it['amount'])) ?></div>
          <span class="badge rounded-pill <?= $badge ?>"><?= strtoupper($it['status']) ?></span>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <form class="pagination-nav" method="get">
    <input type="hidden" name="q" value="<?= htmlspecialchars($q) ?>">
    <input type="hidden" name="status" value="<?= htmlspecialchars($tab) ?>">
    <button class="pg" name="page" value="<?= max(1,$page-1) ?>" <?= $page<=1?'disabled':'' ?>><i class="bi bi-chevron-left"></i></button>
    <?php foreach (pager_window($page,$pages) as $p): ?>
      <?php if ($p==='...'): ?><span class="pg">…</span>
      <?php else: $cls = ($p===$page)?'pg active':'pg'; ?>
        <button class="<?= $cls ?>" name="page" value="<?= (int)$p ?>"><?= (int)$p ?></button>
      <?php endif; ?>
    <?php endforeach; ?>
    <button class="pg" name="page" value="<?= min($pages,$page+1) ?>" <?= $page>=$pages?'disabled':'' ?>><i class="bi bi-chevron-right"></i></button>
  </form>
</div>

<script>
const items = Array.from(document.querySelectorAll('#list .item'));
document.getElementById('exportBtn').addEventListener('click',()=>{
  const rows = [["ID","Method","When","Amount","Status","Dest"]];
  items.forEach(i=>{
    rows.push([
      i.dataset.id || '',
      i.querySelector('.flex-grow-1 div').childNodes[0].textContent.trim(),
      i.dataset.dt || '',
      i.querySelector('.side div').innerText,
      i.querySelector('.badge').innerText,
      (i.querySelector('.flex-grow-1 div:nth-child(2)')?.innerText || '').trim()
    ]);
  });
  const csv = rows.map(r=>r.map(v=>`"${(v||'').replace(/"/g,'""')}"`).join(',')).join('\n');
  const url = URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
  const a = document.createElement('a'); a.href = url; a.download = 'withdraw_history.csv'; a.click();
  URL.revokeObjectURL(url);
});
</script>
</body>
</html>
