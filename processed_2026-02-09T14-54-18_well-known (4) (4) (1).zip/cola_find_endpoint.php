<?php
// ColaPay endpoint finder — tries common paths & tells which one is valid (200/401/403/405)
// Open in browser: https://<your-domain>/includes/payments/cola_find_endpoint.php

require_once __DIR__ . '/cola_config.php';

header('Content-Type:text/plain; charset=utf-8');

$base = rtrim(COLA_API_BASE,'/');

$candidates = [
  // Common create endpoints (adjust list if needed)
  '/api/pay/order/create',
  '/api/pay/create',
  '/api/order/create',
  '/pay/order/create',
  '/order/create',
  '/api/v1/pay/order/create',
  '/api/v1/order/create',
  '/merchant/order/create',
  '/open/api/pay/order/create',
  '/open-api/pay/order/create',
  '/payment/create',
  '/api/payment/create',
  '/api/payments/create',
  '/api/transaction/create',
  '/api/unified/order/create',
  '/api/pay/unifiedOrder',
  '/api/deposit/create',
  '/pay/createOrder',
];

function head_status($url){
  $ch=curl_init($url);
  curl_setopt_array($ch,[
    CURLOPT_NOBODY=>true,
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_TIMEOUT=>12,
    CURLOPT_FOLLOWLOCATION=>true,
  ]);
  curl_exec($ch);
  $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
  $err=curl_error($ch);
  curl_close($ch);
  return [$http,$err];
}

echo "BASE: $base\n\n";
$hits = [];
foreach($candidates as $p){
  $u = $base.$p;
  [$h,$e] = head_status($u);
  printf("%-45s -> HTTP %d %s\n", $p, $h, $e ? "($e)" : "");
  // Anything except 404 means the path exists (401/403/405/200…)
  if ($h && $h!=404) $hits[] = [$p,$h];
}

echo "\n---- RESULT ----\n";
if (!$hits){
  echo "❌ Abhi jitne common paths try kiye sab 404 aaye.\n";
  echo "➡ Docs khol ke 'create order' ka EXACT path copy karo aur cola_config.php me COLA_CREATE_URL update karo.\n";
} else {
  // Prefer 200/405/401/403 in that order
  usort($hits, function($a,$b){
    $score = function($h){ return ($h==200?4:($h==405?3:($h==401?2:($h==403?1:0)))); };
    return $score($b[1])<=>$score($a[1]);
  });
  [$best,$code] = $hits[0];
  echo "✅ Likely correct create path: $best   (HTTP $code)\n";
  echo "➡ Set in cola_config.php:\n";
  echo "   define('COLA_CREATE_URL', COLA_API_BASE . '$best');\n";
  echo "Phir recharge try karo.\n";
}
