<?php
require_once __DIR__ . "/includes/util.php";
require_login();

$pdo = app_pdo();
$uid = current_uid();

/* ------------------------------------------------------------------
   Ensure tables (tickets + replies)
-------------------------------------------------------------------*/
$pdo->exec("
CREATE TABLE IF NOT EXISTS support_tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  subject VARCHAR(160) NOT NULL,
  message TEXT NOT NULL,
  status ENUM('open','pending','closed') NOT NULL DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  KEY (user_id), KEY (status), KEY (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$pdo->exec("
CREATE TABLE IF NOT EXISTS support_replies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT NOT NULL,
  admin_id INT NULL,
  user_id INT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY (ticket_id), KEY (admin_id), KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

/* ------------------------------------------------------------------
   AJAX
-------------------------------------------------------------------*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  header('Content-Type: application/json; charset=utf-8');
  $action = $_POST['action'] ?? '';

  try {
    // create ticket
    if ($action === 'create_ticket') {
      $subject = trim((string)($_POST['subject'] ?? ''));
      $message = trim((string)($_POST['message'] ?? ''));
      if ($subject === '' || $message === '') {
        http_response_code(422);
        echo json_encode(['ok'=>false,'error'=>'Please fill subject and message.']);
        exit;
      }
      $ins = $pdo->prepare("INSERT INTO support_tickets (user_id, subject, message) VALUES (?,?,?)");
      $ins->execute([$uid, $subject, $message]);
      echo json_encode(['ok'=>true,'id'=>$pdo->lastInsertId()]);
      exit;
    }

    // list my tickets
    if ($action === 'list_tickets') {
      $st = $pdo->prepare("SELECT id, subject, status, created_at
                           FROM support_tickets
                           WHERE user_id=? ORDER BY id DESC LIMIT 100");
      $st->execute([$uid]);
      echo json_encode(['ok'=>true,'rows'=>$st->fetchAll(PDO::FETCH_ASSOC)]);
      exit;
    }

    // get single ticket (header + body)
    if ($action === 'get_ticket') {
      $id = (int)($_POST['id'] ?? 0);
      $st = $pdo->prepare("SELECT id, subject, message, status, created_at
                           FROM support_tickets
                           WHERE id=? AND user_id=? LIMIT 1");
      $st->execute([$id, $uid]);
      $row = $st->fetch(PDO::FETCH_ASSOC);
      if (!$row) {
        http_response_code(404);
        echo json_encode(['ok'=>false,'error'=>'Not found']);
        exit;
      }
      echo json_encode(['ok'=>true,'row'=>$row]);
      exit;
    }

    // NEW: fetch replies (admin/user) for a ticket
    if ($action === 'ticket_replies') {
      $id = (int)($_POST['id'] ?? 0);

      // ownership check
      $chk = $pdo->prepare("SELECT id FROM support_tickets WHERE id=? AND user_id=? LIMIT 1");
      $chk->execute([$id, $uid]);
      if (!$chk->fetch()) {
        http_response_code(404);
        echo json_encode(['ok'=>false,'error'=>'Ticket not found']);
        exit;
      }

      $rs = $pdo->prepare("
        SELECT id, admin_id, user_id, message, created_at
        FROM support_replies
        WHERE ticket_id=?
        ORDER BY id ASC
      ");
      $rs->execute([$id]);
      echo json_encode(['ok'=>true,'rows'=>$rs->fetchAll(PDO::FETCH_ASSOC)]);
      exit;
    }

    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Unknown action']);
  } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'Server error']);
  }
  exit;
}

/* Initial list */
$st = $pdo->prepare("SELECT id, subject, status, created_at
                     FROM support_tickets
                     WHERE user_id=? ORDER BY id DESC LIMIT 20");
$st->execute([$uid]);
$initial = $st->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <title>Support – Nebula Arcade</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root{
      --p:#8d78ff; --s:#ff57e6;
      --card:rgba(255,255,255,.08);
      --line:rgba(255,255,255,.12);
      --dim:rgba(255,255,255,.74);
    }
    *{box-sizing:border-box;margin:0;padding:0}
    body{
      font-family:Poppins,sans-serif;color:#fff;
      background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
      overflow-x:hidden;
    }
    body::after{
      content:"";position:fixed;inset:0;pointer-events:none;opacity:.05;
      mix-blend-mode:overlay;
      background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png');
      animation:grain 9s steps(10) infinite;
    }
    @keyframes grain{to{background-position:100% 100%}}
    .app{max-width:480px;margin:auto;padding:1.4rem 1rem 8.6rem}
    .brand{font-size:1.5rem;font-weight:700}
    .glass{background:var(--card);backdrop-filter:blur(18px);border:1px solid var(--line);border-radius:26px}
    .btn-main{border:none;border-radius:18px;padding:.6rem 1rem;font-size:.9rem;font-weight:600;background:var(--p);color:#fff;box-shadow:0 6px 22px rgba(141,120,255,.45)}
    .btn-main:active{transform:scale(.97)}

    /* tiles */
    .tile{flex:1;display:flex;flex-direction:column;align-items:center;gap:.35rem;padding:1rem;border-radius:20px;background:rgba(255,255,255,.06);border:2px solid transparent;cursor:pointer;transition:.25s;text-decoration:none;color:#fff}
    .tile:hover{border-color:var(--p);box-shadow:0 4px 16px rgba(141,120,255,.35)}
    .tile i{font-size:1.6rem}

    /* FAQ (Top Questions) */
    .faq-item{border-bottom:1px solid rgba(255,255,255,.08)}
    .faq-q{display:flex;justify-content:space-between;align-items:center;padding:1rem 0;cursor:pointer}
    .faq-q span{font-weight:600}
    .faq-q i{transition:.2s}
    .faq-a{display:none;padding:0 0 1rem;color:var(--dim);font-size:.9rem;line-height:1.45}

    /* tickets list */
    .row-card{display:flex;align-items:center;gap:.7rem;padding:.85rem;border-radius:16px;margin-bottom:.6rem;background:rgba(255,255,255,.06);border:1px solid var(--line);cursor:pointer}
    .row-card .badge{font-size:.7rem}

    /* dock */
    .dock{position:fixed;left:0;right:0;bottom:0;height:82px;z-index:10;backdrop-filter:blur(18px);background:rgba(14,10,30,.68);border-top:1px solid var(--line);display:grid;grid-template-columns:repeat(5,1fr);align-items:center;justify-items:center;padding:0 env(safe-area-inset-left,8px) 0 env(safe-area-inset-right,8px)}
    .nav-btn{color:var(--dim);text-decoration:none;font-size:.75rem;display:flex;flex-direction:column;align-items:center;gap:2px}
    .nav-btn .bi{font-size:1.4rem}.nav-btn.active{color:#fff}
    .fab{position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:64px;height:64px;border-radius:22px;background:var(--p);display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#fff;box-shadow:0 6px 24px rgba(141,120,255,.55);border:5px solid rgba(255,255,255,.05)}
    @media(max-width:350px){.nav-btn .bi{font-size:1.25rem}.nav-btn span{font-size:.63rem}}

    /* modal */
    .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.65);backdrop-filter:blur(4px);display:flex;align-items:flex-end;justify-content:center;opacity:0;pointer-events:none;transition:.3s;z-index:50}
    .modal-overlay.show{opacity:1;pointer-events:auto}
    .modal-window{width:100%;max-width:480px;max-height:80vh;overflow-y:auto;border-top-left-radius:26px;border-top-right-radius:26px;border:1px solid var(--line);background:rgba(24,22,45,.92);padding:1.4rem 1rem 2rem;animation:slideUp .35s ease;position:relative}
    @keyframes slideUp{from{transform:translateY(100%)}to{transform:none}}
    .close-x{position:absolute;top:18px;right:20px;font-size:1.35rem;cursor:pointer;opacity:.85}

    /* thread bubbles */
    .bubble-user{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.14);color:#fff}
    .bubble-admin{background:#5d45ff;border:1px solid rgba(255,255,255,.14);color:#fff}
  </style>
</head>
<body>
  <div class="app">
    <!-- Header -->
    <div class="d-flex align-items-center gap-2 mb-4">
      <i class="bi bi-arrow-left" style="cursor:pointer" onclick="history.back()"></i>
      <span class="brand">Support</span>
      <div class="ms-auto"><button id="ticketBtn" class="btn-main">Ticket</button></div>
    </div>

    <!-- Tiles -->
    <div class="d-flex gap-2 mb-3">
      <a class="tile" href="mailto:powerhosty6@gmail.com">
        <i class="bi bi-envelope"></i><span style="font-size:.82rem">Email</span>
      </a>
      <a class="tile" href="https://t.me/piyushbond" target="_blank" rel="noopener">
        <i class="bi bi-telegram"></i><span style="font-size:.82rem">Telegram</span>
      </a>
      <div class="tile" id="tileTicket">
        <i class="bi bi-ticket-perforated"></i><span style="font-size:.82rem">New Ticket</span>
      </div>
    </div>

    <!-- Top Questions -->
    <div class="glass p-3 mb-3">
      <h6 style="opacity:.8">Top Questions</h6>
      <div id="faqWrap">
        <div class="faq-item">
          <div class="faq-q"><span>How to reset my password?</span><i class="bi bi-chevron-down"></i></div>
          <div class="faq-a">Go to <b>Settings ▸ Security ▸ Change Password</b> and follow the instructions.</div>
        </div>
        <div class="faq-item">
          <div class="faq-q"><span>Why is my withdrawal pending?</span><i class="bi bi-chevron-down"></i></div>
          <div class="faq-a">Withdrawals are manually reviewed within <b>5–30 minutes</b> during support hours.</div>
        </div>
        <div class="faq-item">
          <div class="faq-q"><span>Which payment methods are supported?</span><i class="bi bi-chevron-down"></i></div>
          <div class="faq-a">We accept <b>UPI, Cards, Net-Banking</b> and <b>USDT (TRC20/BEP20)</b>.</div>
        </div>
        <div class="faq-item">
          <div class="faq-q"><span>Is my data safe on Nebula?</span><i class="bi bi-chevron-down"></i></div>
          <div class="faq-a">We use modern encryption (e.g., <b>AES-256</b>) and best practices to secure your data.</div>
        </div>
      </div>
    </div>

    <!-- My Tickets -->
    <div class="glass p-3">
      <h6 style="opacity:.8">My Tickets</h6>
      <div id="ticketList">
        <?php if (!$initial): ?>
          <div class="text-muted" style="font-size:.85rem">No tickets yet.</div>
        <?php else: foreach ($initial as $t): ?>
          <div class="row-card ticket-row" data-id="<?= (int)$t['id'] ?>">
            <div class="flex-grow-1">
              <div class="ticket-subj" style="font-weight:600"><?= htmlspecialchars($t['subject']) ?></div>
              <small style="opacity:.8"><?= date('d M Y, h:i A', strtotime($t['created_at'])) ?></small>
            </div>
            <span class="badge bg-<?= $t['status']==='open'?'warning':($t['status']==='pending'?'info':'secondary') ?>">
              <?= htmlspecialchars(ucfirst($t['status'])) ?>
            </span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>

  <!-- Modal root -->
  <div id="modal" class="modal-overlay"></div>

  <!-- Bottom Navigation -->
  <nav class="dock">
    <a href="/dashboard.php" class="nav-btn"><i class="bi bi-controller"></i><span>Arcade</span></a>
    <a href="/esports.php" class="nav-btn"><i class="bi bi-trophy"></i><span>eSports</span></a>
    <span></span>
    <a href="/chat.php" class="nav-btn active"><i class="bi bi-chat-dots-fill"></i><span>Chat</span></a>
    <a href="/profile.php" class="nav-btn"><i class="bi bi-person-circle"></i><span>Profile</span></a>
    <a href="/refer.php" class="fab"><i class="bi bi-lightning-fill"></i></a>
  </nav>

  <script>
  const modal = document.getElementById('modal');

  function openModal(html){
    modal.innerHTML = `<div class="modal-window">${html}<i class="bi bi-x-lg close-x"></i></div>`;
    modal.classList.add('show');
    modal.querySelector('.close-x').onclick = closeModal;
  }
  function closeModal(){
    modal.classList.remove('show');
    setTimeout(()=> modal.innerHTML = '', 300);
  }
  function toast(t){
    const d=document.createElement('div');
    d.textContent=t;
    d.style.cssText='position:fixed;bottom:110px;left:50%;transform:translateX(-50%);background:#fff;color:#000;padding:.75rem 1.2rem;border-radius:14px;font-weight:600;z-index:1000;opacity:0;transition:.34s';
    document.body.append(d); requestAnimationFrame(()=>d.style.opacity='1');
    setTimeout(()=>{d.style.opacity='0'; setTimeout(()=>d.remove(),350)},2000);
  }
  function escapeHtml(s){return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
  function cap(s){return (s||'').charAt(0).toUpperCase()+s.slice(1)}
  function fmtDate(iso){const d=new Date(iso.replace(' ','T'));return d.toLocaleString();}

  /* FAQ expand/collapse */
  document.querySelectorAll('.faq-q').forEach(q=>{
    q.onclick=()=>{
      const a=q.nextElementSibling, ic=q.querySelector('i');
      const open=a.style.display==='block';
      a.style.display=open?'none':'block';
      ic.classList.toggle('bi-chevron-down', open);
      ic.classList.toggle('bi-chevron-up', !open);
    };
  });

  // Open ticket modal (Subject + Message)
  document.getElementById('ticketBtn').onclick = openTicket;
  document.getElementById('tileTicket').onclick = openTicket;

  function openTicket(){
    openModal(`
      <div class="d-flex align-items-center gap-2 mb-3">
        <i class="bi bi-ticket-perforated-fill" style="font-size:1.4rem"></i>
        <h5 class="m-0">New Ticket</h5>
      </div>
      <form id="ticketForm">
        <label class="form-label">Subject</label>
        <input name="subject" class="form-control mb-3" placeholder="Subject" required>
        <label class="form-label">Message</label>
        <textarea name="message" class="form-control" rows="4" placeholder="Message" required></textarea>
        <button class="btn-main w-100 mt-3" type="submit" disabled>Submit</button>
      </form>
    `);

    // Enable submit only when both fields filled
    const form = modal.querySelector('#ticketForm');
    const subj = form.querySelector('input[name="subject"]');
    const msg  = form.querySelector('textarea[name="message"]');
    const btn  = form.querySelector('button[type="submit"]');
    function validate(){ btn.disabled = !(subj.value.trim() && msg.value.trim()); }
    subj.addEventListener('input', validate);
    msg.addEventListener('input', validate);
    validate();
  }

  // Submit ticket → DB
  modal.addEventListener('submit', async (e)=>{
    if (e.target.id !== 'ticketForm') return;
    e.preventDefault();
    const fd = new URLSearchParams(new FormData(e.target));
    fd.append('action','create_ticket');
    try{
      const r = await fetch(location.href, {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:fd
      });
      const d = await r.json();
      if(!d.ok) throw new Error(d.error||'Failed');
      toast('Ticket submitted!');
      closeModal();
      await refreshTickets();
    }catch(err){
      toast('⚠️ '+(err.message||'Error'));
    }
  });

  // Click on ticket row → open full message + thread
  document.getElementById('ticketList').addEventListener('click', async (e)=>{
    const row = e.target.closest('.ticket-row');
    if (!row) return;
    const id = row.getAttribute('data-id');
    try{
      const r = await fetch(location.href, {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({action:'get_ticket', id})
      });
      const d = await r.json();
      if(!d.ok) throw new Error(d.error||'Not found');
      const t = d.row;
      openModal(`
        <div class="d-flex align-items-center gap-2 mb-2">
          <i class="bi bi-ticket-perforated-fill" style="font-size:1.2rem"></i>
          <h5 class="m-0">Ticket #${t.id}</h5>
        </div>
        <div class="mb-2" style="opacity:.85"><small>${fmtDate(t.created_at)} • ${cap(t.status)}</small></div>

        <div class="glass p-3 mb-2" style="border-radius:16px">
          <div style="font-weight:700;margin-bottom:.4rem">${escapeHtml(t.subject)}</div>
          <div style="white-space:pre-wrap;opacity:.95">${escapeHtml(t.message)}</div>
        </div>

        <div id="thread" class="glass p-3" style="border-radius:16px; max-height:45vh; overflow:auto">
          <div class="text-muted" style="font-size:.85rem">Loading replies…</div>
        </div>
      `);
      loadReplies(t.id);
    }catch(err){
      toast('⚠️ '+(err.message||'Error opening ticket'));
    }
  });

  // Load replies (admin/user) and render thread
  async function loadReplies(ticketId){
    try{
      const r = await fetch(location.href, {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({action:'ticket_replies', id:ticketId})
      });
      const d = await r.json();
      const box = document.getElementById('thread');
      if(!box) return;
      if(!d.ok){ box.innerHTML = `<div class="text-danger small">${escapeHtml(d.error||'Failed to load')}</div>`; return; }
      if(!d.rows.length){ box.innerHTML = `<div class="text-muted" style="font-size:.85rem">No replies yet.</div>`; return; }

      box.innerHTML = d.rows.map(row=>{
        const isAdmin = row.admin_id && row.admin_id !== '0' && row.admin_id !== 0;
        const side = isAdmin ? 'right' : 'left';
        const who  = isAdmin ? 'Admin' : 'You';
        return `
          <div style="display:flex; ${side==='right'?'justify-content:flex-end':''}; margin:.35rem 0">
            <div class="${isAdmin?'bubble-admin':'bubble-user'}" style="max-width:82%;padding:.6rem .8rem;border-radius:14px;">
              <div style="white-space:pre-wrap">${escapeHtml(row.message||'')}</div>
              <div style="opacity:.75;font-size:.75rem;margin-top:.25rem;text-align:${side==='right'?'right':'left'}">
                ${who} • ${fmtDate(row.created_at)}
              </div>
            </div>
          </div>`;
      }).join('');
      box.scrollTop = box.scrollHeight;
    }catch(e){
      const box = document.getElementById('thread');
      if(box) box.innerHTML = `<div class="text-danger small">Network error</div>`;
    }
  }

  // Refresh ticket list (after create)
  async function refreshTickets(){
    try{
      const r = await fetch(location.href, {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({action:'list_tickets'})
      });
      const d = await r.json();
      if(!d.ok) return;
      const list = document.getElementById('ticketList');
      list.innerHTML = '';
      if(!d.rows.length){
        list.innerHTML = '<div class="text-muted" style="font-size:.85rem">No tickets yet.</div>';
        return;
      }
      d.rows.forEach(t=>{
        const badge = t.status==='open'?'warning':(t.status==='pending'?'info':'secondary');
        list.insertAdjacentHTML('beforeend', `
          <div class="row-card ticket-row" data-id="${t.id}">
            <div class="flex-grow-1">
              <div class="ticket-subj" style="font-weight:600">${escapeHtml(t.subject)}</div>
              <small style="opacity:.8">${fmtDate(t.created_at)}</small>
            </div>
            <span class="badge bg-${badge}">${cap(t.status)}</span>
          </div>
        `);
      });
    }catch{}
  }
  </script>
</body>
</html>
