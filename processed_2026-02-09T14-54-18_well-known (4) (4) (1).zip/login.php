<?php
require_once __DIR__."/includes/util.php"; //The perfect provide 

/* ---------- Handle Login POST ---------- */
$login_error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // sanitize: keep digits + '+' only
  $mobile = preg_replace('/[^0-9+]/', '', (string)($_POST['mobile_number'] ?? ''));
  $password = (string)($_POST['password'] ?? '');
  $remember = isset($_POST['remember_me']);

  if ($mobile === '' || $password === '') {
    $login_error = "Please enter both mobile and password.";
  } else {
    $st = app_pdo()->prepare("SELECT user_id, pass_hash, role FROM users WHERE user_id = ?");
    $st->execute([$mobile]);
    $u = $st->fetch();
    if ($u && password_verify($password, $u['pass_hash'])) {
      // success: set session
      $_SESSION['uid']  = $u['user_id'];
      $_SESSION['role'] = $u['role'];

      // 'Remember me' — extend session cookie lifetime (simple approach)
      if ($remember && session_status() === PHP_SESSION_ACTIVE) {
        $params = session_get_cookie_params();
        setcookie(session_name(), session_id(), [
          'expires'  => time() + 60*60*24*30, // 30 days
          'path'     => $params['path'],
          'domain'   => $params['domain'],
          'secure'   => isset($_SERVER['HTTPS']),
          'httponly' => true,
          'samesite' => 'Lax'
        ]);
      }

      header("Location: /dashboard.php");
      exit;
    } else {
      $login_error = "Invalid mobile number or password.";
    }
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport"
        content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
  <title><?= htmlspecialchars(app_name()) ?> — Log In</title>

  <!-- Fonts & libs -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <!-- 🌌 Nebula UI CORE -->
  <style>
    :root{
      --clr-primary:#8d78ff;
      --clr-card-bg:rgba(255,255,255,.08);
      --clr-glass-line:rgba(255,255,255,.12);
      --clr-dim:rgba(255,255,255,.74);
    }
    *{box-sizing:border-box;}
    html, body { margin:0; padding:0; width:100%; height:100%; touch-action:manipulation; }

    /* PERFECT CENTER on all devices */
    body{
      font-family:'Poppins',sans-serif; color:#fff;
      background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
      min-height:100vh; overflow-x:hidden;

      display:flex; align-items:center; justify-content:center; /* center */
    }

    body::after{content:"";position:fixed;inset:0;pointer-events:none;opacity:.05;mix-blend-mode:overlay;
      animation:grain 9s steps(10) infinite;}
    @keyframes grain{0%{background-position:0 0;}100%{background-position:100% 100%}}

    .app{ max-width:480px; width:100%; margin:0 auto; padding:1rem .75rem; position:relative; z-index:1; }
    .glass{
      background:var(--clr-card-bg); backdrop-filter:blur(16px);
      border:1px solid var(--clr-glass-line); border-radius:26px;
      padding:1.5rem; display:flex; flex-direction:column;
      box-shadow:0 24px 70px rgba(0,0,0,.55), inset 0 0 0 1px rgba(255,255,255,.06);
    }

    .form-control,.form-select{
      background:rgba(255,255,255,.05)!important;
      color:#fff!important;
      border:1px solid var(--clr-glass-line)!important;
      border-radius:14px; padding:.9rem 1rem; font-size:1rem;
    }
    .form-control:focus,.form-select:focus{ box-shadow:none; border-color:var(--clr-primary); }
    .form-control::placeholder { color: rgba(230,230,255,.6) !important; opacity:1 !important; }

    .btn-login{
      width:100%; padding:1.1rem; border:none; border-radius:18px;
      font-weight:600; font-size:1.05rem;
      background:var(--clr-primary); box-shadow:0 6px 22px rgba(141,120,255,.45);
      margin-top:1.5rem;
    }
    .btn-login:active{ transform:scale(.97); }
    .instructions{ font-size:.85rem; color:var(--clr-dim); line-height:1.5; margin-bottom:1.2rem; }
    a.text-link{color:var(--clr-primary); text-decoration:none;}
    a.text-link:hover{text-decoration:underline;}

    @media(max-width:400px){
      .app{ padding:1rem .5rem; }
      .instructions{ font-size:.9rem; }
      .btn-login{ padding:.95rem; font-size:1rem; }
    }
  </style>
</head>
<body>

  <div class="app">
    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div class="brand">
        <a class="text-link" href="/" style="text-decoration:none;color:#e6e6ff;">
          <i class="bi bi-arrow-left"></i>&nbsp;Log In
        </a>
      </div>
      <a href="/register.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Sign Up</a>
    </div>

    <!-- LOGIN FORM -->
    <div class="glass">
      <h5 class="mb-3" style="opacity:.9;">Welcome Back</h5>
      <p class="instructions">Enter your credentials to access your account</p>

      <form id="loginForm" method="POST" action="">
        <div class="mb-3">
          <label class="form-label">Mobile Number</label>
          <input type="tel" class="form-control" placeholder="Enter Mobile Number"
                 pattern="[\d+\s]+" required name="mobile_number" autocomplete="username">
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" placeholder="●●●●●●"
                 minlength="6" required name="password" autocomplete="current-password">
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="rememberMe" name="remember_me">
            <label class="form-check-label small" for="rememberMe">Remember Me</label>
          </div>
          <a href="#" class="text-link small" onclick="Swal.fire('Info','Forgot password flow coming soon.','info');return false;">Forgot Password?</a>
        </div>

        <button class="btn-login" type="submit">Log In</button>
      </form>
    </div>
  </div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <?php if (!empty($login_error)): ?>
  <script>
    Swal.fire({
      icon: 'error',
      title: 'Login failed',
      text: <?= json_encode($login_error) ?>,
      confirmButtonText: 'OK',
      confirmButtonColor: '#8d78ff',
      background: 'rgba(0,0,0,0.85)',
      color: '#fff'
    });
  </script>
  <?php endif; ?>
</body>
</html>
