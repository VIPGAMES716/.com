<?php
/* ---- SECRET ---- */
$SECRET = 'CHANGE_ME_32_CHAR_SECRET';
if (!isset($_GET['key']) || $_GET['key'] !== $SECRET) { http_response_code(403); exit('Forbidden'); }

/* ---- DB ---- */
$DB_HOST = 'localhost';
$DB_NAME = 'demotrus_kdx';
$DB_USER = 'demotrus_kdx';
$DB_PASS = 'demotrus_kdx';

try {
  $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Throwable $e) {
  http_response_code(500); exit("DB connect error: ".$e->getMessage());
}

/* columns ensure */
try {
  $pdo->exec("ALTER TABLE games
    ADD COLUMN IF NOT EXISTS image_url VARCHAR(255) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS category  VARCHAR(32)  DEFAULT 'Arcade',
    ADD COLUMN IF NOT EXISTS external_id VARCHAR(64) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS online_count INT        DEFAULT 0,
    ADD COLUMN IF NOT EXISTS play_url   VARCHAR(512) DEFAULT NULL
  ");
} catch (Throwable $e) {}

/* same $games array as above (shortened here for brevity) */
$games = [
  ['chicken-road','Chicken Road','https://yoloplay.b-cdn.net/img/home/chickenroad.png','Chicken','2126c5c458316ba1f2df65b387b60408',212],
  ['pelanty-unlimited','Pelanty Unlimited','https://yoloplay.b-cdn.net/img/home/pelantyunlimited.png','Arcade','66d311ff6cf531e40b61c483dd34c5c9',212],
  /* ... paste the full list from Option A ... */
  ['cryptos','Cryptos','https://yoloplay.b-cdn.net/img/home/cryptos.png','Arcade','445289d56c9ee8fa590bf6b29b13dc37',213],
];

$pdo->exec("CREATE TABLE IF NOT EXISTS games (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(128) NOT NULL UNIQUE,
  title VARCHAR(128) NOT NULL,
  enabled TINYINT(1) DEFAULT 1,
  image_url VARCHAR(255) DEFAULT NULL,
  category VARCHAR(32) DEFAULT 'Arcade',
  external_id VARCHAR(64) DEFAULT NULL,
  online_count INT DEFAULT 0,
  play_url VARCHAR(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$ins = $pdo->prepare("
  INSERT INTO games (slug,title,enabled,image_url,category,external_id,online_count)
  VALUES (?,?,?,?,?,?,?)
  ON DUPLICATE KEY UPDATE
    title=VALUES(title),
    image_url=VALUES(image_url),
    category=VALUES(category),
    external_id=VALUES(external_id),
    online_count=VALUES(online_count),
    enabled=VALUES(enabled)
");

$cnt=0;
foreach($games as $g){ $ins->execute([$g[0],$g[1],1,$g[2],$g[3],$g[4],(int)$g[5]]); $cnt++; }

header('Content-Type: text/plain'); echo "✅ Seeded {$cnt} games. Delete this file.";
