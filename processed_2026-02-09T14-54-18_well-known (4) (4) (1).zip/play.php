<?php
require_once __DIR__."/includes/util.php";
require_login(); // Ensure user is logged in

$game = $_GET['game'] ?? 'chicken-road';

// Get logged-in user numeric id from DB
$session_user_id = $_SESSION['user_id'] ?? null;

if (!$session_user_id) {
    html_head("Error");
    echo "<div class='card'><p class='danger'>User session not found.</p></div>";
    html_foot();
    exit;
}

$conn = new mysqli("localhost","demotrus_kdx","demotrus_kdx","demotrus_kdx");
if ($conn->connect_error) {
    html_head("Error");
    echo "<div class='card'><p class='danger'>Database connection failed: ".$conn->connect_error."</p></div>";
    html_foot();
    exit;
}

// Fetch numeric id and current balance
$stmt = $conn->prepare("SELECT id, balance FROM users WHERE user_id = ? LIMIT 1");
$stmt->bind_param("s", $session_user_id);
$stmt->execute();
$stmt->bind_result($db_id, $balance);
$stmt->fetch();
$stmt->close();

if (!$db_id) {
    html_head("Error");
    echo "<div class='card'><p class='danger'>User not found in database.</p></div>";
    html_foot();
    exit;
}

// Transfer balance to motta and set balance to 0
// Transfer balance to motta (add) and set balance to 0
$update_stmt = $conn->prepare("UPDATE users SET motta = motta + ?, balance = '0' WHERE id = ?");
$update_stmt->bind_param("di", $balance, $db_id); // "d" for double/decimal, "i" for integer id
$update_stmt->execute();
$update_stmt->close();


// Construct the play URL using numeric id
$playBase = "https://wuttsghdijsbbsh.yrehdjsfiafkjgkjgfsasc.yachts/sjcftrnicgfhfvfghdvhfvytyhthvrthtrhvrthrthrfrthtrhvrthvrthvcrthrthvctrvhtrhvrhcyhtyhrthr/inout";

$playUrl = $playBase . "?" . http_build_query([
    'userid' => $db_id,   
    'gameid' => $game,
    'callbackurl' => 'https://demo.trushme.xyz/api/inout.php'
]);

html_head("Play — " . htmlspecialchars($game));
?>

<style>
html, body {
    height: 100vh;
    margin: 0;
    padding: 0;
    background: #1e1e2f;
    color: #ffffff;
    font-family: Arial, sans-serif;
}

.card {
    height: 90vh;
    max-width: 800px;
    margin: -20px -10px 20px -10px;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    padding: 10px;
    background: #2a2a3f;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.5);
}

.card iframe {
    flex: 1 1 auto;
    width: 100%;
    border: none;
    border-radius: 8px;
    background: #000000;
}

.card p.danger {
    color: #ff6b6b;
    text-align: center;
    font-weight: bold;
}

.card h4 {
    text-align: center;
    padding: 10px 0;
    color: #4ecdc4;
}
</style>

<div class="card">
    <iframe src="<?= htmlspecialchars($playUrl) ?>" 
        allowfullscreen
        sandbox="allow-scripts allow-same-origin allow-forms">
    </iframe>
</div>

<?php
html_foot();
?>
