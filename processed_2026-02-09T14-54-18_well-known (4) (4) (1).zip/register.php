<?php
// register.php — Fully working signup + referral bonus (signup-based)
require_once __DIR__."/includes/util.php";
$pdo = app_pdo();

/* ---------- Ensure referral tables (safe to re-run) ---------- */
$pdo->exec("CREATE TABLE IF NOT EXISTS referral_codes (
  user_id    VARCHAR(64) PRIMARY KEY,
  code       VARCHAR(32) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$pdo->exec("CREATE TABLE IF NOT EXISTS referrals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  referrer_id     VARCHAR(64) NOT NULL,
  referred_id     VARCHAR(64) DEFAULT NULL,
  referred_mobile VARCHAR(32) DEFAULT NULL,
  status ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  note   VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY (referrer_id), KEY (referred_id), KEY (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* ---------- Capture ?ref=CODE and keep for form ---------- */
if (!empty($_GET['ref'])) {
  $_SESSION['pending_ref_code'] = preg_replace('/[^A-Za-z0-9]/','', $_GET['ref']);
}
$prefillRef = $_SESSION['pending_ref_code'] ?? '';

/* ---------- Helpers ---------- */
function make_ref_code(string $uid): string {
  // 12–16 char mixed code; regenerate on collision
  $base = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
  return $base . substr(strtoupper(md5($uid)), 0, 4);
}
function ensure_user_ref_code(PDO $pdo, string $uid): string {
  $st = $pdo->prepare("SELECT code FROM referral_codes WHERE user_id=?");
  $st->execute([$uid]);
  if ($r = $st->fetch()) return $r['code'];

  // generate until unique
  while (true) {
    $code = make_ref_code($uid);
    try {
      $ins = $pdo->prepare("INSERT INTO referral_codes (user_id, code) VALUES (?,?)");
      $ins->execute([$uid, $code]);
      return $code;
    } catch (Throwable $e) {
      // collision -> loop
    }
  }
}

/* ---------- Handle Sign Up POST ---------- */
$reg_error = "";
$reg_ok = false;
$APP_NAME = app_name();
$REF_BONUS = 50.0; // signup bonus paid to REFERRER when their code is used

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name    = trim((string)($_POST['full_name'] ?? ''));
  $mobile  = preg_replace('/[^0-9+]/', '', (string)($_POST['mobile_number'] ?? '')); // keep digits & '+'
  $pass    = (string)($_POST['password'] ?? '');
  $terms   = isset($_POST['terms']);

  // Referral code from form, else the captured ?ref session
  $refCode = trim((string)($_POST['referral_code'] ?? ''));
  if ($refCode === '' && !empty($_SESSION['pending_ref_code'])) {
    $refCode = $_SESSION['pending_ref_code'];
  }
  $refCode = preg_replace('/[^A-Za-z0-9]/','', $refCode);

  if ($name === '' || $mobile === '' || $pass === '' || !$terms) {
    $reg_error = "Please fill all required fields and accept Terms.";
  } elseif (strlen($pass) < 6) {
    $reg_error = "Password must be at least 6 characters.";
  } else {
    try {
      // Check duplicate (we use mobile as user_id)
      $st = $pdo->prepare("SELECT 1 FROM users WHERE user_id=? LIMIT 1");
      $st->execute([$mobile]);
      if ($st->fetch()) {
        $reg_error = "This mobile is already registered. Please log in.";
      } else {
        $pdo->beginTransaction();

        // Create user
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO users (user_id, pass_hash, name) VALUES (?,?,?)")
            ->execute([$mobile, $hash, $name]);

        // Give the new user their own referral code
        ensure_user_ref_code($pdo, $mobile);

        // If a referral code was used, credit the REFERRER immediately (one-time per referred user)
        if ($refCode !== '') {
          // Find referrer by code
          $q = $pdo->prepare("SELECT user_id FROM referral_codes WHERE code=? LIMIT 1");
          $q->execute([$refCode]);
          if ($row = $q->fetch()) {
            $referrer = (string)$row['user_id'];

            // Prevent self-referral
            if ($referrer !== $mobile) {
              // If a referral row already exists for this referred user, lock it
              $ck = $pdo->prepare("SELECT id, status FROM referrals WHERE referred_id=? LIMIT 1 FOR UPDATE");
              $ck->execute([$mobile]);
              $ex = $ck->fetch(PDO::FETCH_ASSOC);

              if (!$ex) {
                // Fresh: insert as PAID and credit referrer balance now
                $pdo->prepare("INSERT INTO referrals (referrer_id, referred_id, status, amount, note)
                               VALUES (?,?,?,?,?)")
                    ->execute([$referrer, $mobile, 'paid', $REF_BONUS, 'signup bonus']);
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?")
                    ->execute([$REF_BONUS, $referrer]);
              } elseif (strtolower($ex['status']) === 'pending') {
                // If some pending record exists, finalize & credit
                $pdo->prepare("UPDATE referrals SET status='paid', amount=?, note='signup bonus' WHERE id=?")
                    ->execute([$REF_BONUS, (int)$ex['id']]);
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?")
                    ->execute([$REF_BONUS, $referrer]);
              }
              // If already paid -> do nothing (one-time)
            }
          }
        }

        $pdo->commit();
        $reg_ok = true;
        unset($_SESSION['pending_ref_code']);
      }
    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $reg_error = "Server error while creating account. Try again.";
    }
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
  <title><?= htmlspecialchars($APP_NAME) ?> — Sign Up</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    :root{
      --clr-primary:#8d78ff; --clr-card-bg:rgba(255,255,255,.08);
      --clr-glass-line:rgba(255,255,255,.12); --clr-placeholder:rgba(255,255,255,.6);
    }
    *{box-sizing:border-box}
    html,body{margin:0;height:100%}
    body{
      font-family:Poppins,system-ui,Segoe UI,Arial,sans-serif; color:#fff;
      background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
      min-height:100vh; display:flex; align-items:center; justify-content:center; overflow-x:hidden;
    }
    .app{max-width:480px;width:100%;padding:1rem .75rem}
    .glass{
      background:var(--clr-card-bg); backdrop-filter:blur(16px);
      border:1px solid var(--clr-glass-line); border-radius:26px;
      padding:1.5rem; box-shadow:0 24px 70px rgba(0,0,0,.55), inset 0 0 0 1px rgba(255,255,255,.06);
    }
    .form-control,.form-select{
      background:rgba(255,255,255,.05)!important; color:#fff!important;
      border:1px solid var(--clr-glass-line)!important; border-radius:14px;
      padding:.9rem 1rem; font-size:1rem;
    }
    .form-control:focus,.form-select:focus{box-shadow:none;border-color:var(--clr-primary)}
    .form-control::placeholder{color:var(--clr-placeholder)!important}
    .btn-sign{
      width:100%;padding:1.1rem;border:none;border-radius:18px;font-weight:600;font-size:1.05rem;
      background:var(--clr-primary);box-shadow:0 6px 22px rgba(141,120,255,.45);margin-top:1.1rem;
    }
    .bad{background:#ff5d71;padding:.7rem 1rem;border-radius:14px;margin-bottom:10px}
    .topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
    .topbar a{color:#e6e6ff;text-decoration:none;font-weight:700}
  </style>
</head>
<body>
  <div class="app">
    <div class="topbar">
      <a href="/login.php"><i class="bi bi-arrow-left"></i>&nbsp;Create Account</a>
      <a href="/login.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Log&nbsp;In</a>
    </div>

    <div class="glass">
      <h5 class="mb-3" style="opacity:.9;">Join <?= htmlspecialchars($APP_NAME) ?> &amp; Play</h5>
      <p class="text-light-50" style="opacity:.7">Register in a minute, get started 🚀</p>

      <?php if ($reg_error): ?>
        <div class="bad"><?= htmlspecialchars($reg_error) ?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="full_name" class="form-control" placeholder="Rahul Sharma" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Mobile Number</label>
          <input type="tel" name="mobile_number" class="form-control"
                 placeholder="+91 9876543210" pattern="^\+?\d{10,15}$" required autocomplete="tel">
        </div>

        <div class="mb-3">
          <label class="form-label">Country</label>
          <select name="country" class="form-select" required>
            <option value="" disabled hidden>Select Country</option>
            <option value="India" selected>🇮🇳 India</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control"
                 placeholder="●●●●●●" minlength="6" required autocomplete="new-password">
        </div>

        <div class="mb-3">
          <label class="form-label">Referral Code <span style="opacity:.6">(optional)</span></label>
          <input type="text" name="referral_code" class="form-control" placeholder="YOURFRIENDCODE"
                 value="<?= htmlspecialchars($prefillRef) ?>">
        </div>

        <div class="form-check mb-3">
          <input type="checkbox" id="terms" name="terms" class="form-check-input" required>
          <label class="form-check-label small" for="terms">
            I accept the Terms &amp; Conditions
          </label>
        </div>

        <button type="submit" class="btn-sign">Sign Up</button>
      </form>
    </div>
  </div>

  <?php if ($reg_ok): ?>
  <script>
    (function(){
      Swal.fire({
        icon: 'success',
        title: 'Account created!',
        text: 'Please log in with your mobile & password.',
        confirmButtonText: 'Go to Log In',
        confirmButtonColor: '#8d78ff',
        background: 'rgba(0,0,0,0.85)', color: '#fff'
      }).then(()=>{ window.location.href = '/login.php'; });
    })();
  </script>
  <?php endif; ?>
</body>
</html>
