<?php
// refer.php — Referral HQ (no navigation)
// Requires: includes/util.php with require_login(), app_pdo(), current_uid()

require_once __DIR__ . '/includes/util.php';
require_login();

$pdo = app_pdo();
$uid = (string) current_uid();

/* ---------- Create tables if missing ---------- */
$pdo->exec("CREATE TABLE IF NOT EXISTS referral_codes (
  user_id    VARCHAR(64) PRIMARY KEY,
  code       VARCHAR(32) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$pdo->exec("CREATE TABLE IF NOT EXISTS referrals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  referrer_id     VARCHAR(64) NOT NULL,
  referred_id     VARCHAR(64) DEFAULT NULL,
  referred_mobile VARCHAR(32) DEFAULT NULL,
  status ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  note   VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY (referrer_id), KEY (referred_id), KEY (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* ---------- Ensure/get referral code ---------- */
function ensure_ref_code(PDO $pdo, string $userId): string {
  $q = $pdo->prepare("SELECT code FROM referral_codes WHERE user_id=?");
  $q->execute([$userId]);
  if ($row = $q->fetch()) return $row['code'];

  $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)) . substr(md5($userId), 0, 4);
  for ($i=0; $i<5; $i++) {
    try {
      $ins = $pdo->prepare("INSERT INTO referral_codes (user_id, code) VALUES (?,?)");
      $ins->execute([$userId, $code]);
      return $code;
    } catch (Throwable $e) {
      $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)) . substr(md5($userId.microtime(true)),0,4);
    }
  }
  return $code;
}
$refCode = ensure_ref_code($pdo, $uid);

/* ---------- Stats ---------- */
$st = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE referrer_id=?");
$st->execute([$uid]); $totalInvites = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM referrals WHERE referrer_id=? AND status='paid'");
$st->execute([$uid]); $totalBonuses = (float)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(DISTINCT referred_id) FROM referrals WHERE referrer_id=? AND status='paid' AND referred_id IS NOT NULL AND referred_id<>''");
$st->execute([$uid]); $activeUsers = (int)$st->fetchColumn();

/* ---------- Rows ---------- */
$rowsStmt = $pdo->prepare("
  SELECT id, referred_id, referred_mobile, status, amount, created_at
  FROM referrals
  WHERE referrer_id=?
  ORDER BY id DESC
  LIMIT 100
");
$rowsStmt->execute([$uid]);
$rows = $rowsStmt->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Payload ---------- */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$payload = [
  'code' => $refCode,
  'stats'=> ['invites'=>$totalInvites,'bonuses'=>(float)$totalBonuses,'active'=>$activeUsers],
  'milestones'=>[
    ['target'=>10,'reward'=>500],
    ['target'=>20,'reward'=>1000],
    ['target'=>50,'reward'=>3000],
  ],
  'ach'=>[
    ['icon'=>'bi-fire','label'=>'5 day streak'],
    ['icon'=>'bi-people','label'=>'10 invites'],
  ],
  'rows'=>array_map(function($r){
    $name = $r['referred_id'] ?: ($r['referred_mobile'] ?: 'Guest');
    return [
      'name'=>$name,
      'date'=>date('d M Y', strtotime($r['created_at'])),
      'amt'=>(float)$r['amount'],
      'status'=>strtolower($r['status']),
      'avatar'=>substr(sha1(($r['referred_id']??'').($r['created_at']??'')),0,10),
    ];
  }, $rows),
];
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on' ? 'https' : 'http').'://'.$_SERVER['HTTP_HOST'];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Referral HQ</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--card:rgba(255,255,255,.08);--line:rgba(255,255,255,.12);--p:#8d78ff;--s:#ff57e6;--ok:#22c55e;--warn:#eab308;--bad:#ef4444}
*{box-sizing:border-box} body{margin:0;color:#fff;background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%)}
.app{max-width:480px;margin:0 auto;padding:18px 14px 40px;font-family:Poppins,system-ui,-apple-system,Segoe UI,Roboto,Arial}
.title{font-size:26px;font-weight:800;letter-spacing:.3px;margin:0 0 10px}
.hero{position:relative;border-radius:26px;padding:18px;border:1px solid var(--line);background:linear-gradient(145deg,rgba(21,17,42,.58),rgba(14,11,32,.92));box-shadow:0 0 18px rgba(141,120,255,.28) inset;margin-bottom:12px}
.hero h2{margin:0 0 8px;font-size:18px;font-weight:800}
.code-row{display:flex;align-items:center;gap:.6rem;font-weight:700}
.copy{display:inline-flex;align-items:center;gap:.35rem;border:none;padding:.45rem .85rem;border-radius:14px;background:#fff;color:#000;font-weight:700}
.progress{height:6px;border-radius:3px;background:rgba(255,255,255,.22);margin-top:10px}
.progress>div{height:100%;width:0;border-radius:inherit;background:#fff}
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:.7rem;margin:12px 0}
.card{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:.75rem;text-align:center}
.card small{display:block;opacity:.8;font-size:.7rem}
.card b{display:block;font-size:1.05rem;margin-top:.15rem}
.tabs{display:flex;gap:.6rem;margin:2px 0 10px}
.tab{flex:1;text-align:center;padding:.55rem 0;border-radius:16px;background:rgba(255,255,255,.08);border:1px solid var(--line);cursor:pointer;font-weight:700}
.tab.active{background:var(--p)}
.section{display:none}.section.show{display:block}
.milestone{display:flex;align-items:center;gap:16px;padding:14px;border-radius:22px;margin-bottom:10px;background:rgba(255,255,255,.06);border:1px solid var(--line)}
.circle{position:relative;width:62px;height:62px}
.circle svg{transform:rotate(-90deg)} .circle circle{fill:none;stroke-width:8;stroke-linecap:round}
.circle .bg{stroke:rgba(255,255,255,.22)} .circle .prog{stroke:#fff}
.circle span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem}
.ms-main{flex:1} .lock{padding:.2rem .6rem;border:1px solid var(--line);border-radius:999px;font-size:.7rem;opacity:.9}
.ach-strip{display:flex;gap:.7rem;padding:6px 4px}
.ach{width:60px;height:60px;border-radius:16px;background:var(--card);border:1px solid var(--line);display:flex;flex-direction:column;align-items:center;justify-content:center}
.ach small{font-size:.55rem;margin-top:2px;opacity:.9}
.pills{display:flex;gap:.5rem;justify-content:center;margin:10px 0 12px}
.pill{padding:.35rem .9rem;border-radius:999px;border:1px solid var(--line);background:var(--card);cursor:pointer}
.pill.active{background:var(--p)}
.list .row{display:flex;align-items:center;gap:.8rem;padding:.8rem;border-radius:18px;margin-bottom:8px;background:rgba(255,255,255,.06);border:1px solid var(--line)}
.row img{width:44px;height:44px;border-radius:50%;border:2px solid var(--line);object-fit:cover}
.row .main{flex:1} .row h6{margin:0;font-size:.95rem} .row small{opacity:.8}
.row .amt{font-weight:800}
.row .paid{color:var(--ok)} .row .pending{color:var(--warn)} .row .failed{color:var(--bad)}
.btn-wide{display:block;width:100%;margin:12px 0;padding:.9rem;border-radius:18px;border:none;font-weight:700;background:linear-gradient(135deg,#8d78ff,#ff57e6);color:#fff}
</style>
</head>
<body>
<div class="app">
  <div class="title">Referral HQ</div>

  <div class="hero">
    <h2>Earn up to 40 % lifetime</h2>
    <div class="code-row">
      <span>Code <b id="code"><?= h($refCode) ?></b></span>
      <button id="copy" class="copy"><i class="bi bi-clipboard"></i> Copy</button>
    </div>
    <div class="progress"><div id="bar"></div></div>
  </div>

  <div class="cards">
    <div class="card"><small>Total Invites</small><b id="stat-inv"><?= (int)$totalInvites ?></b></div>
    <div class="card"><small>Bonuses</small><b id="stat-bon">₹ <?= number_format((float)$totalBonuses,0) ?></b></div>
    <div class="card"><small>Active Users</small><b id="stat-act"><?= (int)$activeUsers ?></b></div>
  </div>

  <div class="tabs">
    <div class="tab active" data-target="milestones">Milestones</div>
    <div class="tab" data-target="achievements">Achievements</div>
    <div class="tab" data-target="rules">Rules</div>
  </div>

  <div id="milestones" class="section show"></div>

  <div id="achievements" class="section">
    <div id="ach-strip" class="ach-strip"></div>
  </div>

  <div id="rules" class="section">
    <ul style="list-style:none;padding:0;margin:0 6px">
      <li style="margin:.45rem 0"><i class="bi bi-percent"></i> &nbsp;30% commission on every wager from your referral.</li>
      <li style="margin:.45rem 0"><i class="bi bi-lightning-charge"></i> &nbsp;Milestone bonus triggers instantly when verified.</li>
      <li style="margin:.45rem 0"><i class="bi bi-clock-history"></i> &nbsp;Payouts credit daily at 00:00 IST.</li>
      <li style="margin:.45rem 0"><i class="bi bi-shield-check"></i> &nbsp;No self-referrals, dups, or fraud — we audit.</li>
      <li style="margin:.45rem 0"><i class="bi bi-gear"></i> &nbsp;Rules may evolve for fairness &amp; safety.</li>
    </ul>
  </div>

  <div class="pills">
    <div class="pill active" data-filter="all">All</div>
    <div class="pill" data-filter="paid">Paid</div>
    <div class="pill" data-filter="pending">Pending</div>
    <div class="pill" data-filter="failed">Failed</div>
  </div>

  <div id="list" class="list"></div>

  <a href="/assets/referral-promo-pack.zip" class="btn-wide"><i class="bi bi-download" style="margin-right:.4rem"></i>Download Promo Pack</a>
</div>

<script>
const baseUrl = <?= json_encode($baseUrl) ?>;
const payload = <?= json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
const $ = s => document.querySelector(s), $$ = s => document.querySelectorAll(s);

/* Copy link */
$('#copy').addEventListener('click', () => {
  const link = `${baseUrl}/register.php?ref=${encodeURIComponent(payload.code)}`;
  navigator.clipboard.writeText(link).then(()=>toast('Link copied ✅'));
});
function toast(t){const d=document.createElement('div');d.textContent=t;d.style.cssText='position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#fff;color:#000;padding:.7rem 1rem;border-radius:14px;font-weight:700;z-index:9999;opacity:0;transition:.3s';document.body.append(d);requestAnimationFrame(()=>d.style.opacity='1');setTimeout(()=>{d.style.opacity='0';setTimeout(()=>d.remove(),300)},1700)}

/* Progress */
const maxTarget = Math.max(...payload.milestones.map(m=>m.target));
const pct = maxTarget ? Math.min((payload.stats.invites/maxTarget)*100,100) : 0;
$('#bar').style.width = pct.toFixed(0)+'%';

/* Tabs */
$$('.tab').forEach(tab => tab.addEventListener('click', ()=>{
  $$('.tab').forEach(x=>x.classList.remove('active')); tab.classList.add('active');
  ['milestones','achievements','rules'].forEach(id=>$('#'+id).classList.remove('show'));
  $('#'+tab.dataset.target).classList.add('show');
}));

/* Milestones */
function renderMilestones(){
  const host = $('#milestones'); host.innerHTML='';
  payload.milestones.forEach(m=>{
    const donePct = Math.min((payload.stats.invites/m.target)*100,100);
    const r=28, circ=(2*Math.PI*r), offset=(1-donePct/100)*circ;
    host.insertAdjacentHTML('beforeend',`
      <div class="milestone">
        <div class="circle">
          <svg viewBox="0 0 80 80" width="62" height="62">
            <circle class="bg" cx="40" cy="40" r="${r}"></circle>
            <circle class="prog" cx="40" cy="40" r="${r}" stroke-dasharray="${circ}" stroke-dashoffset="${offset}"></circle>
          </svg>
          <span>${donePct.toFixed(0)}%</span>
        </div>
        <div class="ms-main"><div style="font-weight:700">${m.target} Friends</div><small>Bonus ₹ ${m.reward}</small></div>
        <div class="lock">${payload.stats.invites>=m.target?'Unlocked':'Locked'}</div>
      </div>
    `);
  });
}

/* Achievements */
function renderAch(){
  const host = $('#ach-strip'); host.innerHTML='';
  payload.ach.forEach(a=>host.insertAdjacentHTML('beforeend',`
    <div class="ach"><i class="bi ${a.icon}"></i><small>${a.label}</small></div>
  `));
}

/* List + Filters */
function renderList(filter='all'){
  const box = $('#list'); box.innerHTML='';
  const data = payload.rows.filter(r=>filter==='all'||r.status===filter);
  if (!data.length){ box.innerHTML='<div style="opacity:.75;text-align:center;padding:14px 6px">No records.</div>'; return; }
  data.forEach(r=>box.insertAdjacentHTML('beforeend',`
    <div class="row">
      <img src="https://i.pravatar.cc/120?u=${r.avatar}">
      <div class="main"><h6>${escapeHtml(r.name)}</h6><small>${r.date}</small></div>
      <div class="amt ${r.status}">₹ ${Math.round(r.amt)}</div>
    </div>
  `));
}
function escapeHtml(s){const d=document.createElement('div'); d.textContent=s; return d.innerHTML;}
$$('.pill').forEach(p=>p.addEventListener('click',()=>{$$('.pill').forEach(x=>x.classList.remove('active'));p.classList.add('active');renderList(p.dataset.filter);}))

/* Init */
renderMilestones(); renderAch(); renderList('all');
</script>
</body>
</html>
