<?php
// ColaPay async notify (must echo 'success' on success)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/payments/cola_client.php';

$pdo = app_pdo();

// Read POST (JSON or form)
$raw = file_get_contents('php://input');
$dat = json_decode($raw,true);
if(!is_array($dat) || empty($dat)) $dat = $_POST;

// Basic fields as per docs (adjust keys if their doc uses different names)
$orderNo = $dat['orderNo'] ?? $dat['order_id'] ?? $dat['merchantOrderNo'] ?? null;
$status  = strtolower((string)($dat['status'] ?? $dat['orderStatus'] ?? ''));
$paidAmt = (float)($dat['amount'] ?? $dat['paidAmount'] ?? 0);

// Verify signature (if they post sign)
if(!cola_verify_notify($dat)){ http_response_code(400); echo 'sign error'; exit; }

if(!$orderNo){ http_response_code(400); echo 'no order'; exit; }

// Mark Approved exactly once
if($status==='success' || $status==='paid' || $status==='successed' || $status==='approved'){
  $pdo->beginTransaction();
  // Approve only if still Pending
  $ok = $pdo->prepare("UPDATE deposits SET status='Approved' WHERE txn_id=? AND status='Pending'")->execute([$orderNo]);

  // (Optional) credit wallet immediately:
  if($ok && $pdo->lastInsertId()=== '0'){ /* ignore */ }
  // If you keep user balance in `users.balance`, credit safely using the deposit row amount:
  $st = $pdo->prepare("SELECT user_id, amount FROM deposits WHERE txn_id=? LIMIT 1");
  $st->execute([$orderNo]); if($row=$st->fetch()){
    $pdo->prepare("UPDATE users SET balance = balance + ? WHERE user_id=?")->execute([(float)$row['amount'], (string)$row['user_id']]);
  }
  $pdo->commit();

  echo 'success'; // ColaPay expects this exact word
  exit;
}

// Otherwise you can mark rejected:
$pdo->prepare("UPDATE deposits SET status='Rejected' WHERE txn_id=? AND status='Pending'")->execute([$orderNo]);
echo 'success';
