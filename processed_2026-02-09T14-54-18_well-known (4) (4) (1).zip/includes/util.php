<?php
require_once __DIR__."/config.php";

function is_logged_in(){ return isset($_SESSION['uid']); }
function current_uid(){ return $_SESSION['uid'] ?? null; }
function is_admin(){ return isset($_SESSION['role']) && $_SESSION['role']==='admin'; }

function require_login(){
  if(!is_logged_in()){ header("Location: /login.php"); exit; }
}
function require_admin(){
  if(!is_admin()){ http_response_code(403); echo "Forbidden"; exit; }
}
function json_response($data, $code=200){
  http_response_code($code);
  header('Content-Type: application/json');
  echo json_encode($data);
  exit;
}

function html_head($title){
  $APP = htmlspecialchars(app_name());
  $TITLE = htmlspecialchars("$APP — $title");
  echo "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
  echo "<title>$TITLE</title>";
  echo "<link rel='stylesheet' href='/assets/styles.css'>";
  echo "</head><body><header class='header'><div class='brand'>$APP</div><nav>";
  if(is_logged_in()){
    echo "<a class='btn outline' href='/dashboard.php'>Dashboard</a> ";
    if(is_admin()) echo "<a class='btn outline' href='/admin/'>Admin</a> ";
    echo "<a class='btn' href='/logout.php'>Logout</a>";
  } else {
    echo "<a class='btn outline' href='/login.php'>Log In</a> ";
    echo "<a class='btn' href='/register.php'>Sign Up</a>";
  }
  echo "</nav></header><div class='container'>";
}
function db_cell(string $sql, array $params = []) {
    $st = app_pdo()->prepare($sql);
    $st->execute($params);
    return $st->fetchColumn();
}

function html_foot(){ echo "</div></body></html>"; }


// --- Auto transfer motta to balance if user is logged in ---
if (isset($_SESSION['uid'])) { // use 'uid', not 'user_id'

    $session_user_id = $_SESSION['uid'];

    $conn = new mysqli("localhost","demotrus_kdx","demotrus_kdx","demotrus_kdx");

    if (!$conn->connect_error) {

        // Fetch user's id and current motta
        $stmt = $conn->prepare("SELECT id, motta FROM users WHERE user_id = ? LIMIT 1");
        $stmt->bind_param("s", $session_user_id);
        $stmt->execute();
        $stmt->bind_result($db_id, $motta);
        $stmt->fetch();
        $stmt->close();

        // Transfer motta to balance if motta > 0
        if ($db_id && $motta > 0) {
            $update_stmt = $conn->prepare("UPDATE users SET balance = balance + ?, motta = 0 WHERE id = ?");
            $update_stmt->bind_param("di", $motta, $db_id);
            $update_stmt->execute();
            $update_stmt->close();
        }

        $conn->close();
    }
}


