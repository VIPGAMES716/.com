<?php
/* ==========================================================
   includes/config.php  — DB, Session & Auth (STABLE)
   ========================================================== */

// वैकल्पिक: timezone सेट करें जिससे log timestamps सही हों
date_default_timezone_set('Asia/Kolkata');

/* ===== DATABASE (your creds) ===== */
$DB_HOST = 'localhost';
$DB_USER = 'demotrus_kdx';
$DB_PASS = 'demotrus_kdx';
$DB_NAME = 'demotrus_kdx';

/* ===== App meta ===== */
$APP_NAME = 'YOLO PLAY';
$SECRET   = 'CHANGE_ME_HMAC_SECRET'; // set a strong random string before going live

/* (Optional) table name hints used by some pages.
   Change only if your table names are different. */
if (!defined('APP_DEPOSIT_TABLE'))   define('APP_DEPOSIT_TABLE',   'deposits');
if (!defined('APP_WITHDRAW_TABLE'))  define('APP_WITHDRAW_TABLE',  'withdrawals');

/* ===== Sessions (one place, consistent everywhere) =====
   - Unique session name to avoid clashes with other apps
   - Cookie path is "/" so all pages share the session
   - Domain left empty => works for both root and www
*/
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_name('nebula_sid');
  session_set_cookie_params([
    'lifetime' => 60*60*24*7,          // 7 days
    'path'     => '/',                 // all routes
    'domain'   => '',                  // current host only (no cross-site issues)
    'secure'   => !empty($_SERVER['HTTPS']), // HTTPS → secure cookies
    'httponly' => true,
    'samesite' => 'Lax',
  ]);
  session_start();
}

/* ===== PDO Connection ===== */
try {
  $pdo = new PDO(
    "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
    $DB_USER,
    $DB_PASS,
    [
      PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
  );
} catch (Throwable $e) {
  // Keep simple error to avoid leaking creds
  http_response_code(500);
  die('DB connection failed.');
}

/* ===== Small helpers ===== */
if (!function_exists('app_pdo')) {
  function app_pdo(): PDO { global $pdo; return $pdo; }
}
if (!function_exists('app_name')) {
  function app_name(): string { global $APP_NAME; return $APP_NAME; }
}
if (!function_exists('app_secret')) {
  function app_secret(): string { global $SECRET; return $SECRET; }
}

/* --- DB mini utils (used by some pages) --- */
if (!function_exists('db_cell')) {
  function db_cell(string $sql, array $args = []) {
    $st = app_pdo()->prepare($sql);
    $st->execute($args);
    return $st->fetchColumn();
  }
}
if (!function_exists('db_all')) {
  function db_all(string $sql, array $args = []): array {
    $st = app_pdo()->prepare($sql);
    $st->execute($args);
    return $st->fetchAll();
  }
}

/* ===== Auth: normalize & guard =====
   Some old pages set $_SESSION['uid'] or $_SESSION['id'].
   Normalize any of those to $_SESSION['user_id'] so all pages work.
*/
(function () {
  if (!empty($_SESSION['user_id'])) return;
  foreach (['uid','id','USER_ID','UID'] as $k) {
    if (!empty($_SESSION[$k])) { $_SESSION['user_id'] = $_SESSION[$k]; break; }
  }
})();

if (!function_exists('app_is_logged_in')) {
  function app_is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
  }
}
if (!function_exists('app_user_id')) {
  function app_user_id() {
    return $_SESSION['user_id'] ?? null;
  }
}
if (!function_exists('app_require_login')) {
  function app_require_login(): void {
    if (!app_is_logged_in()) {
      // Preserve target so user returns where they came from
      $next = rawurlencode($_SERVER['REQUEST_URI'] ?? '/dashboard.php');
      header("Location: /login.php?next={$next}");
      exit;
    }
  }
}

/* ===== After-login tip (use in your login handler) =====
   On successful login, set at least:
     $_SESSION['user_id'] = $row['user_id'] ?? $row['id'];
   And then:
     header('Location: ' . ($_GET['next'] ?? '/dashboard.php')); exit;
*/