<?php
// includes/payments/cola_client.php
require_once __DIR__ . '/cola_conf.php';

/**
 * Simple file logger for debugging
 */
function cola_log(string $tag, $data): void {
  $line = '['.date('Y-m-d H:i:s')."] $tag: ".(is_string($data)?$data:json_encode($data, JSON_UNESCAPED_SLASHES))."\n";
  @file_put_contents(__DIR__.'/cola.log', $line, FILE_APPEND);
}

/**
 * JSON encode stable
 */
function cola_json($arr): string {
  return json_encode($arr, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

/**
 * Flexible signer — supports the common Cola variants.
 * Modes:
 *  A: md5(METHOD&PATH&accessKey&timestamp&nonce&SECRET_DECODED)
 *  B: md5(METHOD&PATH&accessKey&timestamp&nonce&SECRET_PLAIN)
 *  C: md5(METHOD&PATH&accessKey&timestamp&nonce&md5(JSON_BODY)&SECRET_DECODED)
 * Header case: lower or title
 */
function cola_build_headers(string $method, string $path, array $body, string $accessKey, string $accessSecret, string $mode, bool $secretIsB64, string $headerCase = 'lower'): array {
  $ts    = time();
  $nonce = random_int(100000, 999999);
  $sec   = $secretIsB64 ? (base64_decode($accessSecret, true) ?: $accessSecret) : $accessSecret;
  $m     = strtoupper($method);

  if ($mode === 'C') {
    $md5body = md5(cola_json($body));
    $toSign  = "{$m}&{$path}&{$accessKey}&{$ts}&{$nonce}&{$md5body}&{$sec}";
  } else {
    $toSign  = "{$m}&{$path}&{$accessKey}&{$ts}&{$nonce}&{$sec}";
  }
  $sign = md5($toSign);

  $pairs = [
    'Content-Type' => 'application/json',
    'accessKey'    => $accessKey,
    'timestamp'    => $ts,
    'nonce'        => $nonce,
    'sign'         => $sign,
  ];

  $headers = [];
  foreach ($pairs as $k=>$v) {
    if ($k === 'Content-Type') { $headers[] = 'Content-Type: application/json'; continue; }
    if ($headerCase === 'title') {
      $K = ucfirst($k);
    } else {
      $K = $k; // lower
    }
    $headers[] = $K.': '.$v;
  }

  // log stringToSign for debug (comment in prod)
  cola_log('sign', ['mode'=>$mode,'b64'=>$secretIsB64,'headers'=>$headers,'string'=>$toSign]);
  return $headers;
}

/**
 * Try multiple combinations until success.
 * Returns: ['ok'=>bool, 'url'=>payUrl, 'raw'=>rawResponse, 'picked'=>['host'=>..,'path'=>..,'mode'=>..,'b64'=>..,'case'=>..]]
 */
function cola_create_order(string $userId, int $amount, string $orderNo, string $returnUrl, string $notifyUrl): array {
  // Normalized body keys (per your screenshots & common Cola docs)
  $body = [
    'McorderNo'   => $orderNo,          // merchant order no
    'Amount'      => (string)$amount,   // integer string (₹)
    'Type'        => 'inr',
    'ChannelCode' => '71001',           // UPI channel sample; change if docs require
    'CallBackUrl' => $notifyUrl,
    'JumpUrl'     => $returnUrl,
  ];

  // Candidate paths that vendors use (put your doc’s exact path first if known)
  $paths = [
    '/api/v2/create',
    '/api/merchant/v2/create',
    '/api/merchant/v2/order/create',
    '/api/v2/order/create',
  ];

  $modes     = ['A','C','B'];               // try A, then C (with body md5), then B
  $b64flags  = [true,false];                // assume secret is base64 first
  $cases     = ['lower','title'];           // header key casing
  $hosts     = array_unique(array_merge([COLA_API_HOST], COLA_API_HOST_FALLBACKS));

  foreach ($hosts as $host) {
    foreach ($paths as $path) {
      foreach ($modes as $mode) {
        foreach ($b64flags as $b64) {
          foreach ($cases as $case) {
            $headers = cola_build_headers('POST', $path, $body, COLA_ACCESS_KEY, COLA_ACCESS_SECRET, $mode, $b64, $case);

            $url = rtrim($host,'/').$path;
            $ch  = curl_init();
            curl_setopt_array($ch, [
              CURLOPT_URL            => $url,
              CURLOPT_POST           => true,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_HTTPHEADER     => $headers,
              CURLOPT_POSTFIELDS     => cola_json($body),
              CURLOPT_CONNECTTIMEOUT => 12,
              CURLOPT_TIMEOUT        => 25,
            ]);
            $raw  = curl_exec($ch);
            $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err  = curl_errno($ch) ? curl_error($ch) : '';
            curl_close($ch);

            $parsed = json_decode($raw ?? '', true);
            cola_log('create_try', ['url'=>$url,'mode'=>$mode,'b64'=>$b64,'case'=>$case,'http'=>$http,'raw'=>$raw]);

            // Success shapes commonly:
            // { "code":200, "result":{"payUrl":"..."} }  OR
            // { "success":true, "data":{"payUrl":"..."} } etc.
            $payUrl = $parsed['result']['payUrl'] ?? ($parsed['data']['payUrl'] ?? '');
            $okCode = (isset($parsed['code']) && (string)$parsed['code'] === '200') || (isset($parsed['success']) && $parsed['success']);

            if ($http === 200 && $payUrl) {
              return ['ok'=>true,'url'=>$payUrl,'raw'=>$raw,'picked'=>compact('host','path','mode','b64','case')];
            }
            if ($http === 200 && $okCode && $payUrl) {
              return ['ok'=>true,'url'=>$payUrl,'raw'=>$raw,'picked'=>compact('host','path','mode','b64','case')];
            }
            // If explicit sign error, keep looping to next combo
          }
        }
      }
    }
  }

  return ['ok'=>false,'url'=>'','raw'=>'','msg'=>'Create order failed: no working signature/path combo (check docs path & field names).'];
}

/**
 * Very lenient callback verifier: try to recompute sign across modes.
 * Return ['ok'=>bool, 'parsed'=>array]
 */
function cola_verify_callback(array $headers, string $rawBody): array {
  $parsed = json_decode($rawBody, true);
  if (!$parsed) return ['ok'=>false,'parsed'=>null];

  // Some gateways send sign in headers, some in body: try both
  $gotSign = $headers['sign'] ?? $headers['Sign'] ?? ($parsed['sign'] ?? '');
  $ts      = $headers['timestamp'] ?? $headers['Timestamp'] ?? ($parsed['timestamp'] ?? '');
  $nonce   = $headers['nonce'] ?? $headers['Nonce'] ?? ($parsed['nonce'] ?? '');
  $path    = $_SERVER['REQUEST_URI'] ?? '/recharge_callback.php';
  $method  = $_SERVER['REQUEST_METHOD'] ?? 'POST';

  // If their callback pack doesn’t include timestamp/nonce, we can only trust IP whitelist + status+amount matching
  $hasMeta = $gotSign && $ts && $nonce;

  if ($hasMeta) {
    foreach (['A','C','B'] as $mode) {
      foreach ([true,false] as $b64) {
        foreach (['lower','title'] as $case) {
          $hdr = cola_build_headers($method, $path, $parsed, COLA_ACCESS_KEY, COLA_ACCESS_SECRET, $mode, $b64, $case);
          // extract what we generated
          $calc = null;
          foreach ($hdr as $h) {
            if (stripos($h,'sign:')===0) { $calc = trim(substr($h,5)); break; }
          }
          if ($calc && strtolower($calc) === strtolower($gotSign)) {
            return ['ok'=>true,'parsed'=>$parsed];
          }
        }
      }
    }
  }

  // Fallback: verify caller IP (whitelist) and expect a success flag in body:
  $ip = $_SERVER['REMOTE_ADDR'] ?? '';
  if (in_array($ip, COLA_WHITELIST, true)) {
    // accept if body contains success/succeed/status==success
    $ok = false;
    if (isset($parsed['code']) && (string)$parsed['code']==='200') $ok = true;
    if (isset($parsed['success']) && $parsed['success']) $ok = true;
    if (isset($parsed['status']) && in_array(strtolower($parsed['status']),['success','succeed','completed','paid','approved'],true)) $ok = true;
    return ['ok'=>$ok,'parsed'=>$parsed];
  }

  return ['ok'=>false,'parsed'=>$parsed];
}
