<?php
// includes/payments/cola_conf.php
// ⛳ EDIT THESE 4 LINES ONLY
const COLA_MERCHANT_ID = '22125730453797';
const COLA_MERCHANT_NAME = 'Boss122';
const COLA_ACCESS_KEY = 'M8FNEwdDnEekdDKvxGrh9w';
const COLA_ACCESS_SECRET = 'WHe3qyxQoEWNa+9RZrmUfg'; // Usually base64; client auto-handles

// API hosts (from Cola)
const COLA_API_HOST = 'https://mcapi.colapayppp.com';  // main API
// If docs show a different host for “create”, add here (the client will try both)
const COLA_API_HOST_FALLBACKS = [
  'https://mcapi.colapayppp.com',
  'https://api.colapayppp.com',
];

// IP whitelist (as they gave you)
const COLA_WHITELIST = ['47.237.10.82','8.219.253.212'];

// Where Cola should POST your result callbacks:
function cola_notify_url(): string {
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host   = $_SERVER['HTTP_HOST'] ?? 'demo.trushme.xyz';
  return $scheme.'://'.$host.'/recharge_callback.php';
}
// Where user returns after paying
function cola_return_url(): string {
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host   = $_SERVER['HTTP_HOST'] ?? 'demo.trushme.xyz';
  return $scheme.'://'.$host.'/deposit_history.php';
}
