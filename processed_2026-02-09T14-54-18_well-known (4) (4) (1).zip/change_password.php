<?php
// change_password.php
require_once __DIR__ . "/includes/util.php";

/**
 * Assumptions:
 * - util.php exposes: app_pdo(), app_name(), require_login()
 * - users table has: user_id (PK or unique), pass_hash (bcrypt string), name (optional), pwd_changed_at (optional DATETIME)
 */

if (session_status() === PHP_SESSION_NONE) session_start();

$pdo = app_pdo();
$user_id = require_login(); // blocks if not logged-in

// CSRF helpers
if (empty($_SESSION['csrf_cp'])) {
  $_SESSION['csrf_cp'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_cp'];

$me = [
  'user_id' => $user_id,
  'name'    => null,
  'pass_hash' => null,
  'pwd_changed_at' => null,
];
//The perfect provide 
// Load current user
try {
  $st = $pdo->prepare("SELECT user_id, name, pass_hash, pwd_changed_at FROM users WHERE user_id = ?");
  $st->execute([$user_id]);
  if ($row = $st->fetch(PDO::FETCH_ASSOC)) {
    $me = array_merge($me, $row);
  } else {
    // If somehow missing, force logout
    header("Location: logout");
    exit;
  }
} catch (Throwable $e) {
  // Silent; UI will show a generic error on submit
}

$ok = null;
$msg = "";

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $post_csrf = (string)($_POST['csrf'] ?? '');
  $cur = (string)($_POST['current_pwd'] ?? '');
  $new = (string)($_POST['new_pwd'] ?? '');
  $rep = (string)($_POST['repeat_pwd'] ?? '');

  // Basic CSRF & required checks
  if (!hash_equals($csrf, $post_csrf)) {
    $ok = false; $msg = "Security token expired. Please reload this page and try again.";
  } elseif ($cur === '' || $new === '' || $rep === '') {
    $ok = false; $msg = "Please fill all fields.";
  } elseif ($new !== $rep) {
    $ok = false; $msg = "New passwords do not match.";
  } elseif ($new === $cur) {
    $ok = false; $msg = "New password must be different from current password.";
  } else {
    // Password policy
    $lenOK = strlen($new) >= 8;                       // at least 8 chars
    $hasU  = (bool)preg_match('/[A-Z]/', $new);       // uppercase
    $hasL  = (bool)preg_match('/[a-z]/', $new);       // lowercase
    $hasD  = (bool)preg_match('/\d/', $new);          // digit
    $hasS  = (bool)preg_match('/[^A-Za-z0-9]/', $new);// symbol

    if (!($lenOK && $hasU && $hasL && $hasD && $hasS)) {
      $ok = false;
      $msg = "Password must be 8+ chars and include uppercase, lowercase, number & symbol.";
    } else {
      try {
        // Verify current password
        if (!password_verify($cur, (string)$me['pass_hash'])) {
          $ok = false; $msg = "Current password is incorrect.";
        } else {
          // Rehash if needed (optional)
          if (password_needs_rehash((string)$me['pass_hash'], PASSWORD_BCRYPT)) {
            $me['pass_hash'] = password_hash($cur, PASSWORD_BCRYPT);
          }
          // Update to new hash
          $newHash = password_hash($new, PASSWORD_BCRYPT);

          // If you maintain pwd_changed_at column, update it; if not present, remove it safely
          $sql = "UPDATE users SET pass_hash = ?, pwd_changed_at = NOW() WHERE user_id = ?";
          $st = $pdo->prepare($sql);
          $st->execute([$newHash, $user_id]);

          // Optional: rotate session or force re-login. Here we keep the current session alive.
          $ok = true;
          $msg = "Password updated successfully.";
          // Regenerate CSRF for safety after sensitive action
          $_SESSION['csrf_cp'] = bin2hex(random_bytes(16));
          $csrf = $_SESSION['csrf_cp'];
        }
      } catch (Throwable $e) {
        $ok = false;
        $msg = "Server error while updating password. Please try again.";
      }
    }
  }
}

// Helpers for UI
$appName = htmlspecialchars(app_name());
$avatarInitial = strtoupper(substr((string)($me['name'] ?: (string)$me['user_id']), 0, 1));
$displayName = htmlspecialchars($me['name'] ?: 'Player');
$memberSince = $me['pwd_changed_at'] ? date('M Y', strtotime($me['pwd_changed_at'])) : '—';
$maskedId = htmlspecialchars(substr($me['user_id'], 0, 3) . str_repeat('•', max(0, strlen($me['user_id']) - 6)) . substr($me['user_id'], -3));
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
  <title>Change Password – <?= $appName ?></title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
  :root{
    --clr-primary:#8d78ff;
    --clr-card-bg:rgba(255,255,255,.08);
    --clr-glass-line:rgba(255,255,255,.12);
    --clr-dim:rgba(255,255,255,.74);
    --ok:#198754; --err:#dc3545;
  }
  *{box-sizing:border-box}
  body{
    margin:0;min-height:100vh;font-family:'Poppins',sans-serif;color:#fff;
    background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
    overflow-x:hidden;
  }
  body::after{content:"";position:fixed;inset:0;pointer-events:none;opacity:.05;
    background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png');
    mix-blend-mode:overlay;animation:grain 9s steps(10) infinite}
  @keyframes grain{0%{background-position:0 0}100%{background-position:100% 100%}}

  .app{max-width:480px;margin:0 auto;padding:1rem 1rem 9.5rem}
  .header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1.2rem}
  .brand{font-size:1.5rem;font-weight:700}
  .actions{display:flex;gap:.5rem}
  .btn-mini{border:none;border-radius:14px;font-size:.85rem;font-weight:600;padding:.4rem .9rem;cursor:pointer;transition:.25s}
  .btn-mini.back{background:var(--clr-card-bg);border:1px solid var(--clr-glass-line);color:var(--clr-dim)}
  .btn-mini.back:hover{background:rgba(255,255,255,.12)}

  .profile-card{padding:1.2rem;border-radius:22px;background:var(--clr-card-bg);
    border:1px solid var(--clr-glass-line);backdrop-filter:blur(18px);display:flex;gap:.9rem;align-items:center;margin-bottom:1rem}
  .avatar{width:52px;height:52px;border-radius:50%;background:#8d78ff55;display:flex;align-items:center;justify-content:center;font-size:1.2rem;font-weight:700;color:#fff;text-transform:uppercase;border:2px solid rgba(255,255,255,.25)}
  .p-info h5{margin:0;font-size:1rem;font-weight:600}
  .p-info span{font-size:.75rem;color:var(--clr-dim)}

  .form-card{padding:1.4rem;border-radius:22px;background:var(--clr-card-bg);
    border:1px solid var(--clr-glass-line);backdrop-filter:blur(18px);margin-bottom:1rem}
  .form-card label{font-size:.9rem;margin-bottom:.3rem;color:var(--clr-dim)}
  .ipt-wrap{position:relative}
  .ipt{width:100%;padding:.75rem 2.6rem .75rem 1rem;border-radius:16px;margin-bottom:1rem;
      border:1px solid var(--clr-glass-line);background:rgba(0,0,0,.28);color:#fff;font-size:.95rem}
  .ipt:focus{outline:none;border-color:var(--clr-primary)}
  .toggle-eye{position:absolute;right:.65rem;top:.55rem;font-size:1.2rem;opacity:.8;cursor:pointer}

  .strength-wrap{margin-top:-.5rem;margin-bottom:.8rem}
  .meter{height:8px;border-radius:6px;background:rgba(255,255,255,.15);overflow:hidden}
  .meter-fill{height:100%;width:0%;background:var(--clr-primary);transition:width .3s}
  .meter-label{font-size:.75rem;color:var(--clr-dim);margin-top:.2rem;text-align:right}
  .row-actions{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.5rem}
  .btn-ghost{border:1px solid var(--clr-glass-line);background:var(--clr-card-bg);color:#fff;border-radius:14px;padding:.45rem .8rem;font-size:.85rem}
  .btn-ghost:hover{background:rgba(255,255,255,.12)}
  .save-btn{display:block;width:100%;padding:.8rem 1rem;border-radius:18px;border:none;background:var(--clr-primary);color:#fff;font-size:1rem;font-weight:700;transition:.25s}
  .save-btn:hover{opacity:.9}

  .rules{padding:1rem 1.4rem;border-radius:22px;background:var(--clr-card-bg);
    border:1px solid var(--clr-glass-line);backdrop-filter:blur(18px);font-size:.85rem;color:var(--clr-dim);margin-bottom:1rem}
  .rules li{margin-bottom:.4rem}

  .faq{padding:1rem 1.4rem;border-radius:22px;background:var(--clr-card-bg);
    border:1px solid var(--clr-glass-line);backdrop-filter:blur(18px);font-size:.9rem}
  .faq-item{border-bottom:1px solid rgba(255,255,255,.12);padding:.7rem 0}
  .faq-item:last-child{border-bottom:none}
  .q{display:flex;justify-content:space-between;align-items:center;cursor:pointer}
  .a{display:none;color:var(--clr-dim);padding-top:.45rem}

  .notice{position:fixed;left:50%;transform:translateX(-50%);bottom:110px;padding:.8rem 1.1rem;border-radius:14px;font-weight:600;z-index:1000;opacity:0;transition:.35s}
  .notice.ok{background:var(--ok);color:#fff}
  .notice.err{background:var(--err);color:#fff}

  .dock{position:fixed;left:0;right:0;bottom:0;height:82px;z-index:10;
        backdrop-filter:blur(18px);background:rgba(14,10,30,.68);border-top:1px solid var(--clr-glass-line);
        display:grid;grid-template-columns:repeat(5,1fr);align-items:center;justify-items:center;
        padding:0 env(safe-area-inset-left,8px) 0 env(safe-area-inset-right,8px)}
  .nav-btn{color:var(--clr-dim);text-decoration:none;font-size:.75rem;display:flex;flex-direction:column;align-items:center;gap:2px;user-select:none}
  .nav-btn .bi{font-size:1.4rem} .nav-btn.active{color:#fff}
  .fab{position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:64px;height:64px;border-radius:22px;background:var(--clr-primary);display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#fff;box-shadow:0 6px 24px rgba(141,120,255,.55);border:5px solid rgba(255,255,255,.05)}
  @media(max-width:350px){.nav-btn .bi{font-size:1.25rem}.nav-btn span{font-size:.63rem}}
  </style>
</head>
<body>
  <div class="app">
    <!-- Header -->
    <div class="header">
      <div class="brand">Change Password</div>
      <div class="actions">
        <button class="btn-mini back" onclick="history.back()">
          <i class="bi bi-arrow-left me-1"></i>Back
        </button>
      </div>
    </div>

    <!-- Profile box -->
    <div class="profile-card">
      <div class="avatar"><?= $avatarInitial ?></div>
      <div class="p-info">
        <h5><?= $displayName ?></h5>
        <span><?= $maskedId ?> • last updated <?= htmlspecialchars($memberSince) ?></span>
      </div>
    </div>

    <!-- Form -->
    <form method="post" class="form-card" id="pwdForm" autocomplete="off" novalidate>
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
      <label for="current_pwd">Current password</label>
      <div class="ipt-wrap">
        <input class="ipt" type="password" name="current_pwd" id="current_pwd" required autocomplete="current-password" placeholder="••••••••">
        <i class="bi bi-eye-slash toggle-eye" data-for="current_pwd"></i>
      </div>

      <label for="new_pwd">New password</label>
      <div class="ipt-wrap">
        <input class="ipt" type="password" name="new_pwd" id="new_pwd" minlength="8" required autocomplete="new-password" placeholder="Use a strong password">
        <i class="bi bi-eye-slash toggle-eye" data-for="new_pwd"></i>
      </div>

      <!-- strength meter -->
      <div class="strength-wrap">
        <div class="meter"><div class="meter-fill" id="meterFill"></div></div>
        <div class="meter-label" id="meterLabel">Strength: —</div>
      </div>

      <label for="repeat_pwd">Repeat new password</label>
      <div class="ipt-wrap">
        <input class="ipt" type="password" name="repeat_pwd" id="repeat_pwd" minlength="8" required autocomplete="new-password" placeholder="Repeat new password">
        <i class="bi bi-eye-slash toggle-eye" data-for="repeat_pwd"></i>
      </div>

      <div class="row-actions">
        <button class="btn-ghost" type="button" id="genBtn"><i class="bi bi-magic me-1"></i>Generate strong</button>
        <button class="btn-ghost" type="button" id="copyBtn"><i class="bi bi-clipboard me-1"></i>Copy new</button>
      </div>

      <button class="save-btn mt-3" type="submit">Save</button>
    </form>

    <!-- Rules -->
    <ul class="rules">
      <li>At least 8 characters</li>
      <li>Must include uppercase, lowercase, number & symbol</li>
      <li>Don’t reuse an old password and don’t share it</li>
      <li>Avoid personal info (DOB, phone, names)</li>
    </ul>

    <!-- Quick FAQ -->
    <div class="faq">
      <div class="faq-item">
        <div class="q">Why was my password rejected? <i class="bi bi-chevron-down"></i></div>
        <div class="a">It doesn’t meet the policy (length/character mix) or matches your current password.</div>
      </div>
      <div class="faq-item">
        <div class="q">Forgot current password? <i class="bi bi-chevron-down"></i></div>
        <div class="a">Use “Forgot Password” on the login screen to reset via OTP/verification.</div>
      </div>
      <div class="faq-item">
        <div class="q">Will I be logged out elsewhere? <i class="bi bi-chevron-down"></i></div>
        <div class="a">Changing your password protects your account. If you suspect misuse, also log out from other devices via Settings.</div>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <?php if ($ok !== null): ?>
    <div id="notice" class="notice <?= $ok ? 'ok' : 'err' ?>"><?= htmlspecialchars($msg) ?></div>
    <script>
      (function(){
        const n=document.getElementById('notice'); if(!n) return;
        requestAnimationFrame(()=>n.style.opacity='1');
        setTimeout(()=>{ n.style.opacity='0'; setTimeout(()=>n.remove(), 350); }, 2600);
      })();
    </script>
  <?php endif; ?>

  <!-- Dock -->
  <nav class="dock">
    <a href="dashboard.php"  class="nav-btn"><i class="bi bi-controller"></i><span>Arcade</span></a>
    <a href="esports.php" class="nav-btn"><i class="bi bi-trophy"></i><span>eSports</span></a>
    <span></span>
    <a href="chat.php"    class="nav-btn"><i class="bi bi-chat-dots-fill"></i><span>Chat</span></a>
    <a href="profile.php" class="nav-btn active"><i class="bi bi-person-circle"></i><span>Profile</span></a>
    <a href="refer"   class="fab"><i class="bi bi-lightning-fill"></i></a>
  </nav>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // password visibility toggles
    document.querySelectorAll('.toggle-eye').forEach(el=>{
      el.addEventListener('click', ()=>{
        const id = el.getAttribute('data-for');
        const ipt = document.getElementById(id);
        const isPw = ipt.getAttribute('type') === 'password';
        ipt.setAttribute('type', isPw ? 'text' : 'password');
        el.classList.toggle('bi-eye');
        el.classList.toggle('bi-eye-slash');
      });
    });

    // strength meter
    const newPwd  = document.getElementById('new_pwd'),
          repeat  = document.getElementById('repeat_pwd'),
          fill    = document.getElementById('meterFill'),
          label   = document.getElementById('meterLabel');

    function score(p){
      let s=0;
      if(p.length>=8) s++;
      if(/[A-Z]/.test(p)) s++;
      if(/[a-z]/.test(p)) s++;
      if(/[0-9]/.test(p)) s++;
      if(/[^A-Za-z0-9]/.test(p)) s++;
      return s;
    }
    function updateMeter(){
      const v = newPwd.value;
      const s = score(v);
      const pct = (s/5)*100;
      fill.style.width = pct+'%';
      const words = ['—','very weak','weak','fair','strong','excellent'];
      label.textContent = 'Strength: '+words[s];
    }
    newPwd.addEventListener('input', updateMeter);

    // generate strong password
    function genStrong(len=14){
      const sets = {
        U:'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        L:'abcdefghijklmnopqrstuvwxyz',
        D:'0123456789',
        S:'!@#$%^&*()-_=+[]{};:,.?/|~'
      };
      const all = sets.U + sets.L + sets.D + sets.S;
      function pick(s){ return s[Math.floor(Math.random()*s.length)]; }
      let out = pick(sets.U)+pick(sets.L)+pick(sets.D)+pick(sets.S);
      for(let i=out.length;i<len;i++) out += pick(all);
      // shuffle
      return out.split('').sort(()=>Math.random()-0.5).join('');
    }
    document.getElementById('genBtn').addEventListener('click', ()=>{
      const v = genStrong();
      newPwd.value = v;
      repeat.value = v;
      updateMeter();
    });
    document.getElementById('copyBtn').addEventListener('click', async ()=>{
      try{
        await navigator.clipboard.writeText(newPwd.value);
        showToast('Copied to clipboard');
      }catch{}
    });

    // basic client validation
    document.getElementById('pwdForm').addEventListener('submit', e=>{
      if(newPwd.value !== repeat.value){
        e.preventDefault();
        showToast('Passwords do not match', false);
      }
    });

    function showToast(t, ok=true){
      const d=document.createElement('div');
      d.className='notice '+(ok?'ok':'err');
      d.textContent=t;
      document.body.appendChild(d);
      requestAnimationFrame(()=>d.style.opacity='1');
      setTimeout(()=>{ d.style.opacity='0'; setTimeout(()=>d.remove(), 350); }, 2200);
    }

    // initialize meter on load (especially after errors)
    updateMeter();
  </script>
  <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"648dce9918524b9f905e7fa5008b5991","r":1}' crossorigin="anonymous"></script>
</body>
</html>
