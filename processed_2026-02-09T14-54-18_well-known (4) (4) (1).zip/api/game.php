<?php
require_once __DIR__."/../includes/util.php";
require_login();

$gid = trim($_GET['game_id'] ?? '');
if ($gid===''){ http_response_code(400); echo "Missing game_id"; exit; }

$st = app_pdo()->prepare("SELECT slug FROM games WHERE external_id=? AND enabled=1 LIMIT 1");
$st->execute([$gid]);
$row = $st->fetch();

if ($row) {
  header("Location: /play.php?game=".urlencode($row['slug']));
  exit;
}

html_head("Game");
echo "<div class='card' style='max-width:560px;margin:16px auto'>
  <h2>Game not available</h2>
  <p class='muted'>This game will be available soon. Please pick another one.</p>
  <a class='btn' href='/dashboard.php'>Back to Arcade</a>
</div>";
html_foot();
