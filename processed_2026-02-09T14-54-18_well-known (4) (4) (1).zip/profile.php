<?php
/* profile.php — Clean profile: real wallet, i18n (EN/HI), no settings tile,
   no XP/wins strip; shows User ID (and join date if available). */

require_once __DIR__ . '/includes/config.php';
app_require_login();

$pdo = app_pdo();
$UID = app_user_id(); // your user_id (e.g., mobile)

/* ───────────── Language (session) ───────────── */
if (isset($_GET['lang'])) {
  $_SESSION['lang'] = $_GET['lang'] === 'hi' ? 'hi' : 'en';
  // clean URL after setting
  $base = strtok($_SERVER['REQUEST_URI'], '?');
  header("Location: $base"); exit;
}
$LANG = $_SESSION['lang'] ?? 'en';

$T = [
  'en' => [
    'brand' => app_name(),
    'wallet' => 'Wallet Balance',
    'vip' => 'VIP',
    'deposit' => 'Instant Deposit',
    'withdraw' => 'Quick Payout',
    'refer' => 'Refer & Earn',
    'dep_hist' => 'Deposit History',
    'wd_hist' => 'Withdrawal History',
    'bet_hist' => 'Bet History',
    'gift' => 'Gift Redeem',
    'tournaments' => 'Tournaments',
    'telegram' => 'Telegram Channel',
    'support' => 'Customer Support',
    'responsible' => 'Responsible Gaming',
    'logout' => 'Logout',
    'profile' => 'Profile',
    'arcade' => 'Arcade',
    'esports' => 'eSports',
    'chat' => 'Chat',
    'user_id' => 'User ID',
    'joined' => 'Joined',
    'english' => 'English',
    'hindi' => 'हिंदी',
  ],
  'hi' => [
    'brand' => app_name(),
    'wallet' => 'वॉलेट बैलेंस',
    'vip' => 'वीआईपी',
    'deposit' => 'तुरंत जमा',
    'withdraw' => 'तेज़ निकासी',
    'refer' => 'रेफ़र करें और कमाएं',
    'dep_hist' => 'जमा इतिहास',
    'wd_hist' => 'निकासी इतिहास',
    'bet_hist' => 'बेट इतिहास',
    'gift' => 'गिफ़्ट रिडीम',
    'tournaments' => 'टूर्नामेंट',
    'telegram' => 'टेलीग्राम चैनल',
    'support' => 'कस्टमर सपोर्ट',
    'responsible' => 'जिम्मेदार गेमिंग',
    'logout' => 'लॉगआउट',
    'profile' => 'प्रोफ़ाइल',
    'arcade' => 'आर्केड',
    'esports' => 'ई-स्पोर्ट्स',
    'chat' => 'चैट',
    'user_id' => 'यूज़र आईडी',
    'joined' => 'जुड़ने की तारीख',
    'english' => 'English',
    'hindi' => 'हिंदी',
  ],
];
$t = $T[$LANG];

/* ───────────── helpers ───────────── */
function inr($n){ return '₹' . number_format((float)$n, 2); }
function tbl_exists(PDO $pdo, string $t): bool {
  $st = $pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1");
  $st->execute([$t]); return (bool)$st->fetchColumn();
}
function col_exists(PDO $pdo, string $t, string $c): bool {
  $st = $pdo->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
  $st->execute([$t,$c]); return (bool)$st->fetchColumn();
}
function first_table(PDO $pdo, array $cands): ?string {
  foreach($cands as $t){ if(tbl_exists($pdo,$t)) return $t; } return null;
}
function first_col(PDO $pdo, string $t, array $cands): ?string {
  foreach($cands as $c){ if(col_exists($pdo,$t,$c)) return $c; } return null;
}

/* ───────────── name + joined date ───────────── */
$playerName = 'Player';
$joinedOn = null;
try {
  $userTbl = first_table($pdo, ['users','members','accounts','players']);
  if ($userTbl) {
    $idCol   = first_col($pdo,$userTbl,['user_id','id','uid','account_id','member_id']) ?? 'id';
    $nameCol = first_col($pdo,$userTbl,['name','full_name','username','user_name','display_name']);
    $joinCol = first_col($pdo,$userTbl,['created_at','created','joined_at','reg_date','register_date']);
    if ($nameCol) {
      $st = $pdo->prepare("SELECT $nameCol FROM `$userTbl` WHERE `$idCol`=? LIMIT 1");
      $st->execute([$UID]); $v = $st->fetchColumn(); if ($v) $playerName = (string)$v;
    }
    if ($joinCol) {
      $st = $pdo->prepare("SELECT $joinCol FROM `$userTbl` WHERE `$idCol`=? LIMIT 1");
      $st->execute([$UID]); $v = $st->fetchColumn(); if ($v) $joinedOn = date('d M Y', strtotime($v));
    }
  }
} catch(Throwable $e){}

/* ───────────── wallet amount ───────────── */
$walletAmount = 0.00;
try {
  if (!empty($userTbl) || ($userTbl = first_table($pdo, ['users','members','accounts','players']))) {
    $idCol  = first_col($pdo,$userTbl,['user_id','id','uid','account_id','member_id']) ?? 'id';
    $balCol = first_col($pdo,$userTbl,['balance','wallet','main_balance','wallet_balance','credits','coins','amount']);
    if ($balCol) {
      $st = $pdo->prepare("SELECT $balCol FROM `$userTbl` WHERE `$idCol`=? LIMIT 1");
      $st->execute([$UID]);
      $v = $st->fetchColumn();
      if ($v !== false && $v !== null) $walletAmount = (float)$v;
    }
  }
} catch(Throwable $e){}
if ($walletAmount === 0.00) {
  try {
    $wTbl = first_table($pdo, ['wallets','user_wallet','balances','wallet']);
    if ($wTbl) {
      $uCol = first_col($pdo,$wTbl,['user_id','uid','account_id','member_id']) ?? 'user_id';
      $bCol = first_col($pdo,$wTbl,['balance','amount','wallet','available','curr_balance']) ?? 'balance';
      $st = $pdo->prepare("SELECT $bCol FROM `$wTbl` WHERE `$uCol`=? ORDER BY 1 DESC LIMIT 1");
      $st->execute([$UID]); $v=$st->fetchColumn();
      if ($v !== false && $v !== null) $walletAmount = (float)$v;
    }
  } catch(Throwable $e){}
}
if ($walletAmount === 0.00) {
  try {
    $depTbl = first_table($pdo, ['deposits','payments','transactions','wallet_tx']);
    $wdTbl  = first_table($pdo, ['withdrawals','payouts','withdraw','cashout','transactions','wallet_tx']);
    $depSum = 0.0; $wdSum = 0.0;

    if ($depTbl) {
      $u = first_col($pdo,$depTbl,['user_id','uid','account_id','member_id']) ?? 'user_id';
      $a = first_col($pdo,$depTbl,['amount','amt','value','total']) ?? 'amount';
      $s = first_col($pdo,$depTbl,['status','tx_status','state','result']);
      if ($s) $st=$pdo->prepare("SELECT COALESCE(SUM($a),0) FROM `$depTbl` WHERE `$u`=? AND LOWER($s) IN ('approved','success','completed','done','paid','ok')");
      else   $st=$pdo->prepare("SELECT COALESCE(SUM($a),0) FROM `$depTbl` WHERE `$u`=?");
      $st->execute([$UID]); $depSum=(float)$st->fetchColumn();
    }
    if ($wdTbl) {
      $u = first_col($pdo,$wdTbl,['user_id','uid','account_id','member_id']) ?? 'user_id';
      $a = first_col($pdo,$wdTbl,['amount','amt','value','total']) ?? 'amount';
      $s = first_col($pdo,$wdTbl,['status','tx_status','state','result']);
      if ($s) $st=$pdo->prepare("SELECT COALESCE(SUM($a),0) FROM `$wdTbl` WHERE `$u`=? AND LOWER($s) IN ('approved','success','completed','paid','done')");
      else   $st=$pdo->prepare("SELECT COALESCE(SUM($a),0) FROM `$wdTbl` WHERE `$u`=?");
      $st->execute([$UID]); $wdSum=(float)$st->fetchColumn();
    }
    $walletAmount = max(0.0, $depSum - $wdSum);
  } catch(Throwable $e){}
}

/* simple VIP badge (static) */
$vipLevel = 1;
?>
<!doctype html>
<html lang="<?= $LANG ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
  <title><?= htmlspecialchars($t['brand']) ?> – <?= htmlspecialchars($t['profile']) ?></title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    :root{
      --clr-primary:#8d78ff; --clr-secondary:#ff57e6;
      --clr-card-bg:rgba(255,255,255,.08); --clr-glass-line:rgba(255,255,255,.12);
      --clr-dim:rgba(255,255,255,.74); --clr-success:#22c55e; --clr-danger:#ef4444;
    }
    *{box-sizing:border-box;margin:0;padding:0}
    body{
      min-height:100vh;color:#fff;font-family:'Poppins',sans-serif;overflow-x:hidden;
      background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
    }
    body::after{content:"";position:fixed;inset:0;pointer-events:none;opacity:.05;mix-blend-mode:overlay;
      background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png');
      animation:grain 9s steps(10) infinite}
    @keyframes grain{to{background-position:100% 100%}}
    .app{max-width:480px;margin:auto;padding:.6rem 1rem 8.6rem;position:relative;z-index:1}

    .header{display:flex;justify-content:space-between;align-items:center;margin-bottom:.4rem}
    .brand{font-size:1.45rem;font-weight:700;letter-spacing:-.5px}

    .lang-dropdown{position:relative}
    .lang-btn{
      background:var(--clr-card-bg);border:1px solid var(--clr-glass-line);color:#fff;
      padding:.45rem .9rem;border-radius:14px;font-size:.85rem;display:flex;align-items:center;gap:.4rem;cursor:pointer}
    .lang-menu{position:absolute;top:105%;right:0;background:rgba(24,22,45,.92);border:1px solid var(--clr-glass-line);
      border-radius:14px;overflow:hidden;opacity:0;visibility:hidden;transition:.2s;z-index:10}
    .lang-menu.show{opacity:1;visibility:visible}
    .lang-menu button{background:transparent;border:none;color:#fff;width:100%;text-align:left;padding:.55rem 1rem;cursor:pointer}
    .lang-menu button:hover{background:rgba(255,255,255,.12)}

    .profile-card{
      position:relative;padding:1rem 1.2rem 1.1rem;border-radius:28px;
      background:var(--clr-card-bg);backdrop-filter:blur(18px);border:1px solid var(--clr-glass-line);
      overflow:hidden;margin-bottom:1rem}
    .corner-deco{position:absolute;top:10px;right:16px;font-size:1.6rem;color:var(--clr-secondary);filter:drop-shadow(0 0 6px rgba(255,255,255,.45))}
    .avatar{width:60px;height:60px;border-radius:50%;background:url('https://yoloplay.club/img/profile/profile2.png') center/cover;
      border:3px solid rgba(255,255,255,.35);box-shadow:0 0 12px rgba(255,255,255,.45)}
    .player-name{font-size:1.05rem;font-weight:700}
    .vip-badge{display:inline-flex;align-items:center;gap:.35rem;padding:.25rem .55rem;border-radius:20px;
      background:linear-gradient(135deg,var(--clr-primary) 0%,var(--clr-secondary) 100%);
      font-size:.7rem;font-weight:600;box-shadow:0 0 8px rgba(255,255,255,.35)}
    .vip-badge i{font-size:.9rem}

    .info-row{display:flex;gap:10px;margin-top:.6rem;flex-wrap:wrap}
    .pill{
      background:rgba(255,255,255,.1);border:1px solid var(--clr-glass-line);border-radius:14px;
      padding:.35rem .6rem;font-size:.8rem}

    .action-btn{flex:1;padding:.8rem;border-radius:16px;font-size:.9rem;font-weight:600;border:none;
      display:flex;align-items:center;justify-content:center;gap:.5rem}
    .btn-deposit{background:var(--clr-success)} .btn-withdraw{background:var(--clr-danger)}

    .list-tile{display:flex;align-items:center;gap:.9rem;padding:1.05rem 1rem;border-radius:18px;margin-bottom:.7rem;
      background:var(--clr-card-bg);backdrop-filter:blur(16px);border:1px solid var(--clr-glass-line);
      cursor:pointer;transition:background .25s,transform .25s}
    .list-tile:hover{background:rgba(255,255,255,.12);transform:translateY(-3px)}
    .tile-icon{width:40px;height:40px;border-radius:14px;display:flex;align-items:center;justify-content:center;
      font-size:1.3rem;color:#fff;flex-shrink:0}
    .tile-text{flex:1;font-size:.94rem;font-weight:500}
    .tile-chevron{font-size:1.3rem;color:var(--clr-dim)}

    .bg-primary{background:#5c4dff} .bg-success{background:#22c55e}
    .bg-danger{background:#ef4444}  .bg-info{background:#0ea5e9}
    .bg-warning{background:#facc15} .bg-secondary{background:#ff57e6}

    .dock{position:fixed;left:0;right:0;bottom:0;height:82px;z-index:10;backdrop-filter:blur(18px);
      background:rgba(14,10,30,.68);border-top:1px solid var(--clr-glass-line);
      display:grid;grid-template-columns:repeat(5,1fr);align-items:center;justify-items:center}
    .nav-btn{color:rgba(255,255,255,.74);text-decoration:none;font-size:.75rem;display:flex;flex-direction:column;align-items:center;gap:2px}
    .nav-btn .bi{font-size:1.4rem} .nav-btn.active{color:#fff}
    .fab{position:absolute;top:-6px;left:50%;transform:translateX(-50%);width:64px;height:64px;border-radius:22px;background:var(--clr-primary);
      display:flex;align-items:center;justify-content:center;font-size:1.8rem;color:#fff;box-shadow:0 6px 24px rgba(141,120,255,.55);border:5px solid rgba(255,255,255,.05)}
    @media(max-width:350px){.nav-btn .bi{font-size:1.25rem}.nav-btn span{font-size:.63rem}}
  </style>
</head>
<body>
<div class="app">
  <!-- Header -->
  <div class="header">
    <div class="brand"><?= htmlspecialchars($t['brand']) ?></div>
    <div class="lang-dropdown">
      <button class="lang-btn" id="langBtn">
        <i class="bi bi-translate"></i>
        <span><?= $LANG==='hi' ? $t['hindi'] : $t['english'] ?></span>
        <i class="bi bi-chevron-down"></i>
      </button>
      <div class="lang-menu" id="langMenu">
        <button onclick="location.href='?lang=en'"><?= htmlspecialchars($t['english']) ?></button>
        <button onclick="location.href='?lang=hi'"><?= htmlspecialchars($t['hindi']) ?></button>
      </div>
    </div>
  </div>

  <!-- Profile Card -->
  <div class="profile-card">
    <span class="corner-deco"><i class="bi bi-stars"></i></span>
    <div class="d-flex align-items-center gap-3">
      <div class="avatar"></div>
      <div>
        <div class="player-name"><?= htmlspecialchars($playerName) ?></div>
        <div class="vip-badge"><i class="bi bi-star-fill"></i><?= htmlspecialchars($t['vip']) ?> <?= (int)$vipLevel ?></div>
      </div>
    </div>

    <!-- Wallet Balance -->
    <div class="d-flex justify-content-between align-items-center mt-2">
      <div style="font-size:.85rem;opacity:.85"><?= htmlspecialchars($t['wallet']) ?></div>
      <div style="font-weight:700;font-size:1.1rem"><?= inr($walletAmount) ?></div>
    </div>

    <!-- Replaced XP/Stats with User ID (+ Joined) -->
    <div class="info-row">
      <div class="pill"><?= htmlspecialchars($t['user_id']) ?>: <strong><?= htmlspecialchars($UID) ?></strong></div>
      <?php if ($joinedOn): ?>
        <div class="pill"><?= htmlspecialchars($t['joined']) ?>: <strong><?= htmlspecialchars($joinedOn) ?></strong></div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Primary actions -->
  <div class="d-flex gap-3 mb-4">
    <button class="action-btn btn-deposit" onclick="window.location.href='recharge.php';">
      <i class="bi bi-wallet2"></i> <?= htmlspecialchars($t['deposit']) ?>
    </button>
    <button class="action-btn btn-withdraw" onclick="window.location.href='withdraw.php';">
      <i class="bi bi-cash-coin"></i> <?= htmlspecialchars($t['withdraw']) ?>
    </button>
  </div>

  <!-- Menu tiles (Settings removed) -->
  <div id="menu-list">
    <div class="list-tile" onclick="window.location.href='refer.php';">
      <div class="tile-icon bg-primary"><i class="bi bi-people-fill"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['refer']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='deposit_history.php';">
      <div class="tile-icon bg-success"><i class="bi bi-bank"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['dep_hist']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='withdraw_history.php';">
      <div class="tile-icon bg-danger"><i class="bi bi-cash-stack"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['wd_hist']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='bet_history.php';">
      <div class="tile-icon bg-info"><i class="bi bi-card-list"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['bet_hist']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='gift.php';">
      <div class="tile-icon bg-warning"><i class="bi bi-gift"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['gift']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='esports.php';">
      <div class="tile-icon bg-info"><i class="bi bi-trophy-fill"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['tournaments']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='https://t.me/piyushbond';">
      <div class="tile-icon bg-warning"><i class="bi bi-telegram"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['telegram']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='chat.php';">
      <div class="tile-icon bg-warning"><i class="bi bi-headset"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['support']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='ros.php';">
      <div class="tile-icon bg-danger"><i class="bi bi-shield-lock"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['responsible']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>

    <div class="list-tile" onclick="window.location.href='logout.php';">
      <div class="tile-icon bg-danger"><i class="bi bi-box-arrow-right"></i></div>
      <div class="tile-text"><?= htmlspecialchars($t['logout']) ?></div>
      <i class="bi bi-chevron-right tile-chevron"></i>
    </div>
  </div>
</div>

<!-- Bottom dock -->
<nav class="dock">
  <a href="dashboard.php" class="nav-btn"><i class="bi bi-controller"></i><span><?= htmlspecialchars($t['arcade']) ?></span></a>
  <a href="esports.php" class="nav-btn"><i class="bi bi-trophy"></i><span><?= htmlspecialchars($t['esports']) ?></span></a>
  <span></span>
  <a href="chat.php" class="nav-btn"><i class="bi bi-chat-dots-fill"></i><span><?= htmlspecialchars($t['chat']) ?></span></a>
  <a href="profile.php" class="nav-btn active"><i class="bi bi-person-circle"></i><span><?= htmlspecialchars($t['profile']) ?></span></a>
  <a href="refer.php" class="fab"><i class="bi bi-lightning-fill"></i></a>
</nav>

<script>
  const langBtn = document.getElementById('langBtn');
  const langMenu = document.getElementById('langMenu');
  langBtn.addEventListener('click', ()=> langMenu.classList.toggle('show'));
  document.addEventListener('click', (e)=>{
    if(!langBtn.contains(e.target) && !langMenu.contains(e.target)){ langMenu.classList.remove('show'); }
  });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
