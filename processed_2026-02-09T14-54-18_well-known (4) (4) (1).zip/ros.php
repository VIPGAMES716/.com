<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport"
        content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
  <title>YoloPlay – Gaming Rules</title>

  <!-- Fonts & libs -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Theme -->
  <style>
    :root{
      --clr-primary:#8d78ff;
      --clr-primary-dark:#5c4dff;
      --clr-secondary:#ff57e6;
      --clr-card-bg:rgba(255,255,255,.08);
      --clr-glass-line:rgba(255,255,255,.12);
      --clr-dim:rgba(255,255,255,.74);
    }
    *{box-sizing:border-box;}
    body{
      margin:0;min-height:100vh;color:#fff;font-family:'Poppins',sans-serif;overflow-x:hidden;
      background:radial-gradient(circle at 50% -25%,#2d2570 0%,#110e25 70%);
    }
    body::after{
      content:"";position:fixed;inset:0;pointer-events:none;opacity:.05;mix-blend-mode:overlay;
      background:url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/media/noise.png');
      animation:grain 9s steps(10) infinite;
    }
    @keyframes grain{to{background-position:100% 100%}}

    .app{position:relative;z-index:1;max-width:480px;margin-inline:auto;padding:1.2rem 1rem 8.6rem;}

    .glass{
      background:var(--clr-card-bg);
      backdrop-filter:blur(16px);
      border:1px solid var(--clr-glass-line);
      border-radius:26px;
    }
    .intro{font-size:.85rem;color:var(--clr-dim);line-height:1.45;}
    .terms-content{
      max-height:56vh;overflow-y:auto;padding-right:.25rem;
      font-size:.84rem;line-height:1.55;
    }
    .terms-content h6{margin-top:1.1rem;margin-bottom:.45rem;font-size:.9rem;font-weight:600;color:#fff;}
    .terms-content p{margin-bottom:.8rem;}
    .terms-content ul{padding-left:1.2rem;margin-bottom:.8rem;}
    .terms-content li{margin-bottom:.35rem;}
  </style>
</head>
<body>
  <div class="app">
    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div class="brand">
        <i class="bi bi-arrow-left" style="cursor:pointer" onclick="history.back()"></i>
        &nbsp;YoloPlay Gaming Rules
      </div>
      <!-- Disabled Policy button (non-clickable) -->
      <button type="button" class="btn btn-sm btn-outline-light rounded-pill px-3" disabled>
        <i class="bi bi-shield-check me-1"></i>Policy
      </button>
    </div>

    <!-- RULES CARD -->
    <div class="glass p-4">
      <h5 class="mb-2" style="opacity:.9;">YoloPlay Gaming Rules</h5>
      <p class="intro mb-3">
        कृपया नीचे दिए गए नियम ध्यान से पढ़ें। YoloPlay के सभी गेम्स और सर्विसेज़ पर ये नियम लागू होते हैं।
      </p>

      <div class="terms-content" id="tContent">
        <h6>Company Vision</h6>
        <p>
          At YoloPlay, our mission is to provide a fun and responsible gaming environment where users can engage in mini pocket games with the aim of earning small rewards. We do not promote gambling or addiction. Our platform is designed for those who wish to enjoy casual games and make small earnings without the risk of large-scale gambling.
        </p>

        <h6>Deposit Limits</h6>
        <p>
          Unlike other platforms that accept large deposits, YoloPlay encourages responsible gaming with a strict deposit limit ranging from ₹10 to ₹500. This ensures that users only engage in low-stakes, manageable games. This approach is particularly beneficial for students and those seeking small entertainment, with minimal financial risk.
        </p>

        <h6>Why Choose YoloPlay?</h6>
        <ul>
          <li><strong>Low Risk, High Fun:</strong> Our deposit limits are intentionally set low to prevent large financial commitments. Whether you want to make a ₹10 deposit or ₹500, you can enjoy the games without the fear of losing more than you can afford.</li>
          <li><strong>Transparency First:</strong> YoloPlay is built on a foundation of honesty and transparency. We do not accept high-stakes bets and discourage any form of addictive gambling. Our platform is designed to give users a casual experience with clear financial limits.</li>
          <li><strong>For All Ages:</strong> We cater to individuals seeking a fun, risk-free gaming experience. Whether you’re looking for a way to earn a little extra pocket money or just unwind, YoloPlay provides a safe, low-risk environment.</li>
          <li><strong>Responsible Gaming:</strong> We believe in moderation and ensure that our games are designed to be enjoyable, not addictive. With a clear focus on student-friendly gaming, our goal is to provide entertainment that does not spiral into problematic gambling behavior.</li>
        </ul>

        <h6>What Sets Us Apart?</h6>
        <p>
          Unlike other gambling platforms that encourage high deposits and large wagers, YoloPlay stands apart by fostering a low-risk environment. We pride ourselves on offering only small-scale gaming options, ensuring that users can make small, manageable deposits and earn pocket money at their own pace.
        </p>

        <h6>Committed to Ethical Gaming</h6>
        <p>
          At YoloPlay, we understand the importance of promoting responsible gaming. Our platform is designed to be different from others that encourage large-scale gambling. We believe in empowering our users with the tools to manage their gameplay responsibly and avoid falling into patterns of gambling addiction.
        </p>

        <h6>Join Us Today</h6>
        <p>
          Start small, play smart, and enjoy a casual gaming experience that fits your lifestyle. With YoloPlay, gaming is about having fun and making small earnings, not risking it all.
        </p>

        <h6>Fairness &amp; Transparency</h6>
        <p>
          All our games employ modern cryptocurrency algorithms to generate truly random results—no manipulation is possible. You can verify the hash and fair gameplay yourself if you have cryptocurrency knowledge, or have any cryptographer verify the results for you.
        </p>
        <p>
          We are so confident in our fairness that if you believe any outcome is manipulated, we will pay you a ₹10,000 compensation upon proof of discrepancy.
        </p>

        <h6>Our Vision &amp; Intended Use</h6>
        <p>
          Our primary aim is to offer small, fun mini-games that allow students and the unemployed to earn a little pocket money for daily expenses. These games involve an element of skill but also rely on luck—big winnings are not guaranteed. We encourage you to treat YoloPlay as a casual pastime, not a large-scale business or a substitute for your studies.
        </p>
      </div>
    </div>
  </div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // (Optional) active state handler if you add bottom nav later
    document.querySelectorAll('.nav-btn')?.forEach(btn=>{
      btn.addEventListener('click',()=>{
        document.querySelectorAll('.nav-btn').forEach(n=>n.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  </script>
  <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
          integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
          data-cf-beacon='{"version":"2024.11.0","token":"648dce9918524b9f905e7fa5008b5991","r":1}'
          crossorigin="anonymous"></script>
</body>
</html>
