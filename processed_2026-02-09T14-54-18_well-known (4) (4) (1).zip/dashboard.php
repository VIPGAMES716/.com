<?php
require_once __DIR__."/includes/util.php";
require_login();

$pdo = app_pdo();
$uid = current_uid();

// Simple error handling
try {
    // Get user balance
    $balance = (float)db_cell("SELECT COALESCE(balance,0) FROM users WHERE user_id=?", [$uid]);
    
    // Get referral code
    $refCode = "REF" . strtoupper(substr(md5($uid), 0, 8));
    
    // Get categories
    $qcat = trim($_GET['cat'] ?? '');
    $cats = ['Arcade', 'Action', 'Puzzle', 'Sports', 'Racing', 'Adventure'];
    
    // Sample games data
    $games = [
        ['slug' => 'game1', 'title' => 'Hilo', 'image_url' => 'https://icons.inout.games/408_544/io_new-hilo.png', 'online_count' => 15, 'category' => 'Arcade'],
        ['slug' => 'game2', 'title' => 'Coin Flip', 'image_url' => 'https://icons.inout.games/408_544/io_coinflip.png', 'online_count' => 8, 'category' => 'Action'],
        ['slug' => 'game3', 'title' => 'Mines', 'image_url' => 'https://icons.inout.games/408_544/io_platform-mines.png', 'online_count' => 23, 'category' => 'Puzzle'],
        ['slug' => 'game4', 'title' => 'Trading', 'image_url' => 'https://cdn.prod.website-files.com/65e508fe833fc8d3e049ee44/6615848af5aa80909b5ae9d0_cryptos.png', 'online_count' => 11, 'category' => 'Sports'],
        ['slug' => 'game5', 'title' => 'Roulette', 'image_url' => 'https://cdn.prod.website-files.com/65e508fe833fc8d3e049ee44/6613e090263a1cdca857ce57_roulette.jpg', 'online_count' => 7, 'category' => 'Racing'],
        ['slug' => 'game6', 'title' => 'Wheel', 'image_url' => 'https://cdn.prod.website-files.com/65e508fe833fc8d3e049ee44/66157e432622c87ee70dffb4_wheel.png', 'online_count' => 19, 'category' => 'Adventure'],
        ['slug' => 'game7', 'title' => 'Rock Paper Scissors', 'image_url' => 'https://cdn.prod.website-files.com/65e508fe833fc8d3e049ee44/68b15c66348e2dddb02e43a2_Rock%20Paper%20Scissors%20752x480.png', 'online_count' => 19, 'category' => 'Sports'],
        ['slug' => 'game8', 'title' => ' Double Online', 'image_url' => 'https://cdn.prod.website-files.com/65e508fe833fc8d3e049ee44/6615801ee9dd454c714059e1_double%20online.png', 'online_count' => 19, 'category' => 'Sports']
       
    ];
    
    // Filter games by category if selected
    if ($qcat && $qcat !== 'All') {
        $games = array_filter($games, function($game) use ($qcat) {
            return $game['category'] === $qcat;
        });
    }
    
    // Sample winners
    $winners = [
        ['username' => 'Player1', 'avatar' => 'https://yoloplay.b-cdn.net/img/avatars/default.png', 'winnings' => 1500],
        ['username' => 'Gamer2', 'avatar' => 'https://yoloplay.b-cdn.net/img/avatars/default.png', 'winnings' => 850],
        ['username' => 'ProPlayer', 'avatar' => 'https://yoloplay.b-cdn.net/img/avatars/default.png', 'winnings' => 600]
    ];
    
    // Check if we should show welcome popup (first visit)
    $showWelcome = !isset($_COOKIE['welcome_shown']);
    
} catch (Exception $e) {
    // Log error but don't show sensitive info to users
    error_log("Dashboard error: " . $e->getMessage());
    $balance = 0;
    $refCode = "ERROR";
    $games = [];
    $winners = [];
    $cats = [];
    $showWelcome = false;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <title><?= htmlspecialchars(app_name()) ?> — Arcade</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <style>
:root {
  --p: #8d78ff;
  --s: #ff57e6;
  --t: #ffcc00;
  --bg: rgba(255,255,255,.08);
  --line: rgba(255,255,255,.12);
  --dim: rgba(255,255,255,.74);
  --card-bg: linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
  --shadow: 0 10px 30px rgba(0,0,0,0.3);
  --glow: 0 0 20px rgba(141, 120, 255, 0.5);
}

*,*::before,*::after{box-sizing:border-box}
html, body {
  margin:0;
  padding:0;
  min-height:100vh;
  color:#fff;
  font-family:Poppins,sans-serif;
  background: radial-gradient(ellipse at center, #2d2570 0%, #110e25 70%);
  overflow-x:hidden;
  perspective: 1000px;
}
body::after{
  content:"";
  position:fixed;
  inset:0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.03'/%3E%3C/svg%3E");
  mix-blend-mode:overlay;
  pointer-events:none;
  z-index: 100;
}

.app {
  max-width:480px;
  margin-inline:auto;
  padding:.4rem .8rem 6rem; /* Reduced bottom padding since nav is fixed */
  position:relative;
  z-index:1;
}

.glass {
  background: var(--card-bg);
  border: 1px solid var(--line);
  backdrop-filter: blur(16px);
  border-radius: 26px;
  box-shadow: var(--shadow);
  transition: all 0.3s ease;
}

/* 3D Header */
.header-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: .2rem 0;
  margin-bottom: .8rem;
  position: relative;
}

.title {
  position: relative;
  z-index: 2;
}

.title img.header-logo {
  height: 3rem;
  width: auto;
  filter: drop-shadow(0 5px 15px rgba(0,0,0,0.3));
}

.balance {
  display: flex;
  align-items: center;
  gap: .3rem;
  padding: 8px 14px;
  font-size: .85rem;
  font-weight: 700;
  border-radius: 40px;
  background: var(--card-bg);
  border: 1px solid var(--line);
  backdrop-filter: blur(12px);
  box-shadow: var(--shadow);
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
}

.balance::before {
  content: "";
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: var(--s);
  box-shadow: 0 0 10px var(--s);
}

.balance:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 25px rgba(0,0,0,0.4);
}

.balance i {
  font-size: 1rem;
  cursor: pointer;
  transition: transform 0.2s;
}

.balance i:hover {
  transform: scale(1.2);
}

/* Enhanced Slider */
.slider-container {
  position: relative;
  height: 170px;
  border-radius: 26px;
  overflow: hidden;
  margin-bottom: 1.5rem;
  box-shadow: var(--shadow);
  transform-style: preserve-3d;
}

.slider {
  position: relative;
  height: 100%;
  border-radius: 26px;
  overflow: hidden;
}

.slide {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  transition: transform 0.8s ease, opacity 0.8s ease;
  transform-style: preserve-3d;
}

.slide::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(0,0,0,.6), rgba(0,0,0,.2));
}

.slide-content {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 20px;
  padding-inline: 1.5rem;
  font-size: 1.2rem;
  font-weight: 700;
  z-index: 2;
  text-shadow: 0 2px 10px rgba(0,0,0,0.5);
}

.dot-row {
  position: absolute;
  bottom: 15px;
  right: 15px;
  display: flex;
  gap: .4rem;
  z-index: 3;
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: rgba(255,255,255,.55);
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}

.dot.active {
  background: #fff;
  transform: scale(1.2);
  box-shadow: 0 0 10px rgba(255,255,255,0.8);
}

/* Referral Strip */
.refer-strip {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: .8rem;
  margin: 1.2rem 0;
  padding: .9rem 1.2rem;
  background: linear-gradient(135deg, rgba(141, 120, 255, 0.2), rgba(255, 87, 230, 0.2));
  border: 1px solid rgba(255,255,255,0.15);
  position: relative;
  overflow: hidden;
}

.refer-strip::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
  z-index: -1;
}

.ref-l {
  font-size: .85rem;
}

.ref-code {
  font-weight: 700;
  letter-spacing: .3px;
  color: var(--t);
}

.btn-mini {
  border: none;
  border-radius: 14px;
  background: #fff;
  color: #000;
  padding: .4rem .8rem;
  font-size: .76rem;
  font-weight: 700;
  display: inline-flex;
  align-items: center;
  gap: .35rem;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

.btn-mini:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 15px rgba(0,0,0,0.3);
}

/* Chips */
.chips {
  display: flex;
  gap: .6rem;
  overflow-x: auto;
  margin: 1.2rem 0;
  padding: 5px 0;
}

.chips::-webkit-scrollbar {
  display: none;
}

.chip {
  flex: 0 0 auto;
  font-size: .78rem;
  padding: .5rem 1.1rem;
  border-radius: 16px;
  background: rgba(255,255,255,.07);
  border: 1px solid var(--line);
  cursor: pointer;
  text-decoration: none;
  color: #fff;
  transition: all 0.3s ease;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

.chip.active {
  background: var(--p);
  box-shadow: var(--glow);
  transform: translateY(-2px);
}

.chip:hover:not(.active) {
  background: rgba(255,255,255,.12);
  transform: translateY(-2px);
}

/* Games Grid - 2 per line */
.games {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.game-card {
  position: relative;
  border-radius: 22px;
  overflow: hidden;
  background: var(--card-bg);
  border: 1px solid var(--line);
  aspect-ratio: 3/4;
  cursor: pointer;
  box-shadow: var(--shadow);
  transition: all 0.4s ease;
  transform-style: preserve-3d;
}

.game-card:hover {
  transform: translateY(-8px) rotateX(5deg);
  box-shadow: 0 15px 30px rgba(0,0,0,0.4), var(--glow);
}

@supports not (aspect-ratio: 3/4) {
  .game-card::before {
    content: "";
    display: block;
    padding-top: 133.33%;
  }
  .game-card>* {
    position: absolute;
    inset: 0;
  }
}

.game-card img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform .5s ease;
}

.game-card:hover img {
  transform: scale(1.1);
}

.tag {
  position: absolute;
  bottom: 8px;
  right: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  font-size: .66rem;
  font-weight: 600;
  background: rgba(0,0,0,.7);
  border-radius: 14px;
  backdrop-filter: blur(10px);
  z-index: 2;
}

.tag i {
  font-size: .8rem;
  color: var(--t);
}

/* Today's Winners Section */
.winners-section {
  margin: 2rem 0;
}

.section-title {
  font-size: 1.1rem;
  font-weight: 700;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 8px;
}

.section-title i {
  color: var(--t);
}

.winners-container {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
}

.winner-card {
  flex: 1;
  text-align: center;
  padding: 1rem 0.5rem;
  border-radius: 20px;
  background: var(--card-bg);
  border: 1px solid var(--line);
  box-shadow: var(--shadow);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.winner-card:hover {
  transform: translateY(-5px);
}

.winner-card.first {
  background: linear-gradient(145deg, rgba(255,204,0,0.15), rgba(255,204,0,0.05));
  border: 1px solid rgba(255,204,0,0.3);
}

.winner-card.second {
  background: linear-gradient(145deg, rgba(192,192,192,0.15), rgba(192,192,192,0.05));
  border: 1px solid rgba(192,192,192,0.3);
}

.winner-card.third {
  background: linear-gradient(145deg, rgba(205,127,50,0.15), rgba(205,127,50,0.05));
  border: 1px solid rgba(205,127,50,0.3);
}

.rank-badge {
  position: absolute;
  top: -8px;
  left: 50%;
  transform: translateX(-50%);
  width: 30px;
  height: 30px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 0.8rem;
  box-shadow: 0 3px 10px rgba(0,0,0,0.3);
}

.first .rank-badge {
  background: var(--t);
  color: #000;
}

.second .rank-badge {
  background: #c0c0c0;
  color: #000;
}

.third .rank-badge {
  background: #cd7f32;
  color: #fff;
}

.winner-avatar {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  object-fit: cover;
  margin: 0 auto 8px;
  border: 3px solid rgba(255,255,255,0.2);
  box-shadow: 0 5px 15px rgba(0,0,0,0.3);
}

.winner-name {
  font-size: 0.85rem;
  font-weight: 600;
  margin-bottom: 5px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.winner-amount {
  font-size: 0.75rem;
  color: var(--t);
  font-weight: 700;
}

/* Welcome Popup */
.welcome-popup {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(10px);
  opacity: 0;
  visibility: hidden;
  transition: all 0.5s ease;
}

.welcome-popup.active {
  opacity: 1;
  visibility: visible;
}

.welcome-content {
  background: linear-gradient(145deg, rgba(40,30,90,0.9), rgba(20,10,50,0.9));
  border-radius: 30px;
  padding: 2rem;
  max-width: 350px;
  width: 90%;
  text-align: center;
  box-shadow: 0 20px 50px rgba(0,0,0,0.5);
  border: 1px solid rgba(255,255,255,0.1);
  transform: scale(0.8);
  transition: transform 0.5s ease;
  position: relative;
  overflow: hidden;
}

.welcome-popup.active .welcome-content {
  transform: scale(1);
}

.welcome-content::before {
  content: "";
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(141,120,255,0.2) 0%, transparent 70%);
  z-index: -1;
}

.welcome-image {
  width: 100%;
  height: 180px;
  border-radius: 20px;
  object-fit: cover;
  margin-bottom: 1rem;
  box-shadow: 0 10px 25px rgba(0,0,0,0.5);
}

.welcome-title {
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
}

.welcome-text {
  font-size: 0.9rem;
  margin-bottom: 1.5rem;
  opacity: 0.8;
  line-height: 1.5;
}

.welcome-btn {
  background: var(--p);
  color: white;
  border: none;
  border-radius: 20px;
  padding: 0.8rem 2rem;
  font-size: 1rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 5px 15px rgba(141,120,255,0.4);
}

.welcome-btn:hover {
  background: #7a65ff;
  transform: translateY(-3px);
  box-shadow: 0 8px 20px rgba(141,120,255,0.6);
}

/* Dock - FIXED POSITION - ALWAYS VISIBLE */
/* Dock - ALWAYS VISIBLE - FIXED - IMPROVED */
.dock {
  position: fixed !important;
  left: 0;
  right: 0;
  bottom: 0;
  height: 82px;
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  align-items: center;
  justify-items: center;
  background: rgba(14,10,30,0.98);
  border-top: 1px solid var(--line);
  backdrop-filter: blur(18px);
  padding: 0 max(8px, env(safe-area-inset-left)) 0 max(8px, env(safe-area-inset-right));
  z-index: 1000;
  /* Always visible - no transform */
  transform: translateY(0) !important;
  transition: none !important;
  /* Ensure visibility */
  visibility: visible !important;
  opacity: 1 !important;
  /* Prevent any hiding */
  display: grid !important;
}

.nav-btn {
  color: var(--dim);
  font-size: .76rem;
  text-decoration: none;
  display: flex;
  flex-direction: column;
  gap: 2px;
  align-items: center;
  cursor: pointer;
  transition: all 0.3s ease;
  padding: 8px 0;
}

.nav-btn .bi {
  font-size: 1.45rem;
  transition: all 0.3s ease;
}

.nav-btn.active {
  color: #fff;
}

.nav-btn.active .bi {
  color: var(--p);
  filter: drop-shadow(0 0 5px rgba(141,120,255,0.7));
}

.nav-btn:hover:not(.active) {
  color: #fff;
  transform: translateY(-3px);
}

.fab {
  position: absolute;
  top: -6px;
  left: 50%;
  transform: translateX(-50%);
  width: 64px;
  height: 64px;
  background: var(--p);
  border-radius: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.8rem;
  color: #fff;
  box-shadow: 0 6px 24px rgba(141,120,255,0.55);
  border: 5px solid rgba(255,255,255,.05);
  transition: all 0.3s ease;
  z-index: 1001;
}

.fab:hover {
  transform: translateX(-50%) scale(1.1);
  box-shadow: 0 10px 30px rgba(141,120,255,0.7);
}

/* Safe area for modern mobile devices */
@supports (padding: max(0px)) {
  .dock {
    padding-bottom: max(8px, env(safe-area-inset-bottom));
  }
}

/* Ensure main app content doesn't overlap with dock */
.app {
  max-width:480px;
  margin-inline:auto;
  padding:.4rem .8rem calc(9.4rem + env(safe-area-inset-bottom)) !important; /* Extra padding for dock */
  position:relative;
  z-index:1;
}

@media (max-width:350px) {
  .nav-btn .bi {
    font-size:1.3rem;
  }
  .nav-btn span {
    font-size:.66rem;
  }
  .games {
    grid-template-columns: 1fr;
  }
}

/* Toast notification */
.toast {
  position: fixed;
  bottom: 110px;
  left: 50%;
  transform: translateX(-50%);
  padding: .7rem 1.2rem;
  background: #fff;
  color: #000;
  border-radius: 14px;
  font-weight: 700;
  z-index: 999;
  opacity: 0;
  transition: opacity .3s;
  box-shadow: 0 5px 15px rgba(0,0,0,0.3);
}

/* 3D Background Effect */
.three-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
  opacity: 0.4;
}

/* Game title overlay */
.game-title {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 10px;
  background: linear-gradient(transparent, rgba(0,0,0,0.8));
  font-size: 0.85rem;
  font-weight: 600;
  z-index: 2;
}

/* New features section */
.features-section {
  margin: 2rem 0;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
}

.feature-card {
  background: var(--card-bg);
  border: 1px solid var(--line);
  border-radius: 20px;
  padding: 1rem;
  text-align: center;
  transition: all 0.3s ease;
  cursor: pointer;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: var(--glow);
}

.feature-icon {
  font-size: 2rem;
  color: var(--p);
  margin-bottom: 0.5rem;
}

.feature-title {
  font-size: 0.9rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.feature-desc {
  font-size: 0.75rem;
  opacity: 0.8;
}

/* Achievement section */
.achievement-section {
  margin: 2rem 0;
}

.achievement-list {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.achievement-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.8rem;
  background: var(--card-bg);
  border: 1px solid var(--line);
  border-radius: 16px;
  transition: all 0.3s ease;
}

.achievement-item:hover {
  transform: translateX(5px);
  box-shadow: var(--shadow);
}

.achievement-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--p);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
}

.achievement-info {
  flex: 1;
}

.achievement-title {
  font-size: 0.9rem;
  font-weight: 600;
  margin-bottom: 0.2rem;
}

.achievement-desc {
  font-size: 0.75rem;
  opacity: 0.8;
}

.achievement-progress {
  height: 4px;
  background: rgba(255,255,255,0.1);
  border-radius: 2px;
  margin-top: 0.3rem;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: var(--t);
  border-radius: 2px;
  transition: width 0.5s ease;
}

/* Loading animation */
.loading-spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid rgba(255,255,255,.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* Pulse animation for FAB */
@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(141, 120, 255, 0.7); }
  70% { box-shadow: 0 0 0 10px rgba(141, 120, 255, 0); }
  100% { box-shadow: 0 0 0 0 rgba(141, 120, 255, 0); }
}

.fab.pulse {
  animation: pulse 2s infinite;
}

/* Safe area for modern mobile devices */
@supports (padding: max(0px)) {
  .dock {
    padding-bottom: max(8px, env(safe-area-inset-bottom));
  }
  .app {
    padding-bottom: calc(6rem + env(safe-area-inset-bottom));
  }
}
</style>
</head>
<body>
  <!-- 3D Background -->
  <div class="three-bg" id="threeBg"></div>

  <div class="app">
    <!-- header -->
    <div class="header-container">
      <div class="title">
        <img src="/assets/logo.svg" class="header-logo" alt="logo">
      </div>
      <div class="balance" title="Wallet">
        <span>₹<?= number_format($balance,0) ?></span>
        <a href="/recharge.php" style="color:#fff"><i class="bi bi-plus"></i></a>
      </div>
    </div>

    <!-- slider -->
    <div class="slider-container glass">
      <div class="slider" id="slider">
        <div class="slide" style="background-image:url('https://i.ibb.co/B5KHv6mz/6070867519519525726-121.jpg')"></div>
        <div class="slide" style="background-image:url('https://i.ibb.co/9HbGFWZy/6070867519519525724-121.jpg');opacity:0"></div>
        <div class="slide" style="background-image:url('https://i.ibb.co/HZRGVFq/6070867519519525725-121.jpg');opacity:0"></div>
        <div class="slide-content">Double XP Friday – Live Now!</div>
        <div class="dot-row">
          <div class="dot active"></div><div class="dot"></div><div class="dot"></div>
        </div>
      </div>
    </div>

    <!-- referral strip -->
    <div class="refer-strip glass">
      <div class="ref-l">
        <div style="opacity:.85;font-weight:700">Refer & Earn</div>
        <div class="ref-code">Code: <span id="refCode"><?= htmlspecialchars($refCode) ?></span></div>
      </div>
      <div>
        <button class="btn-mini" id="btnCopy"><i class="bi bi-clipboard"></i>Copy</button>
        <a href="/refer.php" class="btn-mini"><i class="bi bi-lightning-fill"></i>Open</a>
      </div>
    </div>

    <!-- chips -->
    <div class="chips">
      <a class="chip <?= $qcat===''||$qcat==='All'?'active':'' ?>" href="/dashboard.php?cat=All">All</a>
      <?php foreach ($cats as $c): ?>
        <a class="chip <?= $qcat===$c?'active':'' ?>" href="/dashboard.php?cat=<?= urlencode($c) ?>"><?= htmlspecialchars($c) ?></a>
      <?php endforeach; ?>
    </div>

    <!-- games -->
    <h6 class="section-title"><i class="bi bi-controller"></i> All Games</h6>
    <div class="games" id="gameGrid">
      <?php foreach ($games as $g): ?>
        <div class="game-card" onclick="location.href='/play.php?game=<?= urlencode($g['slug']) ?>'">
          <img src="<?= htmlspecialchars($g['image_url'] ?: 'https://yoloplay.b-cdn.net/img/home/cryptos.png') ?>" alt="<?= htmlspecialchars($g['title']) ?>">
          <div class="game-title"><?= htmlspecialchars($g['title']) ?></div>
          <div class="tag"><i class="bi bi-people-fill"></i> <?= (int)$g['online_count'] ?></div>
        </div>
      <?php endforeach; ?>
      <?php if (!$games): ?>
        <div class="glass" style="padding:1rem;border-radius:18px; grid-column: 1 / -1; text-align: center;">
          No games enabled. Go to <a href="/admin/games.php">Admin › Games</a>.
        </div>
      <?php endif; ?>
    </div>

    <!-- New Features Section -->
    <div class="features-section">
      <h6 class="section-title"><i class="bi bi-stars"></i> New Features</h6>
      <div class="features-grid">
        <div class="feature-card glass" onclick="showDailyRewards()">
          <div class="feature-icon"><i class="bi bi-gift-fill"></i></div>
          <div class="feature-title">Daily Rewards</div>
          <div class="feature-desc">Claim free coins every day</div>
        </div>
        <div class="feature-card glass" onclick="showTournamentInfo()">
          <div class="feature-icon"><i class="bi bi-trophy-fill"></i></div>
          <div class="feature-title">Tournaments</div>
          <div class="feature-desc">Compete for big prizes</div>
        </div>
      </div>
    </div>

    <!-- Achievement Section -->
    <div class="achievement-section">
      <h6 class="section-title"><i class="bi bi-award-fill"></i> Your Achievements</h6>
      <div class="achievement-list">
        <div class="achievement-item glass" onclick="showAchievementProgress()">
          <div class="achievement-icon"><i class="bi bi-joystick"></i></div>
          <div class="achievement-info">
            <div class="achievement-title">First Game Played</div>
            <div class="achievement-desc">Play your first game</div>
            <div class="achievement-progress">
              <div class="progress-bar" style="width: 100%"></div>
            </div>
          </div>
        </div>
        <div class="achievement-item glass" onclick="showAchievementProgress()">
          <div class="achievement-icon"><i class="bi bi-people-fill"></i></div>
          <div class="achievement-info">
            <div class="achievement-title">Social Butterfly</div>
            <div class="achievement-desc">Invite 5 friends</div>
            <div class="achievement-progress">
              <div class="progress-bar" style="width: 40%"></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Today's Winners -->
    <div class="winners-section">
      <h6 class="section-title"><i class="bi bi-trophy-fill"></i> Today's Winners</h6>
      <div class="winners-container">
        <?php if (count($winners) > 0): ?>
          <?php 
          $ranks = ['first', 'second', 'third'];
          for ($i = 0; $i < min(3, count($winners)); $i++): 
            $winner = $winners[$i];
          ?>
            <div class="winner-card <?= $ranks[$i] ?>">
              <div class="rank-badge"><?= $i+1 ?></div>
              <img src="<?= htmlspecialchars($winner['avatar'] ?: 'https://yoloplay.b-cdn.net/img/avatars/default.png') ?>" class="winner-avatar" alt="<?= htmlspecialchars($winner['username']) ?>">
              <div class="winner-name"><?= htmlspecialchars($winner['username']) ?></div>
              <div class="winner-amount">₹<?= number_format($winner['winnings'], 0) ?></div>
            </div>
          <?php endfor; ?>
        <?php else: ?>
          <div class="winner-card" style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
            <i class="bi bi-emoji-frown" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
            <div>No winners today yet. Be the first!</div>
          </div>
        <?php endif; ?>
      </div>
    </div>

  </div>

  <!-- Welcome Popup -->
  <?php if ($showWelcome): ?>
  <div class="welcome-popup active" id="welcomePopup">
    <div class="welcome-content">
      <img src="https://i.ibb.co/s9CZ2rgR/5e2e665f-d21d-4193-9603-3a8045627b29.png" class="welcome-image" alt="Welcome to <?= htmlspecialchars(app_name()) ?>">
      <h2 class="welcome-title">Welcome to <?= htmlspecialchars(app_name()) ?>!</h2>
      <p class="welcome-text">Get ready for an amazing gaming experience with exciting rewards and challenges. Play, compete, and win big!</p>
      <button class="welcome-btn" id="welcomeClose">Let's Play!</button>
    </div>
  </div>
  <?php endif; ?>

  <!-- Bottom Navigation - FIXED - ALWAYS VISIBLE -->
  <nav class="dock" id="bottomNav">
    <a href="/dashboard.php" class="nav-btn active">
      <i class="bi bi-controller"></i><span>Arcade</span>
    </a>
    <a href="/esports.php" class="nav-btn">
      <i class="bi bi-trophy"></i><span>eSports</span>
    </a>
    <span></span>
    <a href="/chat.php" class="nav-btn">
      <i class="bi bi-chat-dots-fill"></i><span>Chat</span>
    </a>
    <a href="/profile.php" class="nav-btn">
      <i class="bi bi-person-circle"></i><span>Profile</span>
    </a>
    <!-- FAB to refer -->
    <a href="/refer.php" class="fab pulse" title="Refer & Earn">
      <i class="bi bi-lightning-fill"></i>
    </a>
  </nav>

  <script>
    // 3D Background with Three.js
    function initThreeBackground() {
      const container = document.getElementById('threeBg');
      if (!container) return;
      
      const width = container.clientWidth;
      const height = container.clientHeight;
      
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
      const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
      
      renderer.setSize(width, height);
      renderer.setClearColor(0x000000, 0);
      container.appendChild(renderer.domElement);
      
      // Create particles
      const particlesGeometry = new THREE.BufferGeometry();
      const particlesCount = 100;
      const posArray = new Float32Array(particlesCount * 3);
      
      for(let i = 0; i < particlesCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 10;
      }
      
      particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
      
      const particlesMaterial = new THREE.PointsMaterial({
        size: 0.05,
        color: 0x8d78ff,
        transparent: true,
        opacity: 0.6
      });
      
      const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
      scene.add(particlesMesh);
      
      camera.position.z = 2;
      
      // Animation
      function animate() {
        requestAnimationFrame(animate);
        
        particlesMesh.rotation.x += 0.001;
        particlesMesh.rotation.y += 0.002;
        
        renderer.render(scene, camera);
      }
      
      animate();
      
      // Handle resize
      window.addEventListener('resize', () => {
        const width = container.clientWidth;
        const height = container.clientHeight;
        renderer.setSize(width, height);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
      });
    }
    
    // Initialize 3D background when page loads
    document.addEventListener('DOMContentLoaded', function() {
      initThreeBackground();
      
      // Force navigation to be always visible
      const bottomNav = document.getElementById('bottomNav');
      if (bottomNav) {
        bottomNav.style.transform = 'translateX(-50%)';
        bottomNav.style.visibility = 'visible';
        bottomNav.style.opacity = '1';
      }
    });

    // slider
    const slides = [...document.querySelectorAll('.slide')];
    const dots = [...document.querySelectorAll('.dot')];
    let idx = 0;
    
    const showSlide = i => {
      slides.forEach((s, j) => {
        s.style.opacity = (j === i ? 1 : 0);
        s.style.transform = (j === i ? 'scale(1)' : 'scale(1.05)');
      });
      dots.forEach((d, j) => d.classList.toggle('active', j === i));
    };
    
    setInterval(() => {
      idx = (idx + 1) % slides.length;
      showSlide(idx);
    }, 4000);
    
    dots.forEach((d, i) => d.onclick = () => {
      idx = i;
      showSlide(i);
    });

    // copy referral link
    const ref = '<?= htmlspecialchars($refCode, ENT_QUOTES) ?>';
    const base = location.origin;
    
    document.getElementById('btnCopy').onclick = () => {
      const url = `${base}/register.php?ref=${encodeURIComponent(ref)}`;
      navigator.clipboard.writeText(url).then(() => {
        showToast('Referral link copied ✅');
      }).catch(() => {
        showToast('Failed to copy link');
      });
    };

    // Toast notification function
    function showToast(message) {
      const toast = document.createElement('div');
      toast.className = 'toast';
      toast.textContent = message;
      document.body.appendChild(toast);
      
      requestAnimationFrame(() => toast.style.opacity = '1');
      
      setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
      }, 1800);
    }

    // Welcome popup close
    document.getElementById('welcomeClose')?.addEventListener('click', function() {
      const popup = document.getElementById('welcomePopup');
      popup.classList.remove('active');
      setTimeout(() => popup.remove(), 500);
      
      // Set cookie to not show welcome again
      document.cookie = "welcome_shown=true; max-age=" + 60*60*24*30; // 30 days
    });

    // Add hover effects to game cards
    document.querySelectorAll('.game-card').forEach(card => {
      card.addEventListener('mouseenter', function() {
        this.style.zIndex = '10';
      });
      
      card.addEventListener('mouseleave', function() {
        this.style.zIndex = '';
      });
    });

    // Three new functions for enhanced user experience
    function showDailyRewards() {
      showToast('🎁 Daily Rewards: Come back tomorrow for more coins!');
    }
    
    function showTournamentInfo() {
      showToast('🏆 Weekly tournaments start every Monday. Stay tuned!');
    }
    
    function showAchievementProgress() {
      showToast('⭐ Keep playing to unlock more achievements!');
    }

    // Force navigation to be always visible on page load
    window.addEventListener('load', function() {
      const bottomNav = document.getElementById('bottomNav');
      if (bottomNav) {
        bottomNav.style.transform = 'translateX(-50%)';
        bottomNav.style.visibility = 'visible';
        bottomNav.style.opacity = '1';
      }
    });

    // Prevent any scroll-based hiding
    window.addEventListener('scroll', function() {
      const bottomNav = document.getElementById('bottomNav');
      if (bottomNav) {
        bottomNav.style.transform = 'translateX(-50%)';
        bottomNav.style.visibility = 'visible';
        bottomNav.style.opacity = '1';
      }
    }, { passive: true });

    // Force navigation visibility immediately
    (function() {
      const bottomNav = document.getElementById('bottomNav');
      if (bottomNav) {
        bottomNav.style.transform = 'translateX(-50%)';
        bottomNav.style.visibility = 'visible';
        bottomNav.style.opacity = '1';
      }
    })();
  </script>
</body>
</html>